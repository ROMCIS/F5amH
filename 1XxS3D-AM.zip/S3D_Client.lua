﻿local Rroot = getResourceRootElement(getThisResource())

local Serials ={ 
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
}

S3D = {
    window = {},
    gridlist = {},
    label = {},
    button = {},
    edit = {}
}


S3D.window[1] = guiCreateWindow(547, 281, 321, 378, ".: Add Serial Player For Admin Control | T.S :.", false)
S3D.label[1] = guiCreateLabel(26, 64, 47, 16, "Serials :", false, S3D.window[1])
S3D.gridlist[1] = guiCreateGridList(9, 104, 302, 154, false, S3D.window[1])
guiGridListAddColumn(S3D.gridlist[1], "Control", 1.2)
S3D.edit[1] = guiCreateEdit(30, 266, 261, 23, "", false, S3D.window[1])
S3D.button[1] = guiCreateButton(15, 299, 131, 24, "Add Serial", false, S3D.window[1])
S3D.button[2] = guiCreateButton(174, 299, 131, 24, "Deleted Serial", false, S3D.window[1])
S3D.button[3] = guiCreateButton(91, 333, 131, 24, "=[ Close ]=", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
guiSetProperty(S3D.window[1], "CaptionColour", "FF00FED7")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF17FC00")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF17FC00")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFFB0000") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(v, 233, 253, 0)
end end ) 

addEventHandler("onClientGUIClick",root, 
function() 
if (source == S3D.button[3]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(S3D.window[1], false)
elseif (source == S3D.button[1]) then 
local romcis_serials = guiGetText(S3D.edit[1]) 
if ( romcis_serials == '' or guiEditGetCaretIndex( S3D.edit[1] ) < 32 or guiEditGetCaretIndex( S3D.edit[1] ) > 32 ) then exports.infobox:outputMessage('يوجد خلل فني ف السكريبت',50,255,0,true) return end 
if ( romcis_serials == '') then return end  triggerServerEvent('RoMcIS_Check', localPlayer, romcis_serials) 
elseif (source == S3D.button[2]) then 
local romcis_text = guiGridListGetSelectedItem(S3D.gridlist[1]) 
if (romcis_text ~= -1) then 
local Player = guiGridListGetItemText(S3D.gridlist[1], romcis_text, 1) 
triggerServerEvent( 'RoMcIS_RemoveSerial', localPlayer, Player ) 
else 
exports.infobox:outputMessage('يرجى أختيار الاعب من القائمة', 240,255,0, false) 
end 
end
end )

addEvent('RoMcIS_AddPlayers',true) 
addEventHandler('RoMcIS_AddPlayers',root, 
function(RS) 
guiGridListClear(S3D.gridlist[1]) for i, v in ipairs (RS) do local Row = guiGridListAddRow(S3D.gridlist[1]) 
local TheSerial = guiGridListSetItemText(S3D.gridlist[1], Row, 1, RS[i].Serial, false, false) 
end end)

addEvent('RoMcIS_gridlist',true) 
addEventHandler('RoMcIS_gridlist',root, 
function()
guiGridListClear(S3D.gridlist[1])
end )

addCommandHandler('s3d_am', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1])) 
showCursor(guiGetVisible(S3D.window[1])) 
guiSetInputEnabled(guiGetVisible(S3D.window[1])) 
triggerServerEvent('Rom_GetAllfuck', localPlayer) 
triggerServerEvent('Active_Dev1', localPlayer)
triggerServerEvent('ActiveSerialsAllAccount_Dev', localPlayer)
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )