﻿
function deleteLastCharacter(str)
return(str:gsub("[%z\1-\127\194-\244][\128-\191]*$", ""))
end

local Key = 'N'

function centerWindow(center_window,i,v)
local screenW, screenH = guiGetScreenSize()
local windowW, windowH = guiGetSize(center_window, false)
local x, y = (screenW - windowW) / i, (screenH - windowH) / v
guiSetPosition(center_window, x, y, false)
end

-----------------------------------
-- Main Wnd
---------------------------------

local Rroot = getResourceRootElement(getThisResource())

S3D = {
    button = {},
    window = {},
    edit = {}
}

        S3D.window[1] = guiCreateWindow(386, 182, 309, 473, "زخرفة النك", false)
        

        S3D.button[1] = guiCreateButton(10, 30, 41, 27, "Á", false, S3D.window[1])
        S3D.button[2] = guiCreateButton(51, 30, 41, 27, "Ɓ", false, S3D.window[1])
        S3D.button[3] = guiCreateButton(92, 30, 41, 27, "Ƈ", false, S3D.window[1])
        S3D.button[4] = guiCreateButton(133, 30, 41, 27, "Ɗ", false, S3D.window[1])
        S3D.button[5] = guiCreateButton(174, 30, 41, 27, "Є", false, S3D.window[1])
        S3D.button[6] = guiCreateButton(215, 30, 41, 27, "Բ", false, S3D.window[1])
        S3D.button[7] = guiCreateButton(256, 30, 41, 27, "Ɠ", false, S3D.window[1])
		
        S3D.button[8] = guiCreateButton(10, 57, 41, 27, "Ӈ", false, S3D.window[1])
        S3D.button[9] = guiCreateButton(51, 57, 41, 27, "Ĩ", false, S3D.window[1])
        S3D.button[10] = guiCreateButton(92, 57, 41, 27, "ʝ", false, S3D.window[1])
        S3D.button[11] = guiCreateButton(133, 57, 41, 27, "Ƙ", false, S3D.window[1])
        S3D.button[12] = guiCreateButton(174, 57, 41, 27, "L", false, S3D.window[1])
        S3D.button[13] = guiCreateButton(215, 57, 41, 27, "ℓ", false, S3D.window[1])
        S3D.button[14] = guiCreateButton(256, 57, 41, 27, "Ẍ", false, S3D.window[1])
		
		
		
        S3D.button[15] = guiCreateButton(10, 84, 41, 27, "Μ", false, S3D.window[1])
        S3D.button[16] = guiCreateButton(51, 84, 41, 27, "η", false, S3D.window[1])
        S3D.button[17] = guiCreateButton(92, 84, 41, 27, "Ő", false, S3D.window[1])
        S3D.button[18] = guiCreateButton(133, 84, 41, 27, "P", false, S3D.window[1])
        S3D.button[19] = guiCreateButton(174, 84, 41, 27, "S", false, S3D.window[1])
        S3D.button[20] = guiCreateButton(215, 84, 41, 27, "Q", false, S3D.window[1])
        S3D.button[21] = guiCreateButton(256, 84, 41, 27, "Ŕ", false, S3D.window[1])
		
        S3D.button[22] = guiCreateButton(10, 111, 41, 27, "Ś", false, S3D.window[1])
        S3D.button[23] = guiCreateButton(51, 111, 41, 27, "Ť", false, S3D.window[1])
        S3D.button[24] = guiCreateButton(92, 111, 41, 27, "Ú", false, S3D.window[1])
        S3D.button[25] = guiCreateButton(133, 111, 41, 27, "V", false, S3D.window[1])
        S3D.button[26] = guiCreateButton(174, 111, 41, 27, "Ŵ", false, S3D.window[1])
        S3D.button[27] = guiCreateButton(215, 111, 41, 27, "Ӽ", false, S3D.window[1])
        S3D.button[28] = guiCreateButton(256, 111, 41, 27, "Ɣ", false, S3D.window[1])
		
        S3D.button[29] = guiCreateButton(10, 138, 41, 27, "ž", false, S3D.window[1])
        S3D.button[30] = guiCreateButton(51, 138, 41, 27, "室", false, S3D.window[1])
        S3D.button[31] = guiCreateButton(92, 138, 41, 27, "❥", false, S3D.window[1])
        S3D.button[32] = guiCreateButton(133, 138, 41, 27, "✱", false, S3D.window[1])
        S3D.button[33] = guiCreateButton(174, 138, 41, 27, "»", false, S3D.window[1])
        S3D.button[34] = guiCreateButton(215, 138, 41, 27, "Ʒ", false, S3D.window[1])
        S3D.button[35] = guiCreateButton(256, 138, 41, 27, ".", false, S3D.window[1])
		
        S3D.button[36] = guiCreateButton(10, 165, 41, 27, "Ƹ", false, S3D.window[1])
        S3D.button[37] = guiCreateButton(51, 165, 41, 27, "✖", false, S3D.window[1])
        S3D.button[38] = guiCreateButton(92, 165, 41, 27, "«", false, S3D.window[1])
        S3D.button[39] = guiCreateButton(133, 165, 41, 27, "▓", false, S3D.window[1])
        S3D.button[40] = guiCreateButton(174, 165, 41, 27, "『", false, S3D.window[1])
        S3D.button[41] = guiCreateButton(215, 165, 41, 27, "』", false, S3D.window[1])
        S3D.button[42] = guiCreateButton(256, 165, 41, 27, " ๑", false, S3D.window[1])
		
        S3D.button[43] = guiCreateButton(10, 192, 41, 27, "♥", false, S3D.window[1])
        S3D.button[44] = guiCreateButton(51, 192, 41, 27, "✔", false, S3D.window[1])
        S3D.button[45] = guiCreateButton(92, 192, 41, 27, "ֆ", false, S3D.window[1])
        S3D.button[46] = guiCreateButton(133, 192, 41, 27, "▌", false, S3D.window[1])
        S3D.button[47] = guiCreateButton(174, 192, 41, 27, "̉1", false, S3D.window[1])
        S3D.button[48] = guiCreateButton(215, 192, 41, 27, "̉2", false, S3D.window[1])
        S3D.button[49] = guiCreateButton(256, 192, 41, 27, "̉3", false, S3D.window[1])
		
        S3D.button[50] = guiCreateButton(10, 219, 41, 27, "̉4", false, S3D.window[1])
        S3D.button[51] = guiCreateButton(51, 219, 41, 27, "̉5", false, S3D.window[1])
        S3D.button[52] = guiCreateButton(92, 219, 41, 27, "̉6", false, S3D.window[1])
        S3D.button[53] = guiCreateButton(133, 219, 41, 27, "̉7", false, S3D.window[1])
        S3D.button[54] = guiCreateButton(174, 219, 41, 27, "̉8", false, S3D.window[1])
        S3D.button[55] = guiCreateButton(215, 219, 41, 27, "̉9", false, S3D.window[1])
        S3D.button[56] = guiCreateButton(256, 219, 41, 27, "̉0", false, S3D.window[1])
		
        S3D.button[57] = guiCreateButton(10, 246, 41, 27, "⌠", false, S3D.window[1])
        S3D.button[58] = guiCreateButton(51, 246, 41, 27, "⌡", false, S3D.window[1])
        S3D.button[59] = guiCreateButton(92, 246, 41, 27, "♪", false, S3D.window[1])
        S3D.button[60] = guiCreateButton(133, 246, 41, 27, "亗", false, S3D.window[1])
        S3D.button[61] = guiCreateButton(174, 246, 41, 27, "!", false, S3D.window[1])
        S3D.button[62] = guiCreateButton(215, 246, 41, 27, "✔", false, S3D.window[1])
        S3D.button[63] = guiCreateButton(256, 246, 41, 27, "╚►", false, S3D.window[1])

        S3D.edit[1] = guiCreateEdit(85, 278, 139, 32, "", false, S3D.window[1])
        guiEditSetReadOnly(S3D.edit[1], true)
		
        S3D_Suppr = guiCreateButton(229, 277, 48, 33, "مسح", false, S3D.window[1])
        S3D_SetNick = guiCreateButton(85, 314, 139, 33, "اختيار الزخرفة", false, S3D.window[1])
        S3D_DeltedNick = guiCreateButton(85, 353, 139, 33, "ازالة الزخرفة", false, S3D.window[1])
        S3D_Open1 = guiCreateButton(85, 391, 139, 33, "اختصارات جاهزة", false, S3D.window[1])
        S3D_Open2 = guiCreateButton(85, 429, 139, 33, "ألوان الشات", false, S3D.window[1])
        S3D_Close = guiCreateButton(247, 439, 52, 23, "X", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiSetProperty(S3D.window[1], "CaptionColour", "ffff0066")
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
centerWindow(S3D.window[1],2,2)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D_Suppr, 'NormalTextColour', 'FFFFFF00') 
guiSetProperty(S3D_SetNick, 'NormalTextColour', 'FFFFFF00') 
guiSetProperty(S3D_DeltedNick, 'NormalTextColour', 'FFFFFF00') 
guiSetProperty(S3D_Open1, 'NormalTextColour', 'FFFFFF00') 
guiSetProperty(S3D_Open2, 'NormalTextColour', 'FFFFFF00') 
guiSetProperty(S3D_Close, 'NormalTextColour', 'FFFFFF00') 
end
end )
addEventHandler("onClientGUIClick",root, function() 
if source == S3D_Close then 
guiSetVisible(S3D.window[1],false) 
showCursor(false) 
end end )
addEventHandler('onClientGUIClick',root, function()
if source == S3D_Open1 then
guiSetVisible((S3D.window[1]),false)
showCursor(false)
executeCommandHandler ( "s3d_binds" ) 
end end )
addEventHandler('onClientGUIClick',root, function()
if source == S3D_Open2 then
guiSetVisible((S3D.window[1]),false)
showCursor(false)
executeCommandHandler ( "لون" ) 
end end )
bindKey( Key, 'down', function(  )
guiSetVisible( S3D.window[1], not guiGetVisible( S3D.window[1] ) )
showCursor( guiGetVisible( S3D.window[1] ) ) 
end )
addEventHandler("onClientGUIClick",root,
function(char)
if ( source == S3D.button[1]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Á")
elseif ( source == S3D.button[2]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ɓ")
elseif ( source == S3D.button[3]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ƈ")
elseif ( source == S3D.button[4]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ɗ")
elseif ( source == S3D.button[5]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Є")
elseif ( source == S3D.button[6]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Բ")
elseif ( source == S3D.button[7]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ɠ")
elseif ( source == S3D.button[8]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ӈ") 
elseif ( source == S3D.button[9]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ĩ") 
elseif ( source == S3D.button[10]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."ʝ") 
elseif ( source == S3D.button[11]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ƙ") 
elseif ( source == S3D.button[12]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."L") 
elseif ( source == S3D.button[13]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."ℓ") 
elseif ( source == S3D.button[14]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ẍ") 
elseif ( source == S3D.button[15]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Μ") 
elseif ( source == S3D.button[16]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."η") 
elseif ( source == S3D.button[17]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ő") 
elseif ( source == S3D.button[18]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."P") 
elseif ( source == S3D.button[19]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."S") 
elseif ( source == S3D.button[20]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Q") 
elseif ( source == S3D.button[21]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ŕ") 
elseif ( source == S3D.button[22]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ś") 
elseif ( source == S3D.button[23]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ť") 
elseif ( source == S3D.button[24]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ú") 
elseif ( source == S3D.button[25]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."V") 
elseif ( source == S3D.button[26]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ŵ") 
elseif ( source == S3D.button[27]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ӽ") 
elseif ( source == S3D.button[28]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ɣ") 
elseif ( source == S3D.button[29]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."ž") 
elseif ( source == S3D.button[30]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."室") 
elseif ( source == S3D.button[31]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."❥") 
elseif ( source == S3D.button[32]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."✱") 
elseif ( source == S3D.button[33]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."»") 
elseif ( source == S3D.button[34]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ʒ") 
elseif ( source == S3D.button[35]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1..".") 
elseif ( source == S3D.button[36]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."Ƹ") 
elseif ( source == S3D.button[37]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."✖") 
elseif ( source == S3D.button[38]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."«") 
elseif ( source == S3D.button[39]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."▓") 
elseif ( source == S3D.button[40]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."『") 
elseif ( source == S3D.button[41]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."』") 
elseif ( source == S3D.button[42]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.." ๑") 
elseif ( source == S3D.button[43]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."♥") 
elseif ( source == S3D.button[44]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."✔") 
elseif ( source == S3D.button[45]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."ֆ") 
elseif ( source == S3D.button[46]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."▌") 
elseif ( source == S3D.button[47]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."̉1") 
elseif ( source == S3D.button[48]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."2") 
elseif ( source == S3D.button[49]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."3") 
elseif ( source == S3D.button[50]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."4") 
elseif ( source == S3D.button[51]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."5") 
elseif ( source == S3D.button[52]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."6") 
elseif ( source == S3D.button[53]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."7") 
elseif ( source == S3D.button[54]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."8") 
elseif ( source == S3D.button[55]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."9") 
elseif ( source == S3D.button[56]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."0") 
elseif ( source == S3D.button[57]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."⌠") 
elseif ( source == S3D.button[58]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."⌡") 
elseif ( source == S3D.button[59]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."♪") 
elseif ( source == S3D.button[60]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."亗") 
elseif ( source == S3D.button[61]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."!") 
elseif ( source == S3D.button[62]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."✔") 
elseif ( source == S3D.button[63]  ) then
local text1 = guiGetText ( S3D.edit[1] )
guiSetText(S3D.edit[1],text1.."╚►") 
elseif ( source == S3D_Suppr  ) then
local tx=guiGetText ( S3D.edit[1] )
local text1 = deleteLastCharacter(tx)
if #tx>0 then
outputChatBox("تم المسح",0,255,0,true)
else
outputChatBox('خطأ:لايوجد زخرفة',255,0,0,true)
end
guiSetText(S3D.edit[1],text1) 
elseif ( source == S3D_SetNick  ) then
local tx=guiGetText ( S3D.edit[1] )
if #tx>=5 then
if #tx>25 then outputChatBox('الحد الأقصى لنك 25 حرف ..',255,0,0,true) return end
triggerServerEvent('addTag',localPlayer,tx)
else
outputChatBox("يجب أن لايكون النك أقل من 3 حروف ..",255,0,0,true)
end
elseif ( source == S3D_DeltedNick  ) then
triggerServerEvent('removeTag',localPlayer,tx)
end end )