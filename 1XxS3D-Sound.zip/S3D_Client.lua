﻿local Rroot = getResourceRootElement(getThisResource())

local Serials ={ 
["ADF9CD5FAD7B12DC2962329449623AA2"] = true,
["-"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
}

S3D = {
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}


S3D.window[1] = guiCreateWindow(584, 273, 361, 386, "-| Serials Add : Wzrah Sound System |-", false)
S3D.label[1] = guiCreateLabel(11, 79, 43, 17, "Serial :", false, S3D.window[1])
S3D.gridlist[1] = guiCreateGridList(11, 102, 341, 203, false, S3D.window[1])
guiGridListAddColumn(S3D.gridlist[1], "Serial", 1.2)
S3D.edit[1] = guiCreateEdit(79, 315, 224, 26, "", false, S3D.window[1])
S3D.button[1] = guiCreateButton(31, 351, 136, 24, "اضافة | Add", false, S3D.window[1])
S3D.button[2] = guiCreateButton(195, 351, 136, 24, "حذف | Delate", false, S3D.window[1])
S3D.button[3] = guiCreateButton(313, 28, 29, 29, "X", false, S3D.window[1])
-- S3D.window[2] = guiCreateWindow(548, 367, 370, 213, "-| Wzrah تفعيل حسابات التاجات الخاصة |-", false)
-- S3D.label[2] = guiCreateLabel(30, 65, 55, 16, "Account :", false, S3D.window[2])
-- S3D.edit[2] = guiCreateEdit(96, 58, 169, 33, "", false, S3D.window[2])
-- S3D.button[4] = guiCreateButton(112, 101, 139, 25, "اضافة حساب", false, S3D.window[2])
-- S3D.button[5] = guiCreateButton(112, 136, 139, 25, "حذف حساب", false, S3D.window[2])
-- S3D.button[6] = guiCreateButton(112, 171, 139, 25, "X", false, S3D.window[2])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
-- guiSetVisible(S3D.window[2], false)
guiWindowSetSizable(S3D.window[1], false)
-- guiWindowSetSizable(S3D.window[2], false)
guiSetAlpha(S3D.window[1], 1)
-- guiSetAlpha(S3D.window[2], 1)
guiSetProperty(S3D.window[1], "CaptionColour", "FF00FED7")
-- guiSetProperty(S3D.window[2], "CaptionColour", "FF7C9039")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF56FF40")
guiSetProperty(S3D.button[2], "NormalTextColour", "FFFF0000")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFFEFC00") 
---
-- guiSetProperty(S3D.button[4], "NormalTextColour", "FF56FF40")
-- guiSetProperty(S3D.button[5], "NormalTextColour", "FFFF0000")
-- guiSetProperty(S3D.button[6], "NormalTextColour", "FFFFFFFF") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(v, 253, 66, 66)
end end ) 

addEventHandler("onClientGUIClick",resourceRoot, 
function() 
if (source == S3D.button[3]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(S3D.window[1], false) 
elseif (source == S3D.button[1]) then
local serial = guiGetText(S3D.edit[1])
if ( serial == '' or guiEditGetCaretIndex( S3D.edit[1] ) < 32 or guiEditGetCaretIndex( S3D.edit[1] ) > 32 ) then exports.infobox:outputMessage('يوجد خلل فني ف السكريبت',50,255,0,true) return end 
if ( serial == '') then return end  triggerServerEvent('AddSerial_Roma1', localPlayer, serial) 
elseif (source == S3D.button[2] ) then
local tounsi_text = guiGridListGetSelectedItem(S3D.gridlist[1])
if ( tounsi_text ~= -1) then
local tounsi_remove = guiGridListGetItemText(S3D.gridlist[1], tounsi_text, 1)
triggerServerEvent( 'RemoveSerial_Roma1', localPlayer, tounsi_remove )
else 
exports.infobox:outputMessage('يرجى أختيار الاعب من القائمة', 240,255,0, false) 
end
end
end )

addEventHandler("onClientGUIClick",resourceRoot, 
function() 
if (source == S3D.button[6]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(S3D.window[2], false) 
elseif source==S3D.button[4] then
local acc=guiGetText(S3D.edit[2])
if acc=='' then exports.infobox:outputMessage('قم كتابة أسم الحساب',255,255,255,true) return end
triggerServerEvent('addPlrMusicacc',localPlayer,acc)
elseif source==S3D.button[5] then
local acc=guiGetText(S3D.edit[2])
if acc=='' then outputChatBox('#ff0000* please enter valid account',255,255,255,true) return end
triggerServerEvent('RemovePlrMusicacc',localPlayer,acc)
end
end )

addEvent('Refresh_Roma1',true)
addEventHandler('Refresh_Roma1',root,
function(TagData)
guiGridListClear(S3D.gridlist[1])
for i, v in ipairs (TagData) do
local Row = guiGridListAddRow(S3D.gridlist[1])
local TheSerial = guiGridListSetItemText(S3D.gridlist[1], Row, 1, TagData[i].PlayerSerial, false, false)
end end)

addEvent('List_Dev',true) 
addEventHandler('List_Dev',root, 
function()
guiGridListClear(S3D.gridlist[1])
end )

addCommandHandler('s3d_sound', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1])) 
showCursor(guiGetVisible(S3D.window[1])) 
guiSetInputEnabled(guiGetVisible(S3D.window[1])) 
triggerServerEvent('Rom_GetAllfuck', localPlayer) 
triggerServerEvent('Active_Rom1', localPlayer)
triggerServerEvent('ActiveSerialsAllAccount_Dev', localPlayer)
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )