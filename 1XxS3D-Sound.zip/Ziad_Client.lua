﻿local subTrackOnSoundDown = 0.1	-- The volume that goes down, when the player clicks "Volume -"
local subTrackOnSoundUp = 0.1	-- The volume that goes up, when the player clicks "Volume +"

Ziad_list = {
{"1- Look At Me Now", "https://j.top4top.io/m_1673kpicq1.mp3"},
{"2- Escuro", "https://b.top4top.io/m_1673ajry01.mp3"},
{"3- Such a Whore", "https://g.top4top.io/m_1673if7m81.mp3"},
}

local xSound = nil
local sound = false
function print ( message, r, g, b )
	outputChatBox ( message, r, g, b )
end

local Rroot = getResourceRootElement(getThisResource())

Ziad = {
    edit = {},
    button = {},
    window = {},
    staticimage = {},
    label = {},
-- memo = {}
    gridlist = {}
}


Ziad.window[1] = guiCreateWindow(529, 242, 377, 427, ":: T.S | Sound System | لوحة الصوتيات | T.S ::", false)
Ziad.label[7] = guiCreateLabel(55, 16, 263, 17, "_________________________________________", false, Ziad.window[1])
Ziad.button[1] = guiCreateButton(252, 43, 115, 30, ": تشغيل الصوت :", false, Ziad.window[1])
Ziad.edit[1] = guiCreateEdit(11, 43, 226, 30, "رابط الاغنية المراد تشغيلها [ MP3 ]", false, Ziad.window[1])
guiSetFont(Ziad.edit[1], "default-bold-small")
guiSetAlpha(Ziad.edit[1], 0.75)
Ziad.button[2] = guiCreateButton(252, 94, 115, 30, ": أيقاف الصوت :", false, Ziad.window[1])
Ziad.button[3] = guiCreateButton(131, 94, 115, 30, "رفع الصوت [ + ]", false, Ziad.window[1])
Ziad.button[4] = guiCreateButton(10, 94, 115, 30, "خفض الصوت [ - ]", false, Ziad.window[1])
Ziad.label[1] = guiCreateLabel(134, 134, 108, 18, ":: قـوانـيـن الـنـظـام ::", false, Ziad.window[1])
Ziad.gridlist[1] = guiCreateGridList(10, 162, 357, 174, false, Ziad.window[1])
guiGridListAddColumn(Ziad.gridlist[1], "#", 0.9)
Ziad.button[5] = guiCreateButton(332, 395, 35, 22, "X", false, Ziad.window[1])
Ziad.label[2] = guiCreateLabel(10, 402, 137, 13, "Created By : MR.ROMCIS", false, Ziad.window[1])
Ziad.label[3] = guiCreateLabel(55, 375, 263, 17, "_________________________________________", false, Ziad.window[1])
Ziad.button[6] = guiCreateButton(17, 346, 344, 29, "طريقة الحصول على رابط التشغيل الصوتي [ MP3 ]", false, Ziad.window[1])

Ziad.window[2] = guiCreateWindow(548, 314, 373, 271, ":: T.M | شرح نظام الصوتيات | T.M ::", false)

Ziad.label[4] = guiCreateLabel(39, 18, 294, 15, "_______________________________________________________", false, Ziad.window[2])
memo = guiCreateMemo(18, 47, 336, 171, "للحصول على رابط MP3 لتشغيل النظام اتبع الخطوات التالية :\n\nلتحميل رابط صوتي من اليوتيوب عن طريق الموقع التالي \nytmp3cc.cc\n\nومن ثم قم برفع الاغنية من جهازك الى موقع top4top\n\nنضيفه رابط مصغر وبعدها ضع الرابط داخل اللوحة \nواضغط على تشغيل الصوت", false, Ziad.window[2])
guiMemoSetReadOnly(memo, true)
guiSetFont(memo, "default-bold-small")
Ziad.label[5] = guiCreateLabel(39, 218, 294, 15, "_______________________________________________________", false, Ziad.window[2])
Ziad.button[7] = guiCreateButton(306, 243, 58, 18, "Back >", false, Ziad.window[2])
Ziad.label[6] = guiCreateLabel(8, 243, 141, 18, "Created By : MR.ROMCIS", false, Ziad.window[2])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(Ziad.window[1], false)
guiWindowSetSizable(Ziad.window[1], false)
guiSetAlpha(Ziad.window[1], 1)
guiSetProperty(Ziad.window[1], "CaptionColour", "FFFD8300")
guiSetVisible(Ziad.window[2], false)
guiWindowSetSizable(Ziad.window[2], false)
guiSetAlpha(Ziad.window[2], 1)
guiSetProperty(Ziad.window[2], "CaptionColour", "FFFF0000")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(Ziad.button[1], "NormalTextColour", "FF05FD00")
guiSetProperty(Ziad.button[2], "NormalTextColour", "FFFC0000")
guiSetProperty(Ziad.button[3], "NormalTextColour", "FFFD8300")
guiSetProperty(Ziad.button[4], "NormalTextColour", "FFFD8300")
guiSetProperty(Ziad.button[5], "NormalTextColour", "FFF90000")
guiSetProperty(Ziad.button[6], "NormalTextColour", "FFFD8300")  
guiSetProperty(Ziad.button[7], "NormalTextColour", "FF00FF00") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(Ziad.label[1], 249, 0, 0)
guiLabelSetColor(Ziad.label[2], 127, 127, 127)    
guiLabelSetColor(Ziad.label[3], 255, 0, 0)
guiLabelSetColor(Ziad.label[4], 0, 255, 255)
guiLabelSetColor(Ziad.label[5], 0, 255, 255)
guiLabelSetColor(Ziad.label[6], 127, 127, 127)    
guiLabelSetColor(Ziad.label[7], 255, 0, 0)    
end end ) 

for i,GR in ipairs(Ziad_list) do
    local row = guiGridListAddRow(Ziad.gridlist[1])
    guiGridListSetItemText(Ziad.gridlist[1],row,1,GR[1],false,false)
    guiGridListSetItemData(Ziad.gridlist[1],row,1, GR[2])
end

function click ()
if source == Ziad.gridlist[1] then
   guiSetText (Ziad.edit[1], "رابط الاغنية المراد تشغيلها [ MP3 ]" )
      end
       local row,col = guiGridListGetSelectedItem(Ziad.gridlist[1])
       if ( row and col and row ~= -1 and col ~= -1 ) then 
       local Text = guiGridListGetItemData ( Ziad.gridlist[1], guiGridListGetSelectedItem ( Ziad.gridlist[1] ), 1 )
       guiSetText (Ziad.edit[1], Text )
   end
end
 addEventHandler("onClientGUIClick", resourceRoot, click )

addEventHandler("onClientGUIClick",resourceRoot, 
function() 
if (source == Ziad.button[5]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(Ziad.window[1], false) 
end
end )

function Ziad_Change1()
if ( source == Ziad.button[7] ) then
guiSetVisible(Ziad.window[2],false)
guiSetVisible( Ziad.window[1], true )
end
end
addEventHandler( 'onClientGUIClick', resourceRoot, Ziad_Change1 )

function Ziad_Change()
if ( source == Ziad.button[6] ) then
guiSetVisible(Ziad.window[1],false)
guiSetVisible( Ziad.window[2], true )
end
end
addEventHandler( 'onClientGUIClick', resourceRoot, Ziad_Change )

addEventHandler("onClientGUIClick",resourceRoot,function()
if ( source == Ziad.edit[1] ) then
guiSetAlpha(Ziad.edit[1], 1.00)
guiSetText( Ziad.edit[1], '' )
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,function()
if ( source == Ziad.window[1] ) then
guiSetAlpha(Ziad.edit[1], 0.75)
guiSetText( Ziad.edit[1], 'رابط الاغنية المراد تشغيلها [ MP3 ]' )
end
end
)

addCommandHandler('Sound',
function()
triggerServerEvent('Open_Roma1', localPlayer)
end)

addEvent('OpenEdittag_Roma1',true)
addEventHandler('OpenEdittag_Roma1',root,
function ()
triggerServerEvent('getAll_Roma1',localPlayer)
setElementData(localPlayer,'canpress',nil)
guiSetVisible( Ziad.window[1], not guiGetVisible( Ziad.window[1] ) )
showCursor( guiGetVisible( Ziad.window[1] ) )
guiSetInputEnabled(guiGetVisible(Ziad.window[1]))
end )

addEventHandler("onClientGUIClick",root,function()
if ( source == Ziad.button[2] ) then
if ( sound == true ) then
sound = false
if isElement(xSound) then
stopSound(xSound)
end
triggerServerEvent ( "onPlayerDestroySpeakerBox", localPlayer )
isSound = false
else
outputChatBox("[ نظام الصوتيات ]x لا توجد اغنيه",255,255,0,true)
end
end
end
)

local isSound = false

addEventHandler ( "onClientGUIClick", root, function ( )
	if ( source == Ziad.button[1] ) then
		-- if ( not isSound ) then
		 if ( not sound ) then
  -- if ( isURL ( ) ) then
			if ( guiGetText( Ziad.edit[1] ) ~= "" ) then
				triggerServerEvent ( "onPlayerPlaceSpeakerBox", localPlayer, guiGetText ( Ziad.edit[1] ), isPedInVehicle ( localPlayer ) )
				isSound = true
				sound = true
			else
exports.infobox:outputMessage("قم بأدخال الرابط أولا",0,0,255,true)
			end
      end
	elseif ( source == Ziad.button[4] ) then
    if ( isSound ) then
			local toVol = math.round ( getSoundVolume ( speakerSound [ localPlayer ] ) - subTrackOnSoundDown, 2 )
			if ( toVol > 0.0 ) then
				print ( "* %"..math.floor ( toVol * 100 ).." تم وضع الصوت الى", 0, 255, 0 )
				triggerServerEvent ( "onPlayerChangeSpeakerBoxVolume1", localPlayer, toVol )
			else
exports.infobox:outputMessage("لا يمكنك انزال الصوت أكثر من هكذا",0,0,255,true)
			end
		end
	elseif ( source == Ziad.button[3] ) then
   if ( isSound ) then
			local toVol = math.round ( getSoundVolume ( speakerSound [ localPlayer ] ) + subTrackOnSoundUp, 2 )
			if ( toVol < 1.1 ) then
				print ( "[ نظام الصوتيات ]x ("..math.floor ( toVol * 100 )..") مستوى الصوت", 0, 255, 0 )
				triggerServerEvent ( "onPlayerChangeSpeakerBoxVolume1", localPlayer, toVol )
	
			else
exports.infobox:outputMessage("لا يمكنك رفع الصوت اكثر من هكذا",0,0,255,true)
			end
		end
	end
end )

speakerSound = { }
addEvent ( "onPlayerStartSpeakerBoxSound", true )
addEventHandler ( "onPlayerStartSpeakerBoxSound", root, function ( who, url, isCar )
	if ( isElement ( speakerSound [ who ] ) ) then destroyElement ( speakerSound [ who ] ) end
	local x, y, z = getElementPosition ( who )
	speakerSound [ who ] = playSound3D ( url, x, y, z, true )
	setSoundVolume ( speakerSound [ who ], 1 )
	setSoundMinDistance ( speakerSound [ who ], 15 )
	setSoundMaxDistance ( speakerSound [ who ], 20 )
	if ( isCar ) then
		local car = getPedOccupiedVehicle ( who )
		attachElements ( speakerSound [ who ], car, 0, 5, 1 )
	end
end )

addEvent ( "onPlayerDestroySpeakerBox", true )
addEventHandler ( "onPlayerDestroySpeakerBox", root, function ( who ) 
	if ( isElement ( speakerSound [ who ] ) ) then 
		destroyElement ( speakerSound [ who ] ) 
	end
end )

--------------------------
-- Volume				--
--------------------------
addEvent ( "onPlayerChangeSpeakerBoxVolumeC1", true )
addEventHandler ( "onPlayerChangeSpeakerBoxVolumeC1", root, function ( who, vol ) 
	if ( isElement ( speakerSound [ who ] ) ) then
		setSoundVolume ( speakerSound [ who ], tonumber ( vol ) )
	end
end )

function isURL ( )
	if ( guiGetText ( Ziad.edit[1] ) ~= "" ) then
		return true
	else
		return false
	end
end

function math.round(number, decimals, method)
    decimals = decimals or 0
    local factor = 10 ^ decimals
    if (method == "ceil" or method == "floor") then return math[method](number * factor) / factor
    else return tonumber(("%."..decimals.."f"):format(number)) end
end
