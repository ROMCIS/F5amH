﻿s3d_list = {
["ROMCIS_ffs1"] = true,
["ROMCIS_laws12"] = true,
["ROMCIS_ksaos"] = true,
["ROMCIS_bh12"] = true,
["ROMCIS_nm3s"] = true,
["ROMCIS_axx10"] = true,
["ROMCIS_ccw12"] = true,
["ROMCIS_zz9x"] = true,
["ROMCIS_ss10s"] = true,
["ROMCIS_104fk"] = true,
}

s3d_2 = {
{"ROMCIS_ffs1"},
{"ROMCIS_laws12"},
{"ROMCIS_ksaos"},
{"ROMCIS_bh12"},
{"ROMCIS_nm3s"},
{"ROMCIS_axx10"},
{"ROMCIS_ccw12"},
{"ROMCIS_zz9x"},
{"ROMCIS_ss10s"},
{"ROMCIS_104fk"},
}

local Rroot = getResourceRootElement(getThisResource())

ROMCIS = {
    gridlist = {},
    button = {},
    window = {},
    edit = {},
    label = {}
}


ROMCIS.window[1] = guiCreateWindow(488, 186, 446, 507, ":: ┃ Sound System ┃ ::", false)

ROMCIS.label[1] = guiCreateLabel(69, 28, 309, 15, "أهــلا وســهلا بــكــم فــي لــوحــة عــضــويــة الــصــوتــيــات", false, ROMCIS.window[1])
ROMCIS.label[2] = guiCreateLabel(74, 53, 299, 15, "تــستــطــيع مــن خــلال هــذه الــخــاصــية ( الــعــضــويــة )", false, ROMCIS.window[1])
ROMCIS.label[3] = guiCreateLabel(32, 78, 382, 15, "يمكنك تشغيل صوتيات | اغاني لايمكن لأي شخص غيرك تشغيل الصوتيات", false, ROMCIS.window[1])
ROMCIS.label[4] = guiCreateLabel(1, 103, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1])
ROMCIS.label[5] = guiCreateLabel(0, 165, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1])
ROMCIS.button[1] = guiCreateButton(258, 124, 178, 36, "فتح لوحة الشراء", false, ROMCIS.window[1])
ROMCIS.button[2] = guiCreateButton(10, 124, 178, 36, "صورة لـ لوحة الصوتيات", false, ROMCIS.window[1])
ROMCIS.label[6] = guiCreateLabel(125, 190, 174, 17, "الرقم السري للدخول الى اللوحة :", false, ROMCIS.window[1])
ROMCIS.label[7] = guiCreateLabel(284, 223, 156, 15, "كلمة المرور :", false, ROMCIS.window[1])
ROMCIS.edit[1] = guiCreateEdit(123, 215, 151, 33, "", false, ROMCIS.window[1])
ROMCIS.button[3] = guiCreateButton(10, 215, 103, 33, "دخول", false, ROMCIS.window[1])
ROMCIS.label[8] = guiCreateLabel(30, 258, 389, 15, "ملاحظة : سيتم اعطائك الرقم السري للدخول للوحة من قبل صاحب السيرفر", false, ROMCIS.window[1])
ROMCIS.label[9] = guiCreateLabel(30, 258, 389, 15, "ملاحظة : سيتم اعطائك الرقم السري للدخول للوحة من قبل صاحب السيرفر", false, ROMCIS.window[1])
ROMCIS.label[10] = guiCreateLabel(90, 279, 270, 15, "بعد ذلك عليك أدخال الرقم السري وسيتم فتح اللوحة", false, ROMCIS.window[1])
ROMCIS.label[11] = guiCreateLabel(0, 165, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1])
ROMCIS.label[12] = guiCreateLabel(0, 294, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1])
ROMCIS.label[13] = guiCreateLabel(177, 309, 97, 15, "-[ قوانين النظام ]-", false, ROMCIS.window[1])
ROMCIS.label[14] = guiCreateLabel(76, 330, 298, 15, "الرجاء عدم تشغيل الصوتيات او الأغاني في مناطق البداية", false, ROMCIS.window[1])
ROMCIS.label[15] = guiCreateLabel(100, 349, 256, 15, "ممنوع تشغيل الصوتيات او الأغاني مخاليه للأداب", false, ROMCIS.window[1])
ROMCIS.label[16] = guiCreateLabel(10, 369, 423, 15, "  الرجاء عدم اعطاء احد الرقم السري : تحذير اللوحة مراقبة من قبل صاحب السيرفر   ", false, ROMCIS.window[1])
ROMCIS.label[17] = guiCreateLabel(0, 384, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1])
ROMCIS.label[18] = guiCreateLabel(29, 415, 26, 35, "*", false, ROMCIS.window[1])
ROMCIS.label[19] = guiCreateLabel(397, 415, 26, 35, "*", false, ROMCIS.window[1])
ROMCIS.label[20] = guiCreateLabel(120, 425, 207, 15, "The Panel Created By [ MR.ROMCIS ]", false, ROMCIS.window[1])
ROMCIS.label[21] = guiCreateLabel(10, 482, 42, 15, "@2020", false, ROMCIS.window[1])
ROMCIS.label[22] = guiCreateLabel(0, 445, 440, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[1]) 
ROMCIS.button[4] = guiCreateButton(153, 466, 103, 27, "X", false, ROMCIS.window[1])
ROMCIS.window[2] = guiCreateWindow(526, 156, 454, 527, "[ System Passwords To Sound Panel ]", false)

ROMCIS.gridlist[1] = guiCreateGridList(10, 50, 287, 463, false, ROMCIS.window[2])
guiGridListAddColumn(ROMCIS.gridlist[1], "#", 0.3)
guiGridListAddColumn(ROMCIS.gridlist[1], "Password", 0.9)
ROMCIS.label[23] = guiCreateLabel(136, 25, 171, 15, "-[ رموز دخول عضوية الصوتيات ]-", false, ROMCIS.window[2])
ROMCIS.button[5] = guiCreateButton(317, 60, 127, 33, "-[ نسخ ]-", false, ROMCIS.window[2])
ROMCIS.button[6] = guiCreateButton(317, 480, 124, 33, "X", false, ROMCIS.window[2])
ROMCIS.label[24] = guiCreateLabel(307, 150, 143, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬", false, ROMCIS.window[2])   
ROMCIS.button[7] = guiCreateButton(317, 107, 127, 33, "-[ حذف ]-", false, ROMCIS.window[2])

ROMCIS.window[3] = guiCreateWindow(569, 187, 337, 474, "عضوية الصوتيات", false)

staticimage1 = guiCreateStaticImage(16, 29, 304, 376, "info.png", false, ROMCIS.window[3])
ROMCIS.button[8] = guiCreateButton(9, 421, 318, 32, "-[ Close | أغلاق ]-", false, ROMCIS.window[3]) 

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(ROMCIS.window[1], false)
guiWindowSetSizable(ROMCIS.window[1], false)
guiSetAlpha(ROMCIS.window[1], 1.00)
guiSetProperty(ROMCIS.window[1], "CaptionColour", "FF0041FC")
guiSetVisible(ROMCIS.window[2], false)
guiWindowSetSizable(ROMCIS.window[2], false)
guiSetAlpha(ROMCIS.window[2], 1.00)
guiSetVisible(ROMCIS.window[3], false)
guiWindowSetSizable(ROMCIS.window[3], false)
guiSetAlpha(ROMCIS.window[3], 1.00)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(ROMCIS.button[1], "NormalTextColour", "FFBB4242")
guiSetProperty(ROMCIS.button[2], "NormalTextColour", "FFBB4242")
guiSetProperty(ROMCIS.button[3], "NormalTextColour", "FFBB4242")
guiSetProperty(ROMCIS.button[4], "NormalTextColour", "FFBB4242")  
guiSetProperty(ROMCIS.button[5], "NormalTextColour", "FFBB4242")
guiSetProperty(ROMCIS.button[6], "NormalTextColour", "FFBB4242") 
guiSetProperty(ROMCIS.button[7], "NormalTextColour", "FFBB4242") 
guiSetProperty(ROMCIS.button[8], "NormalTextColour", "FF00FF5F")   
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(ROMCIS.label[1], "default-bold-small")
guiLabelSetColor(ROMCIS.label[1], 0, 254, 251)
guiSetFont(ROMCIS.label[2], "default-bold-small")
guiLabelSetColor(ROMCIS.label[2], 254, 0, 137)
guiSetFont(ROMCIS.label[3], "default-bold-small")
guiLabelSetColor(ROMCIS.label[3], 0, 254, 251)
guiSetFont(ROMCIS.label[4], "default-bold-small")
guiLabelSetColor(ROMCIS.label[4], 254, 0, 137)
guiSetFont(ROMCIS.label[5], "default-bold-small")
guiLabelSetColor(ROMCIS.label[5], 254, 0, 137)
guiSetFont(ROMCIS.label[6], "default-bold-small")
guiLabelSetColor(ROMCIS.label[6], 232, 252, 0)
guiSetFont(ROMCIS.label[7], "default-bold-small")
guiLabelSetColor(ROMCIS.label[7], 236, 155, 15)
guiSetFont(ROMCIS.label[8], "default-bold-small")
guiLabelSetColor(ROMCIS.label[8], 254, 0, 137)
guiSetFont(ROMCIS.label[9], "default-bold-small")
guiLabelSetColor(ROMCIS.label[9], 254, 0, 137)
guiSetFont(ROMCIS.label[10], "default-bold-small")
guiLabelSetColor(ROMCIS.label[10], 0, 254, 251)
guiSetFont(ROMCIS.label[11], "default-bold-small")
guiLabelSetColor(ROMCIS.label[11], 254, 0, 137)
guiSetFont(ROMCIS.label[12], "default-bold-small")
guiLabelSetColor(ROMCIS.label[12], 254, 0, 137)
guiSetFont(ROMCIS.label[13], "default-bold-small")
guiLabelSetColor(ROMCIS.label[13], 236, 155, 15)
guiSetFont(ROMCIS.label[14], "default-bold-small")
guiLabelSetColor(ROMCIS.label[14], 11, 253, 0)
guiSetFont(ROMCIS.label[15], "default-bold-small")
guiLabelSetColor(ROMCIS.label[15], 11, 253, 0)
guiSetFont(ROMCIS.label[16], "default-bold-small")
guiLabelSetColor(ROMCIS.label[16], 11, 253, 0)
guiSetFont(ROMCIS.label[17], "default-bold-small")
guiLabelSetColor(ROMCIS.label[17], 254, 0, 137)
guiSetFont(ROMCIS.label[18], "sa-header")
guiLabelSetColor(ROMCIS.label[18], 11, 253, 0)
guiSetFont(ROMCIS.label[19], "sa-header")
guiLabelSetColor(ROMCIS.label[19], 11, 253, 0)
guiSetFont(ROMCIS.label[20], "default-bold-small")
guiSetFont(ROMCIS.label[21], "default-bold-small")
guiSetFont(ROMCIS.label[22], "default-bold-small")
guiLabelSetColor(ROMCIS.label[22], 254, 0, 137)  
guiSetFont(ROMCIS.label[23], "default-bold-small")
guiLabelSetColor(ROMCIS.label[23], 254, 0, 137) 
guiSetFont(ROMCIS.label[24], "default-bold-small")
guiLabelSetColor(ROMCIS.label[24], 254, 0, 137)
end end ) 

for i,GS in ipairs(s3d_2) do
    local row = guiGridListAddRow(ROMCIS.gridlist[1])
	guiGridListSetItemText(ROMCIS.gridlist[1],row,1,''..i..'-',false,false)
    guiGridListSetItemText(ROMCIS.gridlist[1],row,2,GS[1],false,false)
    guiGridListSetItemData(ROMCIS.gridlist[1],row,2, GS[2])
guiSetFont( ROMCIS.gridlist[1] , "default-bold-small")
	guiGridListSetItemColor(ROMCIS.gridlist[1],row,1,255, 255, 0)
	guiGridListSetItemColor(ROMCIS.gridlist[1],row,2,120, 170, 112)
end

addEventHandler("onClientGUIClick",resourceRoot,
function( )
if ( source == ROMCIS.button[5] ) then
local sel = guiGridListGetSelectedItem(ROMCIS.gridlist[1])
if sel ~= -1 then
local text = guiGridListGetItemText(ROMCIS.gridlist[1], sel, 2)
setClipboard(text)
exports["infobox"]:outputMessage ("Ctrl + V تم نسخ هذا السطر بنجاح | للصق !",math.random(0,255),math.random(0,255),math.random(0,155))
else
exports["infobox"]:outputMessage ("يرجى تحديد سطر للانساخ",math.random(0,255),math.random(0,255),math.random(0,155))
end
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[2] ) then
guiSetVisible(ROMCIS.window[1], false)
guiSetVisible(ROMCIS.window[3], true)
elseif ( source == ROMCIS.button[8] ) then
guiSetVisible(ROMCIS.window[1], true)
guiSetVisible(ROMCIS.window[3], false)
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[4] ) then
guiSetVisible(ROMCIS.window[1], false)
showCursor(false)
elseif ( source == ROMCIS.button[6] ) then
guiSetVisible(ROMCIS.window[2], false)
showCursor(false)
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,function()
if source == ROMCIS.button[7] then
local sel = guiGridListGetSelectedItem( ROMCIS.gridlist[1] ) --جلب من القريت لست
local aSoking = guiGridListGetItemText(ROMCIS.gridlist[1],sel,2) -- احظار مكان الكلمة اذا كان في قصمين
if sel ~= -1 then -- يتحقق اذا كان محدد
guiGridListRemoveRow ( ROMCIS.gridlist[1], sel )
exports["infobox"]:outputMessage ("تم حذف هذا السطر بنجاح  !",math.random(0,255),math.random(0,255),math.random(0,155))
else
exports["infobox"]:outputMessage ("يرجى تحديد سطر للحذف",math.random(0,255),math.random(0,255),math.random(0,155))
end
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function()
if ( source == ROMCIS.button[3] ) then
local acc=guiGetText(ROMCIS.edit[1])
if acc=='' then exports.infobox:outputMessage('خطأ قم بأدخال الرقم السري [ Sound ]',0,255,0,source) return end
local Text = guiGetText(ROMCIS.edit[1])
if s3d_list[Text] then
exports.infobox:outputMessage('Welcome To [ Sound System ]',0,255,0,source)
guiSetVisible(Ziad.window[1],true)
guiSetVisible(ROMCIS.window[1],false)
guiSetText( ROMCIS.label[7], 'تهانينا كلمة المرور صحيحة !' )
else
exports.infobox:outputMessage('الرقم السري خطأ [ Sound ]',0,255,0,source)
end
end
end
)

addCommandHandler('صوتيات',
function()
if (guiGetVisible(ROMCIS.window[1]) == true) then
guiSetVisible(ROMCIS.window[1],false)
showCursor(false)
else
guiSetVisible(ROMCIS.window[1],true)
showCursor(true)
end
end
)