local Serials = {
["ADF9CD5FAD7B12DC2962329449623AA2"] = true,
["-"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
["Your Serial"] = true,
}

addCommandHandler('edit.sound',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('عذرآ انت لا تمتلك الخاصية . . !', 255, 0, 0, true) return end
guiSetVisible(ROMCIS.window[2],not guiGetVisible(ROMCIS.window[2]))
showCursor(guiGetVisible(ROMCIS.window[2]))
end)