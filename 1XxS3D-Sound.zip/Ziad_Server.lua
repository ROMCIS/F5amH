﻿local TheDb = dbConnect('sqlite', 'ROMCISA_Serials.db')
local db=dbConnect('sqlite','ROMCISA_Account.db')

dbExec(TheDb, ' CREATE TABLE IF NOT EXISTS `InformationRom` (PlayerSerial) ' )
dbExec(db,'CREATE TABLE IF NOT EXISTS YeahNice (acc TEXT, tag TEXT, isactive TEXT,color TEXT,isactive2 TEXT)')

function getPlayerFromSerial ( serial )
assert ( type ( serial ) == "string" and #serial == 32, "getPlayerFromSerial - invalid serial" )
for index, player in ipairs ( getElementsByType ( "player" ) ) do
if ( getPlayerSerial ( player ) == serial ) then
return player
end
end
return  false
end

function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEvent('AddSerial_Roma1',true)
addEventHandler('AddSerial_Roma1',root,
function( serial )
local SerialCheck = getPlayerFromSerial( serial )
if (SerialCheck == nil or not SerialCheck) then return OutPut('يجب على المستخدم الدخول !', source, 255,0,0, false) end
local CheckResults = dbQuery( TheDb, ' SELECT * FROM `InformationRom` WHERE PlayerSerial = ? ', serial )
local GetData = dbPoll( CheckResults, -1 )
if ( type ( GetData ) == 'table' and #GetData == 0 or not GetData ) then
dbExec(TheDb, ' INSERT INTO `InformationRom` (PlayerSerial) VALUES(?) ', serial)
OutPut('(sound) : رمز بأف8 ('..serial..') : تم تفعيل السريال', source, 50,255,0, false)
romcis_refresh()
else
OutPut('! تم تفعيل السريال مسبقا يرجى الإنتباه', source, 240,255,0, false)
end end)

function romcis_refresh()
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationRom` ' )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return triggerClientEvent('List_Dev', source) end
triggerClientEvent(source, "Refresh_Roma1", source, checkData)
end
addEvent( 'Active_Rom1', true )
addEventHandler( 'Active_Rom1', root, romcis_refresh)

addEvent('RemoveSerial_Roma1',true)
addEventHandler('RemoveSerial_Roma1',root,
function( SerialRemove )
local SerialCheck = getPlayerFromSerial( SerialRemove )
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationRom` WHERE PlayerSerial = ? ', SerialRemove )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return end
dbExec(TheDb, ' DELETE FROM `InformationRom` WHERE PlayerSerial = ? ', SerialRemove )
OutPut('تم إزالة السريال !', source, 50,255,0, false)
romcis_refresh()
end)

addEvent('getAll_Roma1',true)
addEventHandler('getAll_Roma1',root,function()
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice'),-1)
triggerClientEvent(source,'PlayerGridlist_Dev',source,sel)
end)

addEvent('Open_Roma1',true)
addEventHandler('Open_Roma1',root,
function( )
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationRom` WHERE PlayerSerial = ? ', getPlayerSerial(source) )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return end
triggerClientEvent(source ,'OpenEdittag_Roma1', source)
end)

--------- Sound

local isSpeaker = false

function print ( player, message, r, g, b )
	outputChatBox ( message, player, r, g, b )
end

speakerBox = { }
addCommandHandler ( "-898980-0", function ( thePlayer  )
	if ( isElement ( speakerBox [ thePlayer] ) ) then isSpeaker = true end
	triggerClientEvent ( thePlayer, "onPlayerViewSpeakerManagment", thePlayer, isSpeaker )
end )

addEvent ( "onPlayerPlaceSpeakerBox", true )
addEventHandler ( "onPlayerPlaceSpeakerBox", root, function ( url, isCar ) 
	if ( url ) then
		if ( isElement ( speakerBox [ source ] ) ) then
			local x, y, z = getElementPosition ( speakerBox [ source ] ) 
			print ( source, "Destroyed old speaker located at: "..math.floor ( x )..", "..math.floor ( y )..", "..math.floor ( z ), 255, 0, 0 )
			destroyElement ( speakerBox [ source ] )
			removeEventHandler ( "onPlayerQuit", source, destroySpeakersOnPlayerQuit )
		end
		local x, y, z = getElementPosition ( source )
		local rx, ry, rz = getElementRotation ( source )
		speakerBox [ source ] = createObject ( 2229, x-0.5, y+0.5, z - 1, 0, 0, rx )
		print ( source, "Speaker box placed at "..math.floor ( x )..", "..math.floor ( y )..", "..math.floor ( z ), 0, 255, 0 )
		addEventHandler ( "onPlayerQuit", source, destroySpeakersOnPlayerQuit )
		triggerClientEvent ( root, "onPlayerStartSpeakerBoxSound", root, source, url, isCar )
		if ( isCar ) then
			local car = getPedOccupiedVehicle ( source )
			attachElements ( speakerBox [ source ], car, -0.7, -1.5, -0.5, 0, 90, 0 )
		end
	end
end )

addEvent ( "onPlayerDestroySpeakerBox", true )
addEventHandler ( "onPlayerDestroySpeakerBox", root, function ( )
	if ( isElement ( speakerBox [ source ] ) ) then
		destroyElement ( speakerBox [ source ] )
		triggerClientEvent ( root, "onPlayerDestroySpeakerBox", root, source )
		removeEventHandler ( "onPlayerQuit", source, destroySpeakersOnPlayerQuit )
		print ( source, "Speaker box has been removed.", 255, 0, 0 )
	else
		print ( source, "", 255, 255, 0 )
	end
end )

addEvent ( "onPlayerChangeSpeakerBoxVolume1", true ) 
addEventHandler ( "onPlayerChangeSpeakerBoxVolume1", root, function ( to )
	triggerClientEvent ( root, "onPlayerChangeSpeakerBoxVolumeC1", root, source, to )
end )

function destroySpeakersOnPlayerQuit ( )
	if ( isElement ( speakerBox [ source ] ) ) then
		destroyElement ( speakerBox [ source ] )
		triggerClientEvent ( root, "onPlayerDestroySpeakerBox", root, source )
	end
end