﻿GUIEditor = {
    button = {},
    window = {},
    scrollbar = {},
    label = {}
}

function centerWindow(center_window)
  local screenW, screenH = guiGetScreenSize()
  local windowW, windowH = guiGetSize(center_window, false)
  local x, y = (screenW - windowW) / 2, (screenH - windowH) / 2
  guiSetPosition(center_window, x, y, false)
end

        GUIEditor.window[1] = guiCreateWindow(330, 104, 229, 344, "نافذه فتح ابواب السيارة #", false)
        guiWindowSetSizable(GUIEditor.window[1], false)
        guiSetAlpha(GUIEditor.window[1], 0.95)
        guiSetProperty(GUIEditor.window[1], "CaptionColour", "FFFF0000")

        GUIEditor.label[1] = guiCreateLabel(87, 22, 50, 15, "الكـبوت #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[1], 0, 255, 251)
        GUIEditor.scrollbar[1] = guiCreateScrollBar(19, 41, 193, 15, true, false, GUIEditor.window[1])
        GUIEditor.label[2] = guiCreateLabel(77, 72, 73, 15, "باب السائق #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[2], 0, 255, 251)
        GUIEditor.label[3] = guiCreateLabel(9, 56, 221, 16, "---------------------------------------------------------", false, GUIEditor.window[1])
        GUIEditor.scrollbar[2] = guiCreateScrollBar(19, 91, 193, 15, true, false, GUIEditor.window[1])
        guiScrollBarSetScrollPosition(GUIEditor.scrollbar[2], 100.0)
        GUIEditor.label[4] = guiCreateLabel(5, 106, 231, 15, "-----------------------------------------------------------", false, GUIEditor.window[1])
        GUIEditor.label[5] = guiCreateLabel(62, 121, 117, 15, "الراكب بجنب السائق #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[5], 0, 255, 251)
        GUIEditor.scrollbar[3] = guiCreateScrollBar(19, 142, 193, 15, true, false, GUIEditor.window[1])
        GUIEditor.label[6] = guiCreateLabel(5, 157, 235, 15, "------------------------------------------------------------------", false, GUIEditor.window[1])
        GUIEditor.label[7] = guiCreateLabel(63, 172, 116, 15, "باب خلف السائق #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[7], 0, 255, 251)
        GUIEditor.scrollbar[4] = guiCreateScrollBar(19, 193, 194, 15, true, false, GUIEditor.window[1])
        GUIEditor.label[8] = guiCreateLabel(0, 208, 240, 15, "----------------------------------------------------------", false, GUIEditor.window[1])
        GUIEditor.label[9] = guiCreateLabel(53, 218, 128, 15, "باب خلف جانب السائق #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[9], 0, 255, 251)
        GUIEditor.scrollbar[5] = guiCreateScrollBar(20, 239, 193, 15, true, false, GUIEditor.window[1])
        GUIEditor.label[10] = guiCreateLabel(0, 254, 240, 15, "------------------------------------------------------------", false, GUIEditor.window[1])
        GUIEditor.label[11] = guiCreateLabel(90, 264, 63, 15, "الشـنطه #", false, GUIEditor.window[1])
        guiLabelSetColor(GUIEditor.label[11], 0, 255, 251)
        GUIEditor.scrollbar[6] = guiCreateScrollBar(21, 284, 192, 15, true, false, GUIEditor.window[1])
        GUIEditor.button[1] = guiCreateButton(43, 310, 140, 24, "إغلاق |#| Close", false, GUIEditor.window[1])
        guiSetProperty(GUIEditor.button[1], "NormalTextColour", "FFE4FF00")    
centerWindow ( GUIEditor.window[1] )
setElementData(GUIEditor.scrollbar[1], "Type", 0)
setElementData(GUIEditor.scrollbar[2], "Type", 2)
setElementData(GUIEditor.scrollbar[3], "Type", 3)
setElementData(GUIEditor.scrollbar[4], "Type", 4)
setElementData(GUIEditor.scrollbar[5], "Type", 5)
setElementData(GUIEditor.scrollbar[6], "Type", 1)
guiSetVisible(GUIEditor.window[1], false)



addCommandHandler('openDoor',
	function()
		local vis = not guiGetVisible(GUIEditor.window[1])
		guiSetVisible(GUIEditor.window[1],vis)
		showCursor(vis)
	end
)

function closeButton()
	guiSetVisible(GUIEditor.window[1], false)
	showCursor(false)
end
addEventHandler ( "onClientGUIClick", GUIEditor.button[1], closeButton, false )

function updateRatio(Scrolled)
	local position = guiScrollBarGetScrollPosition(Scrolled)
	local door = getElementData(Scrolled, "Type")
	local vehicle = getPedOccupiedVehicle(localPlayer)	
	if door and vehicle then
		triggerServerEvent("moveThisShit", getLocalPlayer(), door, position)
	end	
end
addEventHandler("onClientGUIScroll", resourceRoot, updateRatio)