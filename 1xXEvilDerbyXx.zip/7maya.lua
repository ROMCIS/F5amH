﻿buttons = {
    ['F1'] = true,
	['F3'] = true,
    ['b'] = true,
        ['p'] = true,
        ['F7'] = true,
    ['F9'] = true,
        ['F10'] = true,
    ['F12'] = true,
        ['F5'] = true,
    ['F4'] = true,
        ['F6'] = true,
    [']'] = true,
        ['m'] = true,
    ['x'] = true,
        ['z'] = true,
    ['i'] = true,
        ['b'] = true,
}

 
addEventHandler( 'onClientKey', root, function (button , prees)
    if prees and getElementDimension(localPlayer) == 30 then
        if buttons[button] then
                         -- outputChatBox("* غير مصرح لك بأستخدام اللوحة",0,255,0)
                         outputChatBox("* غير مصرح لك بأستخدام اللوحة",source,0,255,0,true)

            cancelEvent()
        end
    end
end)