function getCount()
c = 0 
for k,v in ipairs ( getElementsByType ( "player" ) ) do 
if ( getElementData(v,"onCrossMap") == "yes" )  then 
c = c + 1 
end 
end 
return c 
end

local Rroot = getResourceRootElement(getThisResource())
local ids = { 411 , 477 , 470 } 
S3D = {
    gridlist = {},
    button = {},
    window = {},
    checkbox = {},
    label = {}
}

S3D.window[1] = guiCreateWindow(471, 304, 515, 353, ":: Control Panel Of Derby System ::", false)

S3D.gridlist[1] = guiCreateGridList(10, 36, 278, 131, false, S3D.window[1])
guiSetFont(S3D.gridlist[1], "default-bold-small")
guiGridListAddColumn(S3D.gridlist[1], "ID:", 0.9)
S3D.button[1] = guiCreateButton(311, 36, 182, 43, "اختيار السيارة", false, S3D.window[1])
S3D.button[2] = guiCreateButton(311, 98, 182, 43, "تشغيل النيترو", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(348, 161, 103, 16, "( تغير لون سيارتك )", false, S3D.window[1])
S3D.checkbox[1] = guiCreateCheckBox(418, 202, 48, 15, "اختيار", true, false, S3D.window[1])
S3D.checkbox[2] = guiCreateCheckBox(324, 202, 48, 15, "اختيار", true, false, S3D.window[1])
S3D.checkbox[3] = guiCreateCheckBox(418, 247, 48, 15, "اختيار", true, false, S3D.window[1])
S3D.checkbox[4] = guiCreateCheckBox(324, 247, 48, 15, "اختيار", false, false, S3D.window[1])
S3D.label[2] = guiCreateLabel(335, 272, 131, 19, "꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊꞊", false, S3D.window[1])
S3D.button[3] = guiCreateButton(314, 297, 182, 36, "X", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(20, 204, 237, 18, "┃┃ سيسمح لك بتغير لون موترك كل 30 ثانية ┃┃", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(10, 328, 107, 15, "Created By RoMciS", false, S3D.window[1])
for _, v in ipairs ( ids ) do 
local row = guiGridListAddRow (S3D.gridlist[1])
guiGridListSetItemText(S3D.gridlist[1],row,1,getVehicleNameFromID(v),false,false)
guiGridListSetItemText(S3D.gridlist[1],row,2,v,false,false)
guiGridListSetItemColor(S3D.gridlist[1], row, 1, 33, 9, 254, 255)
end

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
for _, v in ipairs(getElementsByType('gui-checkbox',Rroot)) do
guiCheckBoxSetSelected( v, false )
guiSetProperty(S3D.checkbox[1], "NormalTextColour", "FFFD0000")
guiSetProperty(S3D.checkbox[2], "NormalTextColour", "FF05FC00")
guiSetProperty(S3D.checkbox[3], "NormalTextColour", "FF1100FB")
guiSetProperty(S3D.checkbox[4], "NormalTextColour", "FFFEEF00")
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FFFEEF00")
guiSetProperty(S3D.button[2], "NormalTextColour", "FFFEEF00")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFFD0000")
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(S3D.label[1], 0, 251, 253)
guiLabelSetColor(S3D.label[2], 0, 251, 253)
guiLabelSetColor(S3D.label[3], 5, 252, 0)
guiSetFont(v, "default-bold-small")
end end ) 

addEvent ( "openRent:derby" , true )
addEventHandler("openRent:derby",root,function()
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1]))
showCursor(guiGetVisible(S3D.window[1]))
end ) ; 

addEventHandler ( "onClientGUIClick" , root , function ( )
if ( source == S3D.button[3] ) then 
guiSetVisible(S3D.window[1],false)
showCursor(false)
elseif ( source == S3D.button[1] ) then 
if ( guiGridListGetSelectedItem ( S3D.gridlist[1] ) ~= -1 ) then 
triggerServerEvent ( "appleCommand:derby" , localPlayer , "CarChange" , guiGridListGetItemText ( S3D.gridlist[1] ,guiGridListGetSelectedItem ( S3D.gridlist[1] ),1))
end
elseif ( source == S3D.button[2] ) then 
triggerServerEvent ( "appleCommand:derby" , localPlayer , "Nitro" )
elseif ( source == S3D.checkbox[1] ) then 
if guiCheckBoxGetSelected (source) then
guiSetEnabled(source,false) setTimer(guiSetEnabled,15000,1,S3D.checkbox[1],true)
triggerServerEvent ( "appleCommand:derby" , localPlayer , "Color" )
  end
elseif ( source == S3D.checkbox[2] ) then 
if guiCheckBoxGetSelected (source) then
guiSetEnabled(source,false) setTimer(guiSetEnabled,15000,1,S3D.checkbox[2],true)
triggerServerEvent ( "appleCommand:derby" , localPlayer , "Color2" )
  end
elseif ( source == S3D.checkbox[3] ) then 
if guiCheckBoxGetSelected (source) then
guiSetEnabled(source,false) setTimer(guiSetEnabled,15000,1,S3D.checkbox[3],true)
triggerServerEvent ( "appleCommand:derby" , localPlayer , "Color3" )
  end
elseif ( source == S3D.checkbox[4] ) then 
if guiCheckBoxGetSelected (source) then
guiSetEnabled(source,false) setTimer(guiSetEnabled,15000,1,S3D.checkbox[4],true)
triggerServerEvent ( "appleCommand:derby" , localPlayer , "Color4" )
  end
end
end ) ; 