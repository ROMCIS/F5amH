﻿local allowed = { 
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, 
["8D869BF1C7B595F57F550B9817600584"] = true,
}

addEvent ( "appleCommand:derby" , true )
addEventHandler ( "appleCommand:derby" , root , function ( ty , id )
if ( ty == "Nitro" ) then 
if ( getPedOccupiedVehicle ( source ) ) then 
addVehicleUpgrade (getPedOccupiedVehicle(source),1010)
end 
elseif ( ty == "Color" ) then 
if ( getPedOccupiedVehicle ( source ) ) then 
local r, g, b = 255, 0, 0
setVehicleColor( getPedOccupiedVehicle(source), r, g, b )
end
elseif ( ty == "Color2" ) then 
if ( getPedOccupiedVehicle ( source ) ) then 
local r, g, b = 100, 255, 0
setVehicleColor( getPedOccupiedVehicle(source), r, g, b )
end
elseif ( ty == "Color3" ) then 
if ( getPedOccupiedVehicle ( source ) ) then 
local r, g, b = 0, 108, 255
setVehicleColor( getPedOccupiedVehicle(source), r, g, b )
end
elseif ( ty == "Color4" ) then 
if ( getPedOccupiedVehicle ( source ) ) then 
local r, g, b = 255, 255, 0
setVehicleColor( getPedOccupiedVehicle(source), r, g, b )
end
elseif ( ty == "CarChange" ) then 
if ( getPedOccupiedVehicle ( source ) and isElement(getElementData(source,"carDerby")) ) then 
setElementModel ( getElementData(source,"carDerby") , tonumber(id))
end
end
end ) ; 

addCommandHandler ( "Change" , function ( player ) 
if ( allowed[getPlayerSerial(player)] ) then 
triggerClientEvent ( player , "openRent:derby" , player )
end
end ) ;