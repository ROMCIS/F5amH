﻿player = {} ;
spawns = {} ; 
maps,selectMap = {
[1] = "map/mapnew1",
[2] = "map/mapfas2",
[3] = "map/mapfas3",
[4] = "map/map1",
[5] = "map/map2",
[6] = "map/map3",
[7] = "map/map4",
},0

local mapCar = {
[1] = 502,
[2] = 502,
[3] = 495,
[4] = 495,
[5] = 502,
[6] = 495,
[7] = 502,
}

s3d_serials = {
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- سعد
['3CF46E6436232FC5C3B880FCA0013DE4'] = true, -- خمر الروقي
};

setElementData(resourceRoot,"map","no")
setElementData(resourceRoot,"winMoney","0")
addEventHandler("onPlayerChat",getRootElement(),function(message)
local acc = getPlayerAccount ( source )
	local vehicle = getPedOccupiedVehicle(targetPlayer)
if tostring(message) == "ديربي" and checkDuel(source) == "prestart" and ( not checkExistPlrOnDuel(source) )   then
		if getPedOccupiedVehicle(source) then return
OutPut('الرجاء النزول من السيارة للعب', source, 255, 255, 0, true) end
if isGuestAccount ( acc ) then return exports.killmessages:outputMessage('فضلا قم بتسجيل دخولك اولا للعب بالديربي', source, 255, 255, 255, true) end
    if   getAccountData(getPlayerAccount(source),'derbban') then
	if string.find(message,"ديربي") then
return end
end
setPedGravity(source,0.008)

addEventHandler( 'onPlayerLogin', root,
function(_, acc)
if (acc) then
if (getAccountData(acc, "derwin") ~= 0) and (getAccountData(acc, "derplay") ~= 0) then
setElementData(source, "derwin", getAccountData(acc, "derwin"))
setElementData(source, "derplay", getAccountData(acc, "derplay"))
else
setAccountData(acc, "derwin", 0)
setAccountData(acc, "derplay", 0)
setElementData(source, "derwin", 0)
setElementData(source, "derplay", 0)
end end end )

addEventHandler( 'onPlayerQuit', root,
function()
local accPlayer = getPlayerAccount(source)
if (accPlayer) then
setAccountData(accPlayer, "derwin", getElementData(source, "derwin"))
setAccountData(accPlayer, "derplay", getElementData(source, "derplay"))
end end )



online = countPlayersOnDerby()
if tonumber(online)+1 < 32 then
setData(source,"onCrossMap","yes")
outputChatBox( "... يـرجى الأنتظار",source,0,255,0,true)
setD(source)
spawnOnMap(source)
if ( not isGuestAccount ( getPlayerAccount ( source ) ) ) then 
setAccountData ( getPlayerAccount ( source ) , "derplay" , (getAccountData (getPlayerAccount(source),"derplay") or 0 )+1)
setElementData ( source , "derplay" , getAccountData (getPlayerAccount(source),"derplay") )
end
else
exports.killmessages:outputMessage("لم يوجد مكان في الديربي",source,0,255,0,true)
end
end end)
function checkDuel(p)
if tostring(getElementData(resourceRoot,"map")) == "yes" then
elseif tostring(getElementData(resourceRoot,"map")) == "no" then
outputChatBox( "الديـربي يعـمل حاليا نـرجو الأنتظار",p,255,0,0,true)
end
return tostring(getElementData(resourceRoot,"map"))
end
function checkExistPlrOnDuel(p)
per = getElementData(p,"onCrossMap")
if tostring(per) == "yes" then
return true
else
return false
end
end
function setData(element,key,vlr)
setElementData(element,key,vlr)
end
function setD(element)
setElementDimension(element,30)
end
function spawnOnMap(p)
count = countPlayersOnDerby()
spawned = "no"
for i,data in pairs(spawns)do
if tonumber(data.id) == tonumber(count) then
spawned = "yes"
v = createVehicle(mapCar[selectMap] or 502,data.x,data.y,data.z,data.rx,data.ry,data.rz)
setElementDimension(v,30)
setElementFrozen(v,true)
setElementData(v,"creatorDerby","yes")
break
end
end
if spawned == "no" then
randomS = math.random("1","32")
for i,data in pairs(spawns)do
if tonumber(data.id) == tonumber(randomS) then
v = createVehicle(mapCar[selectMap] or 502,data.x,data.y,data.z,data.rx,data.ry,data.rz)
setElementDimension(v,30)
setElementFrozen(v,true)
setElementData(v,"creatorDerby","yes")
break
end end
end
toggleControl(p,"enter_exit", false ) 
warpPedIntoVehicle(p,v)
setElementData(p,"carDerby",v)
setCameraTarget(p,p)
end
function countPlayersOnDerby()
c = -1
for i,p in pairs(getElementsByType("player"))do
if checkExistPlrOnDuel(p) then
c = c+1
end
end 
return tonumber(c)
end
function eventCheck ()
if checkExistPlrOnDuel(source) then
toggleControl(source,"enter_exit",true ) 
setData(source,"onCrossMap","no")
checkEnd()
end
end
addEventHandler("onPlayerWasted",getRootElement(),eventCheck)
addEventHandler("onPlayerQuit",getRootElement(),eventCheck)
addEventHandler("onPlayerJoin",getRootElement(),function()
outputChatBox("",source,255,255,0,true)
setData(source,"onCrossMap","no")
end)
for i,p in pairs(getElementsByType("player"))do
setData(p,"onCrossMap","no")
end
function checkEnd()
c = 0
for i,p in pairs(getElementsByType("player"))do
if checkExistPlrOnDuel(p) then
c = c+1
winner = p
end end
if tonumber(c) == 1 then
givePlayerMoney(winner,tonumber(getElementData(resourceRoot,"winMoney")))
n = string.gsub(getPlayerName(winner), "#%x%x%x%x%x%x", "")
outputChatBox( "#c0c0c0* * * * الفائز بالديربي [ " .. n .. " ]#ff0000  ولقد ربح = #f8f800(" .. tonumber(getElementData(resourceRoot,"winMoney")) .. ")  * * *" ,getRootElement(),0,0,0,true)
outputChatBox( "تهانينا لقد ربحت بالديربي وحصلت على مبلغ " .. tonumber(getElementData(resourceRoot,"winMoney")) .. "$",n,0,255,0,true)
setElementData(resourceRoot,"map","no")
if ( not isGuestAccount ( getPlayerAccount ( winner ) ) ) then 
setAccountData ( getPlayerAccount ( winner ) , "derwin" , (getAccountData (getPlayerAccount(winner),"derwin") or 0 )+1)
setElementData ( winner , "derwin" , getAccountData (getPlayerAccount(winner),"derwin") )
end
endDerby()
setTimer(newDuel,30000,1)
end
end
function newDuel()
for i,p in pairs(getElementsByType("player"))do
setData(p,"onCrossMap","no")
end
setElementData(resourceRoot,"map","prestart")
if ( selectMap == 7 ) then selectMap = 0 end 
selectMap = selectMap + 1  
onStartLoadSpawns ( maps[selectMap] )
exports.killmessages:outputMessage("بدأ الديربي يرجا الكتابة : ديربي للدخول",getRootElement(),0,255,0,true)
RMoney = math.random("50000","300000")
setElementData(resourceRoot,"winMoney",tonumber(RMoney))
exports.killmessages:outputMessage("الفائز بالديربي سوف يحصل على $ " .. RMoney .. " ",getRootElement(),0,0,255,true)
setTimer(checkPlrs,30000,1)
end

-- addCommandHandler("s3d_start",
-- function (thePlayer)
--  local name = getPlayerName(thePlayer)
-- if ( s3d_serials[getPlayerSerial( thePlayer )] ) then 
-- for i,p in pairs(getElementsByType("player"))do
-- setData(p,"onCrossMap","no")
-- end
-- setElementData(resourceRoot,"map","prestart")
-- if ( selectMap == 7 ) then selectMap = 0 end 
-- -- onStartLoadSpawns ( maps[selectMap] )
-- exports.killmessages:outputMessage("بدأ الديربي يرجا الكتابة : ديربي للدخول",getRootElement(),0,255,0,true)
-- RMoney = math.random("50000","300000")
-- setElementData(resourceRoot,"winMoney",tonumber(RMoney))
-- exports.killmessages:outputMessage("الفائز بالديربي سوف يحصل على $ " .. RMoney .. " ",getRootElement(),0,0,255,true)
-- outputChatBox("#00FFE8*#FFFFFF" ..name .. " : تم تشغيل الديربي من قبل صاحب السيرفر",getRootElement(),0,255,0,true)
-- setTimer(checkPlrs,30000,1)
-- else
-- outputChatBox('يجب ان تمتلك صلاحية الادمنية',thePlayer,255,0,0,true)
-- end
-- end)

-- addCommandHandler("s3d_stop",
-- function (thePlayer)
--  local name = getPlayerName(thePlayer)
-- if ( s3d_serials[getPlayerSerial( thePlayer )] ) then 
-- setElementData(resourceRoot,"map","no")
-- outputChatBox("#00FFE8*#FFFFFF" ..name .. " #FF0000: تم اغلاق الديربي من قبل صاحب السيرفر",getRootElement(),255,0,0,true)
-- endDerby()
-- setTimer(newDuel,60000,1)
-- else
-- outputChatBox('يجب ان تمتلك صلاحية الادمنية',thePlayer,255,0,0,true)
-- end
-- end)

function checkPlrs ()
c = 0
for i,p in pairs(getElementsByType("player"))do
if checkExistPlrOnDuel(p) then
c = c+1
end end
if tonumber(c) > 1 then
setElementData(resourceRoot,"map","yes")
for i,p in pairs(getElementsByType("player"))do
if checkExistPlrOnDuel(p) then
setElementCollisionsEnabled(getPedOccupiedVehicle(p),true)
outputChatBox("! يـرجى التحرك الآن فقط بدأ الديربي",p,255,255,0,true)
setElementFrozen(getPedOccupiedVehicle(p),false)
end end
else
endDerby()

setElementData(resourceRoot,"map","no")
outputChatBox("لايوجد عدد كافي من اللاعبين لبدء الديربي",getRootElement(),196,255,77,true)
setTimer(newDuel,60000,1)
end
end
setTimer(newDuel,3000,1)

 
function onStartLoadSpawns ( nameMap1 )
nameMap = nameMap1
file = fileOpen(nameMap..".map")
localFile = ( fileExists ( nameMap..".xml" ) and fileOpen(nameMap..".xml") or fileCreate ( nameMap..".xml" ) )
fileWrite(localFile,"")
data = fileRead(file,999999)
fileWrite(localFile,data)
fileClose(localFile)
xml = xmlLoadFile(nameMap..".xml")
c = 0
for i,data in pairs(xmlNodeGetChildren(xml)) do
if  xmlNodeGetName(data) == "spawnpoint" then
c = c+1
v,xx,yy,zz,rxx,ryy,rzz = xmlNodeGetAttribute(data,"vehicle"),xmlNodeGetAttribute(data,"posX"),xmlNodeGetAttribute(data,"posY"),xmlNodeGetAttribute(data,"posZ"),xmlNodeGetAttribute(data,"rotX"),xmlNodeGetAttribute(data,"rotY"),xmlNodeGetAttribute(data,"rotZ")
table.insert(spawns,{id = c,model = v,x = xx,y = yy,z = zz,rx = rxx,ry = ryy,rz = rzz})
end
end
for i,data in pairs(xmlNodeGetChildren(xml)) do
if  xmlNodeGetName(data) == "object" then
m,xx,yy,zz,rxx,ryy,rzz = xmlNodeGetAttribute(data,"model"),xmlNodeGetAttribute(data,"posX"),xmlNodeGetAttribute(data,"posY"),xmlNodeGetAttribute(data,"posZ"),xmlNodeGetAttribute(data,"rotX"),xmlNodeGetAttribute(data,"rotY"),xmlNodeGetAttribute(data,"rotZ")
object = createObject(m,xx,yy,zz,rxx,ryy,rzz)
setElementDimension(object,30)
end end
end

function endDerby()
spawns = { };
for i,p in pairs(getElementsByType("player"))do
if checkExistPlrOnDuel(p) then
killPed(p)
end end
for i,v in pairs(getElementsByType("vehicle"))do
if getElementData(v,"creatorDerby") then
destroyElement(v)
end end
for k,v in ipairs ( getElementsByType("object",resourceRoot)) do 
destroyElement(v)
end
end

setTimer(function()
for i,p in pairs(getElementsByType("player"))do
sea(p)
resetHan(p)
checkVeh(p)
end
end,1000,0)

function sea(p)
if checkExistPlrOnDuel(p) then
x,y,z = getElementPosition(p)
if tonumber(z) <= 0 then
killPed(p)
end
end
end
function checkVeh(p)
if (tonumber(getElementDimension(p)) == 30) and not (isPedInVehicle(p))then
killPed(p)
end
end
function resetHan(p)
if checkExistPlrOnDuel(p) then
setVehicleHandling (getPedOccupiedVehicle(p), true )
end
end

addEvent( "Warning", true )
function Warningg ()
outputChatBox( "لا يمكنك الغش في الديربي !", source, 255, 218, 199 )
end
addEventHandler ( "Warning", getRootElement(), Warningg )


function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end