function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true,
["1A5AE4945A35897595921B1F48DE5854"] = true,
}

exports.xXScoreboard:addScoreboardColumn('Level') -- خليهم كذا
exports.xXScoreboard:addScoreboardColumn('Kills') -- خليهم كذا

player = {} ;

addEventHandler( 'onPlayerLogin', root,
function(_, acc)
if (acc) then
if (getAccountData(acc, "Level") ~= 0) and (getAccountData(acc, "Kills") ~= 0) then
setElementData(source, "Level", getAccountData(acc, "Level"))
setElementData(source, "Kills", getAccountData(acc, "Kills"))
else
setAccountData(acc, "Level", 0)
setAccountData(acc, "Kills", 0)
setElementData(source, "Level", 0)
setElementData(source, "Kills", 0)
end end end )

addEventHandler( 'onPlayerQuit', root,
function()
local accPlayer = getPlayerAccount(source)
if (accPlayer) then
setAccountData(accPlayer, "Level", getElementData(source, "Level"))
setAccountData(accPlayer, "Kills", getElementData(source, "Kills"))
end end )

addCommandHandler('stats',
function()
      triggerClientEvent ( source, 'show', resourceRoot )
end
)

addEventHandler( 'onPlayerWasted', root,
function(_, Killer)
if Killer and (Killer ~= source) and (getElementType(Killer) == 'player') then
local accKiller = getPlayerAccount(Killer)
if (accKiller) then
setElementData(Killer, "Kills", (getElementData(Killer, "Kills") or 0) + 1)
setElementData(Killer, "LevelUP", (getElementData(Killer, "LevelUP") or 0) + 1)
if (getElementData(Killer, "LevelUP") == 25) then --
setElementData(Killer, "Level", (getElementData(Killer, "Level") or 0) + 1)
setElementData(Killer, "LevelUP", 0)
triggerClientEvent( Killer, "levelsound", Killer )
local Level = getElementData( Killer, "Level" ) or 0
outputChatBox ("[ " .. string.gsub(getPlayerName(Killer), "#%x%x%x%x%x%x", "") .. " ] #00FF00Has got +1 Level and he is on Level #FFFFFF[ " ..Level.." ]", root, 255,255, 255, true, true)
end end end end )

function GiveAndTake(player, commandName, acc, amount)
if not serials[getPlayerSerial(player)] then return end
if commandName == '+level' then
amount = tonumber(amount)
if player then
if not acc then return outputChatBox("يوجد خلل فني فالسكريبت",player,0,255,0,false) end
local AccP = getAccount(acc)
if (AccP == false) then return outputChatBox("يوجد خلل فني فالسكريبت",player,255,255,0,false) end
if not amount then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
if (AccP) then
local accGetP = getAccountPlayer(getAccount(acc))
if ( accGetP ) then
local thePlayer = getPlayerFromName ( getPlayerName (accGetP) )
setElementData(thePlayer, "Level", (getElementData(thePlayer, "Level") or 0) + amount)
local accPlayer = getPlayerAccount(thePlayer)
if not (accPlayer) then return end
setAccountData(accPlayer, "Level", getElementData(thePlayer, "Level"))
local nowHowMany = getElementData(thePlayer, "Level") or 0
outputChatBox('you Give ['..amount..'] level to ['..acc..'] and now he reach level ['..nowHowMany..'] !!',player,255,255,0)
outputChatBox('you get ['..amount..'] level from Console and now you reach level ['..nowHowMany..'] !!',thePlayer,0,255,0)
triggerClientEvent( thePlayer, "levelsound", thePlayer ) end end end end
if commandName == '-level' then
amount = tonumber(amount)
if player then
if not acc then return outputChatBox("يوجد خلل فني فالسكريبت",player,0,255,0,false) end
local AccP = getAccount(acc)
if (AccP == false) then return outputChatBox("يوجد خلل فني فالسكريبت",player,255,255,0,false) end
if not amount then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
if (AccP) then
local accGetP = getAccountPlayer(getAccount(acc))
if ( accGetP ) then
local thePlayer = getPlayerFromName ( getPlayerName (accGetP) )
if getElementData(thePlayer, "Level") == 0 or amount > getElementData(thePlayer, "Level") then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
setElementData(thePlayer, "Level", (getElementData(thePlayer, "Level") or 0) - amount)
local accPlayer = getPlayerAccount(thePlayer)
if not (accPlayer) then return end
setAccountData(accPlayer, "Level", getElementData(thePlayer, "Level"))
local nowHowMany = getElementData(thePlayer, "Level") or 0
outputChatBox('you take ['..amount..'] level from ['..acc..'] and now he is level ['..nowHowMany..'] !!',player,255,255,0)
outputChatBox('Console take ['..amount..'] level from you and now you are level ['..nowHowMany..'] !!',thePlayer,255,0,0) end end end end
if commandName == '+kill' then
amount = tonumber(amount)
if player then
if not acc then return outputChatBox("يوجد خلل فني فالسكريبت",player,0,255,0,false) end
local AccP = getAccount(acc)
if (AccP == false) then return outputChatBox("يوجد خلل فني فالسكريبت",player,255,255,0,false) end
if not amount then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
if (AccP) then
local accGetP = getAccountPlayer(getAccount(acc))
if ( accGetP ) then
local thePlayer = getPlayerFromName ( getPlayerName (accGetP) )
setElementData(thePlayer, "Kills", (getElementData(thePlayer, "Kills") or 0) + amount)
local accPlayer = getPlayerAccount(thePlayer)
if not (accPlayer) then return end
setAccountData(accPlayer, "Kills", getElementData(thePlayer, "Kills"))
local nowHowMany = getElementData(thePlayer, "Kills") or 0
outputChatBox('you Give ['..amount..'] kill to ['..acc..'] and now he reach ['..nowHowMany..'] kill !!',player,255,255,0)
outputChatBox('you get ['..amount..'] kill from Console and now you reach ['..nowHowMany..'] kill !!',thePlayer,0,255,0) end end end end
if commandName == '-kill' then
amount = tonumber(amount)
if player then
if not acc then return outputChatBox("يوجد خلل فني فالسكريبت",player,0,255,0,false) end
local AccP = getAccount(acc)
if (AccP == false) then return outputChatBox("يوجد خلل فني فالسكريبت",player,255,255,0,false) end
if not amount then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
if (AccP) then
local accGetP = getAccountPlayer(getAccount(acc))
if ( accGetP ) then
local thePlayer = getPlayerFromName ( getPlayerName (accGetP) )
if getElementData(thePlayer, "Kills") == 0 or amount > getElementData(thePlayer, "Kills") then return outputChatBox('يوجد خلل فني فالسكريبت',player,0,255,0) end
setElementData(thePlayer, "Kills", (getElementData(thePlayer, "Kills") or 0) - amount)
local accPlayer = getPlayerAccount(thePlayer)
if not (accPlayer) then return end
setAccountData(accPlayer, "Kills", getElementData(thePlayer, "Kills"))
local nowHowMany = getElementData(thePlayer, "Kills") or 0
outputChatBox('you take ['..amount..'] kill from ['..acc..'] and now he has ['..nowHowMany..'] kill !!',player,255,255,0)
outputChatBox('Console take ['..amount..'] kill from you and now you have ['..nowHowMany..'] kill !!',thePlayer,0,255,0) end end end end
end

addCommandHandler('+level',GiveAndTake)
addCommandHandler('-level',GiveAndTake)
addCommandHandler('+kill',GiveAndTake)
addCommandHandler('-kill',GiveAndTake)