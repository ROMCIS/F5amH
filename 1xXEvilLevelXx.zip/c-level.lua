--[[
g_LocalPlayer = getLocalPlayer()
g_Root = getRootElement()
g_ThisResource = getThisResource()
g_ResourceRoot = getResourceRootElement(getThisResource())
spam = false
GUIEditor_TabPanel = {}
GUIEditor_Tab = {}
GUIEditor_Button = {}
GUIEditor_Memo = {}
GUIEditor_Label = {}
GUIEditor_Grid = {}
GUIEditor_Image = {}
s3dlevel = guiCreateWindow(188,89,342,350,"====Level/Kill=== System",false)
guiSetAlpha(s3dlevel,1)
guiSetVisible(s3dlevel,false)
yurlevel = guiCreateLabel(16,31,184,22,"مستواك :",false,s3dlevel)
guiLabelSetColor(yurlevel,244,234,155)
yurkill = guiCreateLabel(15,56,176,22,"عدد القتل :",false,s3dlevel)
guiLabelSetColor(yurkill,155,255,0)
yurdeath = guiCreateLabel(15,83,208,22,"الموت :",false,s3dlevel)
guiLabelSetColor(yurdeath,255,155,127)
GUIEditor_TabPanel[1] = guiCreateTabPanel(14,112,319,229,false,s3dlevel)
show = guiCreateButton(197,38,84,97,"والقتل بالشات ظهور المستوى",false,s3dlevel)
guiSetFont(GUIEditor_Label[1],"default-bold-small")
GUIEditor_Tab[2] = guiCreateTab("ارسال المستوى ",GUIEditor_TabPanel[1])
GUIEditor_Grid[1] = guiCreateGridList(7,5,156,193,false,GUIEditor_Tab[2])
column = guiGridListAddColumn(GUIEditor_Grid[1], "Players Name", 0.85)
GUIEditor_Label[2] = guiCreateLabel(170,11,120,26,"Player Name:",false,GUIEditor_Tab[2])
guiLabelSetColor(GUIEditor_Label[2],144,155,255)
plrlevel = guiCreateEdit(164,29,148,33,"",false,GUIEditor_Tab[2])
guiEditSetReadOnly(plrlevel,true)
GUIEditor_Label[3] = guiCreateLabel(169,66,120,26,"amount Level:",false,GUIEditor_Tab[2])
guiLabelSetColor(GUIEditor_Label[3],255,0,0)
GUIEditor_Button[1] = guiCreateButton(103,-286,5,5,"",false,GUIEditor_Label[3])
amountt = guiCreateEdit(167,87,148,33,"",false,GUIEditor_Tab[2])
onsend = guiCreateButton(183,125,111,25,"ارسال مستوى",false,GUIEditor_Tab[2])
hislevel = guiCreateLabel(170,154,122,19,"مستواه:",false,GUIEditor_Tab[2])
guiLabelSetColor(hislevel,155,233,0)
hiskill = guiCreateLabel(170,173,133,18,"عدد قتله:",false,GUIEditor_Tab[2])
guiLabelSetColor(hiskill,120,133,155)
GUIEditor_Tab[3] = guiCreateTab("مساعدة",GUIEditor_TabPanel[1])
lhelp = xmlLoadFile("S3D.xml")
helpTxt = xmlNodeGetValue(lhelp)
GUIEditor_Memo[1] = guiCreateMemo(6,5,310,194,helpTxt,false,GUIEditor_Tab[3])
guiMemoSetReadOnly(GUIEditor_Memo[1],true)
close = guiCreateButton(286,26,47,47,"X",false,s3dlevel)


function refresh()
    for id, player in ipairs ( getElementsByType ( "player" ) ) do
        guiGridListSetItemText ( GUIEditor_Grid[1], guiGridListAddRow ( GUIEditor_Grid[1] ), column, getPlayerName ( player ), false, false )
    end
end
addEventHandler ( "onClientResourceStart", resourceRoot, refresh)

function update( old, new )
    if ( eventName == "onClientPlayerJoin" ) then
        guiGridListSetItemText ( GUIEditor_Grid[1], guiGridListAddRow ( GUIEditor_Grid[1] ), column, getPlayerName ( source ), false, false )
    elseif ( eventName == "onClientPlayerQuit" ) then
        for row = 0, guiGridListGetRowCount ( GUIEditor_Grid[1] ) do
            if ( guiGridListGetItemText ( GUIEditor_Grid[1], row, column ) == getPlayerName ( source ) ) then
                guiGridListRemoveRow ( GUIEditor_Grid[1], row )
                break
            end
        end
    elseif ( eventName == "onClientPlayerChangeNick" ) then
        for row = 0, guiGridListGetRowCount ( GUIEditor_Grid[1] ) do
            if ( guiGridListGetItemText ( GUIEditor_Grid[1], row, column ) == old ) then
                guiGridListSetItemText ( GUIEditor_Grid[1], row, column, new, false, false )
                break
            end
        end
    end
end
addEventHandler("onClientPlayerJoin", root, update)
addEventHandler("onClientPlayerQuit", root, update)
addEventHandler("onClientPlayerChangeNick", root, update)


function onGuiClick (button, state, absoluteX, absoluteY)
  if (source == add) then
	triggerServerEvent ("add", getLocalPlayer())
  elseif (source == onsend) then
    playerNick = guiGetText ( plrlevel ) ----player name
    amount = guiGetText ( amountt )
		triggerServerEvent ("sendLevel", getLocalPlayer(), playerNick, tonumber( amount ) )
  elseif (source == show) then
        if spam then outputChatBox("You have to wait 60 second To Use This Show",255,0,0) return end
        triggerServerEvent ("showlevel", localPlayer) --- trigger it to server side
        spam = true
        setTimer(function() spam = false end,60000,1)
    end
end
addEventHandler ("onClientGUIClick", getRootElement(), onGuiClick)

function click()
	   if  guiGridListGetSelectedItem ( GUIEditor_Grid[1] ) == -1 then return end
       local playerName = guiGridListGetItemText ( GUIEditor_Grid[1], guiGridListGetSelectedItem ( GUIEditor_Grid[1] ), 1 )
	   local target = getPlayerFromName(playerName)
       guiSetText ( plrlevel, playerName )
	   guiSetText(hislevel,"مستواه : Level "..tostring(getElementData(target,"Level") or 0 ))
	   guiSetText(hiskill,"عدد قتله : Kill "..tostring(getElementData(target,"Kills") or 0 ))
end
addEventHandler ("onClientGUIClick", GUIEditor_Grid[1], click, false)

addEvent("show", true)
addEventHandler("show", root,
    function()
		local x = exports.GameMode:getPlayerGameMode()	
		if x ~= 'Zombies' then return end
		guiSetVisible(s3dlevel, not guiGetVisible(s3dlevel))
        showCursor(guiGetVisible(s3dlevel))
		guiSetText(yurlevel,"مستواك : Level "..tonumber(getElementData(getLocalPlayer(),"Level"))or 0)
		guiSetText(yurkill,"عدد القتل : kill "..tonumber(getElementData(getLocalPlayer(),"Kills"))or 0)
		guiSetText(yurdeath,"الموت : death "..tonumber(getElementData(getLocalPlayer(),"deaths"))or 0)
    end
)

function CLOSE()
	guiSetVisible( s3dlevel, false )
	showCursor(false)
end
addEventHandler("onClientGUIClick", close, CLOSE, false)

--]]
addEvent("levelsound",true)
addEventHandler("levelsound",root,
function()
	if isElement(sound) then return end
	sound = playSound("level.mp3")
	setSoundVolume(sound, 1.0)
end)