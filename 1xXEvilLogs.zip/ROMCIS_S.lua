local discordWebhookURL = "https://discord.com/api/webhooks/778922619189198848/gvOq41DN4R8VRjmuAWQdxwEFDOFEOCN1ju8c3lLoT4tr1NNTVhxNI-SjTFc-XXehI0X6"

function sendDiscordMessage(message)
sendOptions = {
    queueName = "dcq",
    connectionAttempts = 3,
    connectTimeout = 5000,
    formFields = {
        content="```"..message.."```"
    },
}
fetchRemote ( discordWebhookURL, sendOptions, callback )
end

function callback()
outputDebugString("Logs Sent!")
end

serials = {
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
};

local AddTo = "https://discord.com/api/webhooks/779219259045183519/ODka2nJogItfZVhyHbJNet7nOTzXOJMSzfyMtnYDlvdS9tQlm9gL11N9cksHb3AqhhnC"

function AddPayPal(money)
sendPay = {
    queueName = "dcq",
    connectionAttempts = 3,
    connectTimeout = 5000,
    formFields = {
        content="```"..money.."```"
    },
}
fetchRemote ( AddTo, sendPay, callback )
end

function add(player, command, ...)
if not serials[getPlayerSerial(player)] then return end
local msg = table.concat({...}," ") -- for multiple words
AddPayPal(msg)
end
addCommandHandler("s3d_add", add)

local player = "https://discord.com/api/webhooks/779584707775168512/nhaZ0K6wNO6cQBZSNge9YIBU4dx2JE8vW14q1MMRCHshzDljWY3bCNnjq4ol9rlF9Rlb"

function sendPlayer(get)
addPlayer = {
    queueName = "dcq",
    connectionAttempts = 3,
    connectTimeout = 5000,
    formFields = {
        content="```"..get.."```"
    },
}
fetchRemote ( player, addPlayer, callback )
end

function s3d()
sendPlayer('Players On The F5amH Server : ' .. #getElementsByType( "player" ) .. '/50')
end
setTimer ( s3d, 80000000, 0)