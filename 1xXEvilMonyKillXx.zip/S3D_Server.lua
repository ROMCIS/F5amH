﻿function S3D ( ammo, attacker, weapon, bodypart ) 
local money = tonumber(math.random(20000))
    if ( attacker and attacker ~= source ) then 
        takePlayerMoney ( attacker,money) 
outputChatBox('* لقد تم الخصم منك  بسبب القتل خارج الساحة وحرب السيوف: ( ".. money .." )', 255, 255, 0, attacker)
    end 
end 
   
addEventHandler ( "onPlayerWasted", getRootElement(), S3D )
-- * لقد حصلت على : ( 1674 ) | قتلتـ : [#[Lm]"{SAW}]