GUIEditor = {
    button = {},
    edit = {},
    window = {},
    gridlist = {},
    label = {},
}
 

addEventHandler("onClientResourceStart", resourceRoot,
    function()
        GUIEditor.window[1] = guiCreateWindow(174, 120, 502, 334, "X[ لوحة تحويل النقود ]X ", false)
        guiWindowSetSizable(GUIEditor.window[1], false)
        guiSetAlpha(GUIEditor.window[1], 0.98)
        guiSetVisible(GUIEditor.window[1],false)
        guiSetProperty(GUIEditor.window[1], "CaptionColour", "FF0041FF")

        GUIEditor.edit[2] = guiCreateEdit(244, 51, 223, 25, "", false, GUIEditor.window[1])
        GUIEditor.gridlist[1] = guiCreateGridList(10, 31, 224, 293, false, GUIEditor.window[1])
        guiGridListAddColumn(GUIEditor.gridlist[1], "# Players ...", 0.9)
        GUIEditor.button[1] = guiCreateButton(244, 143, 117, 28, "=[ تحويل ]=", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.button[2], "default-bold-small")
        guiSetProperty(GUIEditor.button[2], "NormalTextColour", "FF1EDDDF")
        GUIEditor.edit[1] = guiCreateEdit(244, 108, 223, 25, "", false, GUIEditor.window[1])
        GUIEditor.label[3] = guiCreateLabel(244, 304, 94, 15, "MR.ROMCIS", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[3], "default-bold-small")
        guiLabelSetColor(GUIEditor.label[3], 0, 255, 197)   
        GUIEditor.label[2] = guiCreateLabel(332, 86, 162, 15, "قيمة المبلغ اللذي تريد تحويله :", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[2], "default-bold-small")
        guiLabelSetColor(GUIEditor.label[2], 89, 255, 0)
        GUIEditor.button[2] = guiCreateButton(442, 299, 50, 25, "X", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.button[2], "default-bold-small")
        guiSetProperty(GUIEditor.button[2], "NormalTextColour", "FFFF0000")
        GUIEditor.label[4] = guiCreateLabel(330, 304, 112, 15, "T.S", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[4], "default-bold-small")
        guiLabelSetColor(GUIEditor.label[4], 162, 0, 255)
        GUIEditor.label[5] = guiCreateLabel(244, 181, 48, 42, "*", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[5], "sa-gothic")
        guiLabelSetColor(GUIEditor.label[5], 219, 100, 35)
        GUIEditor.label[6] = guiCreateLabel(444, 240, 48, 42, "*", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[6], "sa-gothic")
        guiLabelSetColor(GUIEditor.label[6], 255, 0, 101)
        GUIEditor.label[7] = guiCreateLabel(244, 244, 48, 42, "*", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[7], "sa-gothic")
        guiLabelSetColor(GUIEditor.label[7], 6, 0, 255)
        GUIEditor.label[8] = guiCreateLabel(444, 181, 48, 42, "*", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[8], "sa-gothic")
        guiLabelSetColor(GUIEditor.label[8], 29, 255, 0)
        GUIEditor.label[9] = guiCreateLabel(310, 208, 112, 53, "T.S", false, GUIEditor.window[1])
        guiSetFont(GUIEditor.label[9], "sa-gothic")

    end
)


function RefreshGridlist ( aElement , Col )
if ( getElementType ( aElement ) == "gui-gridlist" ) then
guiGridListClear ( aElement )
Col = Col or 1
for i,v in ipairs ( getElementsByType("player") ) do
local aRow = guiGridListAddRow ( aElement )
guiGridListSetItemText ( aElement , aRow , Col , getPlayerName ( v ) , false , false )
end
end
end
 
addEventHandler("onClientGUIClick",root,
function()
if source == GUIEditor.button[2] then
guiSetVisible(GUIEditor.window[1], false)
showCursor(false)
end
end
)

function CreateSearch ( gridlist,edit )
	guiGridListClear(gridlist)
	local text = guiGetText(GUIEditor.edit[2])
	if text == "" then
		for id,player in ipairs(getElementsByType("player")) do
			local row = guiGridListAddRow(gridlist)
			guiGridListSetItemText(gridlist, row, 1, getPlayerName(player), false, false)
		end
	else
		for id,player in ipairs(getElementsByType("player")) do
		    if string.find(string.upper(getPlayerName(player)), string.upper(text), 1, true) then
			local row = guiGridListAddRow(gridlist)
				guiGridListSetItemText(gridlist, row, 1, getPlayerName(player), false, false)
			end
		end
	end
end
	
function Search()
	CreateSearch ( GUIEditor.gridlist[1] )
end
addEventHandler ("onClientGUIChanged", GUIEditor.edit[2], Search, false)



function Search()
	CreateSearch ( GUIEditor.gridlist[1] )
end
addEventHandler ("onClientGUIChanged", GUIEditor.edit[2], Search, false)

addEventHandler ( "onClientGUIClick",GUIEditor.gridlist[1], 
	function ( )
	    local playerName = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 1 )
		if ( guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ) == -1 ) then
			guiSetText(GUIEditor.edit[2],'')
		return end
		guiSetText(GUIEditor.edit[2],playerName)
	end,false
)

 
function Update ( )
RefreshGridlist ( GUIEditor.gridlist [1] )
end
addEventHandler ("onClientPlayerJoin",root,Update)
addEventHandler ("onClientPlayerChangeNick",root,Update)
addEventHandler ("onClientPlayerQuit",root,Update)
 
---------------------
 
addEventHandler("onClientGUIClick",resourceRoot, function ( )
if ( source == GUIEditor.button[1] ) then
local InfoSelected = { guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ) };
if ( InfoSelected [ 1 ] ~= -1 and guiGetText ( GUIEditor.edit[1] ) ~= "" ) then
triggerServerEvent("SendMoney",getLocalPlayer(),guiGridListGetItemText(GUIEditor.gridlist[1],InfoSelected[1],InfoSelected[2]),guiGetText(GUIEditor.edit[1]))
else
exports["infobox"]:outputMessage ("* الرجاء اختيار لاعب | Choose Player Please ..",0,255,0)
end
end
end
)

addCommandHandler('فلوس',
function()
if (guiGetVisible(GUIEditor.window[1]) == true) then
guiSetVisible(GUIEditor.window[1],false)
showCursor(false)
else
guiSetVisible(GUIEditor.window[1],true)
showCursor(true)
RefreshGridlist ( GUIEditor.gridlist [1] )
end
end
)