    addEvent("SendMoney",true)
    addEventHandler("SendMoney",root, function ( aPlayer , aPrice )
    if ( getPlayerFromName ( aPlayer ) and tonumber ( aPrice ) ) then
    if ( getPlayerFromName ( aPlayer ) == source ) then return OutPut( "* You Can't Send For YourSelf !",source, math.random(0,255),math.random(0,255),math.random(0,155)) end
    if ( getPlayerMoney ( source ) >= tonumber ( aPrice ) ) then
    givePlayerMoney ( getPlayerFromName ( aPlayer ) , tonumber ( aPrice ) )
    takePlayerMoney ( source , tonumber ( aPrice ) )
    else
    OutPut( "* ليس لديكـ المبلغ الكآفي | You don't have money",source,255,0,0)
    end
    end
    end )
     
function OutPut(message, player, r, g, b)
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEvent("server:outputMessage", true)
addEventHandler("server:outputMessage", root,
	function(message, r, g, b)
		OutPut(message, source, r, g, b)
	end
)