--By JBoy--
node = xmlLoadFile ("accounts.xml")

function playerLogin (thePreviousAccount, theCurrentAccount, autoLogin)
	if not (isGuestAccount (getPlayerAccount(source))) then
		local accountData = getAccountData (theCurrentAccount, "money")
		if (accountData) then
			local playerMoney = getAccountData(theCurrentAccount, "money")
			setPlayerMoney(source, playerMoney)
			
		else
	
		setPlayerMoney(source, 500)
		end
	end
end
addEventHandler("onPlayerLogin", getRootElement(), playerLogin)

function onQuit()
	if not (isGuestAccount (getPlayerAccount (source))) then
		account = getPlayerAccount (source)
		if (account) then
			setAccountData(account,"money", tostring(getPlayerMoney(source)))
		end
	end
end
addEventHandler("onPlayerQuit", getRootElement(), onQuit)


function m ()
setPlayerMoney(source, 0)
end
addEventHandler("onPlayerLogout", getRootElement(), m)


