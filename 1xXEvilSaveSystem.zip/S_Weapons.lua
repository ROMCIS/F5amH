﻿addEventHandler("onPlayerWasted", root,
    function()
        local weapons = convertWeaponsToJSON(source)
        setElementData(source,"tempWeapons",weapons)
    end
)
 
addEventHandler("onPlayerSpawn", root,
    function ()
        local weapons = getElementData(source,"tempWeapons")
        if (weapons) then
            giveWeaponsFromJSON(source, weapons)
        end
    end
)
 
function convertWeaponsToJSON(player)
    local weaponSlots = 12
    local weaponsTable = {}
    for slot=1, weaponSlots do
        local weapon = getPedWeapon( source, slot )
        local ammo = getPedTotalAmmo( source, slot )
        if (weapon > 0 and ammo > 0) then
            weaponsTable[weapon] = ammo
        end
    end
    return toJSON(weaponsTable)
end
 
function giveWeaponsFromJSON(player, weapons)
    if (weapons and weapons ~= "") then
        for weapon, ammo in pairs(fromJSON(weapons)) do
            if (weapon and ammo) then
                giveWeapon(player, tonumber(weapon), tonumber(ammo))
            end
        end
    end
end
