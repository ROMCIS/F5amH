﻿
        window1 = guiCreateWindow(491, 260, 473, 392, "✖  طرق الدفع  ✖", false)
        guiWindowSetSizable(window1, false)
        guiSetAlpha(window1, 0.77)
	guiSetVisible(window1,false)

        label1 = guiCreateLabel(4, 26, 467, 30, "═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ", false, window1)
        guiSetFont(label1, "default-bold-small")
        guiLabelSetColor(label1, 12, 242, 104)
        label2 = guiCreateLabel(4, 310, 467, 30, "═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ", false, window1)
        guiSetFont(label2, "default-bold-small")
        guiLabelSetColor(label2, 12, 242, 104)
        button1 = guiCreateButton(381, 349, 80, 33, "إغلاق", false, window1)
        guiSetFont(button1, "default-bold-small")
        guiSetProperty(button1, "NormalTextColour", "FFFD0000")
        label3 = guiCreateLabel(13, 334, 122, 53, "#Team F5aMh ヅ", false, window1)
        guiSetFont(label3, "default-bold-small")

        tabpanel1 = guiCreateTabPanel(18, 52, 430, 230, false, window1)
        tab1 = guiCreateTab("طرق الدفع", tabpanel1)
        memo1 = guiCreateMemo(5, 5, 419, 196, "مرحبا بك في سيرفر فخامة الهجولة\n\nطرق الدفع المتوفرة في السيرفر هي :\n\n1- PayPal\n- ( يرجى قبل التحويل التواصل مع صاحب السيرفر ) -\n\n2 - Zain - زين\n\nتحويل بنكي -3\n\nستور اماراتي -4\n\nللشراء تواصل مع صاحب السيرفر واتساب عبر رقم التالي\n\nWhatsApp : +966-", false, tab1)
        guiMemoSetReadOnly(memo1, true)

        tab2 = guiCreateTab("صاحب السيرفر", tabpanel1)
        memo2 = guiCreateMemo(5, 5, 419, 196, "#ROMCIS\n\nWhatsApp : WhatsApp : +966-", false, tab2)
        guiMemoSetReadOnly(memo2, true)

        tab3 = guiCreateTab("الأدارة", tabpanel1)
        memo3 = guiCreateMemo(5, 5, 419, 196, "MAD_MAX\n\nWhatsApp : +966-\n\n‬------------------------------------------\n\n#5Mr\n\nWhatsApp : +966-", false, tab3)
        guiMemoSetReadOnly(memo3, true)    


addEventHandler ("onClientGUIClick", root,
        function()
        if (source == button1) then
         guiSetVisible(window1, false)
         showCursor(false)
         guiSetInputEnabled(false)
        end
    end
)

addCommandHandler('دفع',
function()
if (guiGetVisible(window1) == true) then
guiSetVisible(window1,false)
showCursor(false)
else
guiSetVisible(window1,true)
showCursor(true)
end
end
)