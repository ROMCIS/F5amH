﻿ Questions_AnswerS = {
{"1- فائدة الساعات", "تفيدك في شراء ألرتب "},
{"2- كيف أترقى", "عندما تصل ساعاتك لمستوى الرتبة اللي تبيها"},
{"3- ابي بيت من وين ؟", "إسأل اي شخص عنده بيت يبيعه ولآ لآ"},
{"4- حسابي أنسرق كيف أرجعه ؟", "عبر إخبار صاحب ألسيرفر"},
{"5- كيف أطلع سيريالي ؟", "من لوحة إظهار السيريال اف 12"},
{"6- ليه إنصكيت أدمن مخالف ؟", "يمكن لآنك خالفت أمام احد الادمنيين "},
{"7- كيف أطلع موتر ؟", "عبر اف 1 - ألمواتر"},
{"8- كيف أغير وزنية السيارة", "عبر لائحة الوزنيات الجاهزة اف 3"},
{"9- كيف انتقل ؟", "من أف 6 لوحة الانتقالات"},
{"10- كيف أحمي حسابي من ألسرقة ؟", "لا تعطي كلمة سر حسابك لأي أحد كان"},
{"11- متى توزيع ألساعات ؟", "حسب قرار ألادارة "},
{"12- أنصكيت سلاب وانا اهجول ليه ؟", "بسبب عكس الطريق أو ألوقوف به"},
{"13- متى ينفك المخالف حقي ؟", "حسب ألمخالفة و مدة العقوبة المقررة"},
{"14- كيف أشتكي على واحد ؟", "من لوحة الريبورت اف 9"},
{"15- منهم مسؤولين البيوت ؟", "رومسيس ,  , وألذين يملكون صلاحيات"},
{"16- كيف أعرف ساعاتي ؟", "من لوحة Tab إضغط على تاب"},
{"17- كيف أثبت السرعة حقتي ؟", "X بالضغط على حرف"},
{"18- كيف أعرف من معهم أكثر ساعات ؟", "من لوحة أف 12 اعلى 30 تواجد"},
{"19- كيف أشغل مود ساهر ؟", "من لوحة اف 1"},
{"20- كيف أغير شكل طريق ألدائري ؟", "من لوحة أف 1 زفلت الدائري والشارع الطويل "},
{"21- كيف أعدل على الوزنية ؟", "من حرف B يمكنك التعديل عليها"},
{"22- كيف أشتري ساعات ؟", "من لوحة أف 12 شراء ألرتب والساعات"},
{"23- كيف أعدل على شكل ألسيارة ؟", "عبر ألذهاب لعلامة الورشة بالخريطة "},
{"24- كيف شتري سيارة خاصة ؟", "عبر ألذهاب للمعرض من اف 5"},
{"1- فائدة الساعات", "تفيدك في شراء ألرتب "},
{"2- كيف أترقى", "عندما تصل ساعاتك لمستوى الرتبة اللي تبيها"},
{"3- ابي بيت من وين ؟", "إسأل اي شخص عنده بيت يبيعه ولآ لآ"},
{"4- حسابي أنسرق كيف أرجعه ؟", "عبر إخبار صاحب ألسيرفر"},
{"5- كيف أطلع سيريالي ؟", "من لوحة إظهار السيريال اف 12"},
{"6- ليه إنصكيت أدمن مخالف ؟", "يمكن لآنك خالفت أمام احد الادمنيين "},
{"7- كيف أطلع موتر ؟", "عبر اف 1 - ألمواتر"},
{"8- كيف أغير وزنية السيارة", "عبر لائحة الوزنيات الجاهزة اف 3"},
{"9- كيف انتقل ؟", "من أف 6 لوحة الانتقالات"},
{"10- كيف أحمي حسابي من ألسرقة ؟", "لا تعطي كلمة سر حسابك لأي أحد كان"},
{"11- متى توزيع ألساعات ؟", "حسب قرار ألادارة "},
{"12- أنصكيت سلاب وانا اهجول ليه ؟", "بسبب عكس الطريق أو ألوقوف به"},
{"13- متى ينفك المخالف حقي ؟", "حسب ألمخالفة و مدة العقوبة المقررة"},
{"14- كيف أشتكي على واحد ؟", "من لوحة الريبورت اف 9"},
{"15- منهم مسؤولين البيوت ؟", "رومسيس ,  , وألذين يملكون صلاحيات"},
{"16- كيف أعرف ساعاتي ؟", "من لوحة Tab إضغط على تاب"},
{"17- كيف أثبت السرعة حقتي ؟", "X بالضغط على حرف"},
{"18- كيف أعرف من معهم أكثر ساعات ؟", "من لوحة أف 9 اعلى 30 تواجد"},
{"19- كيف أشغل مود ساهر ؟", "من لوحة اف 1"},
{"20- كيف أغير شكل طريق ألدائري ؟", "من لوحة أف 1 زفلت الدائري والشارع الطويل "},
{"21- كيف أعدل على الوزنية ؟", "من حرف B يمكنك التعديل عليها"},
{"22- كيف أشتري ساعات ؟", "من لوحة أف 12 شراء ألرتب والساعات"},
{"23- كيف أعدل على شكل ألسيارة ؟", "عبر ألذهاب لعلامة الورشة بالخريطة "},
{"24- كيف شتري سيارة خاصة ؟", "عبر ألذهاب للمعرض من اف 5"},
}
function OpenWindow()
    if guiGetVisible(Wind) == false then
        guiSetVisible(Wind, true)
        showCursor(true)
    else
        guiSetVisible(Wind, false)
        showCursor(false)
    end
end
addCommandHandler("OPEN",OpenWindow)
 
local screenW, screenH = guiGetScreenSize()
Wind = guiCreateWindow((screenW - 382) / 2, (screenH - 536) / 2, 382, 536, "=[ الأسئلة الشائعة ]=", false)
guiWindowSetSizable(Wind, false)
guiSetProperty(Wind, "CaptionColour", "FFFF0000")
guiSetVisible(Wind,false)
grid = guiCreateGridList(10, 25, 360, 378, false, Wind)
guiGridListAddColumn(grid, "# السؤال", 0.9)
Question_Edit = guiCreateEdit(10, 422, 360, 41, "أختر سؤال لتظهر الأجابة", false, Wind)
guiSetProperty(Question_Edit, "NormalTextColour", "FFFF0000")
guiEditSetReadOnly(Question_Edit, true)
close = guiCreateButton(116, 498, 109, 22, "=[ إغلاق ]=", false, Wind)
guiSetFont(close, "default-bold-small")
guiSetProperty(close, "NormalTextColour", "FF00FFFC")

for i,GR in ipairs(Questions_AnswerS) do
    local row = guiGridListAddRow(grid)
    guiGridListSetItemText(grid,row,1,GR[1],false,false)
    guiGridListSetItemData(grid,row,1, GR[2])
    guiGridListSetItemColor(grid,row,1,math.random(1,255),math.random(2,255),math.random(3,255))
end

addEventHandler("onClientGUIClick",root,
function ()
if source == close then
if ( guiGetVisible(Wind) == false ) then
    end
    guiSetVisible ( Wind, false )
        showCursor(false)
        guiSetInputEnabled(false)
     end
  end
)

function click ()
if source == grid then
   guiSetText (Question_Edit, "أختر سؤال لتظهر الأجابة" )
      end
       local row,col = guiGridListGetSelectedItem(grid)
       if ( row and col and row ~= -1 and col ~= -1 ) then 
       local Answers = guiGridListGetItemData ( grid, guiGridListGetSelectedItem ( grid ), 1 )
       guiSetText (Question_Edit, Answers )
   end
end
 addEventHandler("onClientGUIClick", root, click )