﻿
local Bind = "oo"
local sw,sh=guiGetScreenSize()

----------------
-- Window
----------------

GUIEditor = {
    label = {}
}
local screenW, screenH = guiGetScreenSize()
Window = guiCreateStaticImage((screenW - 456) / 2, (screenH - 313) / 2, 456, 313, "s3d.png", false)
guiSetVisible(Window,false)
GUIEditor.label[1] = guiCreateLabel(50, 32, 351, 20, "لـ حفظ مكان يجب ان يكون مكان خارجي لا يكون بيت او غيرة !!", false, Window)
guiSetFont(GUIEditor.label[1], "default-bold-small")
guiLabelSetColor(GUIEditor.label[1], 35, 210, 93)
List = guiCreateGridList(9, 80, 202, 217, false, Window)
guiGridListAddColumn(List, "المكــان", 0.9)
Close = guiCreateButton(417, 36, 29, 26, "X", false, Window)
guiSetFont(Close, "default-bold-small")
guiSetProperty(Close, "NormalTextColour", "FFD600F6")
NamePlace = guiCreateEdit(215, 83, 191, 27, "اسم المكان المراد حفظه !", false, Window)
Warp = guiCreateButton(215, 120, 194, 27, "xXx الانتقال الى المكان xXx", false, Window)
guiSetFont(Warp, "default-bold-small")
guiSetProperty(Warp, "NormalTextColour", "FF00EBE1")
Delete = guiCreateButton(215, 157, 194, 27, "xXx حذف المكان المختار xXx", false, Window)
guiSetFont(Delete, "default-bold-small")
guiSetProperty(Delete, "NormalTextColour", "FFFF0000")
Add = guiCreateButton(215, 194, 194, 27, "xXx اضافة هذا المكان xXx", false, Window)
guiSetFont(Add, "default-bold-small")
guiSetProperty(Add, "NormalTextColour", "FF00FF00")
GUIEditor.label[2] = guiCreateLabel(221, 235, 62, 18, "Mr.RoMciS", false, Window)
guiSetFont(GUIEditor.label[2], "default-bold-small")
guiLabelSetColor(GUIEditor.label[2], 237, 123, 11)
GUIEditor.label[3] = guiCreateLabel(221, 253, 72, 17, "", false, Window)
guiSetFont(GUIEditor.label[3], "default-bold-small")
guiLabelSetColor(GUIEditor.label[3], 13, 195, 234)
GUIEditor.label[4] = guiCreateLabel(221, 276, 62, 18, "", false, Window)
guiSetFont(GUIEditor.label[4], "default-bold-small")
guiLabelSetColor(GUIEditor.label[4], 86, 231, 15)

---------------
-- On Click
---------------

addEventHandler("onClientGUIClick",guiRoot,function()
	if ( source == Warp ) then
		local Select = guiGridListGetSelectedItem(List)
		local getNamePlaceFromList = guiGridListGetItemText(List,Select,1)
		if ( tostring(getNamePlaceFromList) ) then
			triggerServerEvent("WarpPlace",localPlayer,tostring(getNamePlaceFromList))
			guiSetVisible(Window,false)
			showCursor(false)
			guiSetInputEnabled(false)
		else
			outputChatBox("Please Select Place .",255,0,0,true)
		end
	elseif ( source == Delete ) then
		local Select = guiGridListGetSelectedItem(List)
		local getNamePlaceFromList = guiGridListGetItemText(List,Select,1)
		if ( tostring(getNamePlaceFromList) ) then
			triggerServerEvent("DeletePlace",localPlayer,tostring(getNamePlaceFromList))
		else
			outputChatBox("Please Select Place .",255,0,0,true)
		end
	elseif ( source == Add ) then
		local Name = guiGetText(NamePlace)
		if ( tostring(Name) and string.len(tostring(Name)) >= 1 ) then
			triggerServerEvent("AddNewPlace",localPlayer,tostring(Name))
		end
	elseif ( source == Close ) then
		guiSetVisible(Window,false)
		showCursor(false)
		guiSetInputEnabled(false)
	end
end)

-----------------------
-- Event From Server
-----------------------

addEvent("UpPleaceToList",true)
addEventHandler("UpPleaceToList",root,function(Table)
	guiGridListClear(List)
	for _,v in ipairs(Table) do
		local row = guiGridListAddRow(List)
		guiGridListSetItemText(List,row,1,tostring(v.NamePlaceT),false,false)
		guiGridListSetItemColor(List,row,1,0,255,0)
	end
end)

---------------
-- Bind Key
---------------

bindKey(Bind,"Down",function()
	if ( guiGetVisible(Window) == false ) then
		triggerServerEvent("UpPleacesOnOpenWindow",localPlayer)
	end
	guiSetVisible(Window,not guiGetVisible(Window))
	showCursor(guiGetVisible(Window))
	guiSetInputEnabled(guiGetVisible(Window))
end)

function enableVehicleControl()
 if guiGetVisible(Window) == false then
  guiSetVisible(Window, true)
  showCursor(true)
  triggerServerEvent("AddRowPlace",localPlayer,tostring(Name))
 else
  guiSetVisible(Window, false)
  showCursor(false)
 end
end
addCommandHandler("حفظ",enableVehicleControl)
-------------

addEventHandler ( "onClientResourceStart", resourceRoot,
	function (	)
			downloadFile ("cPlace.lua")
		end
	
)