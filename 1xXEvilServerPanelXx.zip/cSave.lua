﻿
GUIEditor = {
    label = {}
}
				addEventHandler("onClientResourceStart", resourceRoot,
			function()
		local screenW, screenH = guiGetScreenSize()
        Cj = guiCreateWindow((screenW - 337) / 2, (screenH - 264) / 2, 337, 264, "xXx | حــفــظ الـملابــس | xXx", false)
        guiWindowSetSizable(Cj, false)
        guiSetAlpha(Cj, 1.00)
        guiSetProperty(Cj, "CaptionColour", "FFFF0000")
		guiSetVisible(Cj,false)
        GUIEditor.label[1] = guiCreateLabel(7, 23, 271, 15, "لحفظ الملابس يجب تغيير البنطلون , الحذاء , السترة!!", false, Cj)
        guiSetFont(GUIEditor.label[1], "default-bold-small")
        guiLabelSetColor(GUIEditor.label[1], 0, 255, 0)
        Close_Cj = guiCreateButton(301, 28, 27, 24, "X", false, Cj)
        guiSetFont(Close_Cj, "default-bold-small")
        guiSetProperty(Close_Cj, "NormalTextColour", "FFA71FD9")
        GUIEditor.label[2] = guiCreateLabel(10, 238, 220, 16, "T.S | MR.RoMciS", false, Cj)
        guiSetFont(GUIEditor.label[2], "default-bold-small")
        guiLabelSetColor(GUIEditor.label[2], 250, 0, 135)
        Save_Cj = guiCreateButton(9, 67, 319, 51, "xXx | حــفــظ ملآبســـي | xXx", false, Cj)
        guiSetFont(Save_Cj, "default-bold-small")
        guiSetProperty(Save_Cj, "NormalTextColour", "FF0A66F1")
        unSaveCj = guiCreateButton(9, 128, 318, 51, "xXx | اسـتعاده ملابســي المحفــوظــة | xXx", false, Cj)
        guiSetFont(unSaveCj, "default-bold-small")
        guiSetProperty(unSaveCj, "NormalTextColour", "FF0A66F1")    
    end
)


bindKey("","down",
function ()
    guiSetVisible(Cj,not guiGetVisible(Cj))
    showCursor(guiGetVisible(Cj))
     guiMoveRightToCenter(Cj)
end)



addEventHandler ( "onClientGUIClick", root,
    function ( )
        if ( source == Save_Cj ) then
                triggerServerEvent ( "sa", localPlayer )
            end
end)

      addEventHandler ( "onClientGUIClick", root,
    function ( )
        if ( source == unSaveCj ) then
                triggerServerEvent ( "lo", localPlayer )
            end
end)



addEventHandler ("onClientGUIClick", root,
        function()
        if (source == Close_Cj) then
         guiSetVisible(Cj, false)
         showCursor(false)
         guiSetInputEnabled(false)
        end
    end
)

addCommandHandler('ملابس',
function()
if (guiGetVisible(Cj) == true) then
guiSetVisible(Cj,false)
showCursor(false)
else
guiSetVisible(Cj,true)
showCursor(true)
end
end
)

function S3DFast()
	if fileExists("cSave.lua") then
		fileDelete("cSave.lua")
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), S3DFast)
addEventHandler("onClientPlayerQuit", getRootElement(), S3DFast)
addEventHandler("onClientPlayerJoin", getRootElement(), S3DFast)