addEventHandler("onResourceStart",resourceRoot,function()
	executeSQLQuery("CREATE TABLE IF NOT EXISTS PlaceSystem (NamePlace,SerialPlr,X,Y,Z) ")
end)

addEvent("AddNewPlace",true)
addEventHandler("AddNewPlace",root,function(Name)
	local serial = getPlayerSerial(source)
	local Row = executeSQLQuery("SELECT * FROM PlaceSystem WHERE SerialPlr=?",tostring(serial))
	if ( Row and Row ~= 0 ) then
		for _,v in ipairs(Row) do
			if ( tostring(v.NamePlace) == tostring(Name) ) then
				outputChatBox("Please Choose Another Name .",source,255,0,0,true)
				return
			end
		end
	end
	local x,y,z = getElementPosition(source)
	executeSQLQuery("INSERT INTO PlaceSystem (NamePlace,SerialPlr,X,Y,Z) VALUES (?,?,?,?,?)",tostring(Name),tostring(serial),tostring(x),tostring(y),tostring(z))
	outputChatBox("Successfully Add Place [ "..tostring(Name).." ]",source,0,0,255,true)
	sendPlaceForClient(source,serial)
end)

addEvent("WarpPlace",true)
addEventHandler("WarpPlace",root,function(Name)
	local skin = getElementModel(source)
	if ( Name and string.len(Name) >= 1 ) then
		local Row = executeSQLQuery("SELECT * FROM PlaceSystem WHERE SerialPlr=? AND NamePlace=?",getPlayerSerial(source),Name)
		if ( type(Row) == "table" and Row == 0 or not Row ) then
			outputChatBox("Please Select Place .",source,255,0,0,true)
			return
		end
		spawnPlayer(source,Row[1]["X"],Row[1]["Y"],Row[1]["Z"],math.random(0,270),skin)
	else
		outputChatBox("Please Select Place .",source,255,0,0,true)
	end
end)

addEvent("UpPleacesOnOpenWindow",true)
addEventHandler("UpPleacesOnOpenWindow",root,function()
	sendPlaceForClient(source,getPlayerSerial(source))
end)

addEvent("DeletePlace",true)
addEventHandler("DeletePlace",root,function(Name)
	if ( Name and string.len(Name) >= 1 ) then
		local Row = executeSQLQuery("SELECT * FROM PlaceSystem WHERE SerialPlr=? AND NamePlace=?",getPlayerSerial(source),Name)
		executeSQLQuery("DELETE FROM PlaceSystem WHERE NamePlace =? AND X=? AND Y=? AND Z=? AND SerialPlr=?",Name,Row[1]["X"],Row[1]["Y"],Row[1]["Z"],getPlayerSerial(source))
		sendPlaceForClient(source,getPlayerSerial(source))
	end
end)

function sendPlaceForClient(plr,serial)
	local Table = {}
	for _,v in ipairs (getPleaces(serial)) do
		table.insert(Table,{NamePlaceT = v.NamePlace,})
	end
	triggerClientEvent(plr,"UpPleaceToList",plr,Table)
end

function getPleaces(Serial)
	if ( Serial and type(Serial) == "string" ) then
		local Row = executeSQLQuery("SELECT * FROM PlaceSystem WHERE SerialPlr=?",tostring(Serial))
		if ( type(Row) == "table" and #Row == 0 or not Row ) then
			return {}
		else
			return Row
		end
	end
end