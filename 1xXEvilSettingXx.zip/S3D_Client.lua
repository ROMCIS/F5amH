﻿-----------------------------------
-- Main Wnd
---------------------------------

local Rroot = getResourceRootElement(getThisResource())

S3D = {
    window = {},
    checkbox = {},
    label = {}
}

S3D.window[1] = guiCreateStaticImage(1229, 281, 201, 380, "s3d.png", false)

S3D.checkbox[1] = guiCreateCheckBox(9, 55, 168, 21, "~| زفلتة الدايري |~  ", false, false, S3D.window[1])
S3D.checkbox[2] = guiCreateCheckBox(9, 80, 168, 21, "~| زفلتة الشارع الطويل |~   ", false, false, S3D.window[1])
S3D.checkbox[3] = guiCreateCheckBox(9, 105, 168, 21, "~| الرادار المعدل |~   ", false, false, S3D.window[1])
S3D.checkbox[4] = guiCreateCheckBox(9, 130, 168, 21, "~| الجرافيكس |~   ", false, false, S3D.window[1])
S3D.checkbox[5] = guiCreateCheckBox(9, 155, 178, 21, "~| جيرافيكس السيارات |~   ", false, false, S3D.window[1])
S3D.checkbox[6] = guiCreateCheckBox(9, 180, 178, 21, "جيرافيكس الماء   ", false, false, S3D.window[1])
S3D.checkbox[7] = guiCreateCheckBox(9, 205, 178, 21, "الوضوح العآلي   ", true, false, S3D.window[1])
S3D.checkbox[8] = guiCreateCheckBox(9, 230, 178, 21, "جيرافيكس الثلج   ", true, false, S3D.window[1])
S3D.checkbox[9] = guiCreateCheckBox(9, 255, 178, 21, "جيرافيكس السماء   ", true, false, S3D.window[1])
S3D.label[1] = guiCreateLabel(30, 5, 56, 16, "الأعدادات", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(10, 30, 179, 18, "====================", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(10, 325, 179, 15, "====================", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(10, 300, 132, 16, "للتشغيل ضع علامة صح", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(10, 350, 132, 16, "MR.S3D", false, S3D.window[1]) 

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
-- centerWindow(S3D.window[1],2,2)
for _, v in ipairs(getElementsByType('gui-checkbox',Rroot)) do
guiCheckBoxSetSelected( v, false )
guiSetProperty(v, 'NormalTextColour', 'FFFF0000')
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(v, 255, 0, 0)  
end end )

bindKey("F1", "down", 
function ()
guiSetVisible(S3D.window[1], not guiGetVisible (S3D.window[1])) 
showCursor(guiGetVisible(S3D.window[1]))
end )

addEventHandler("onClientGUIClick", resourceRoot,
function()
if source == S3D.checkbox[1] then
executeCommandHandler ( "s3d_dairy" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل زفلتة الدايري]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف زفلته الدايري]",255,255,255,source)
  end
elseif source == S3D.checkbox[2] then 
executeCommandHandler ( "s3d_long" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل الشارع الطويل]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف الشارع الطويل]",255,255,255,source)
  end
elseif source == S3D.checkbox[3] then 
executeCommandHandler ( "s3d_radar" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل الرادار المعدل]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف الرادار المعدل]",255,255,255,source)
  end
elseif source == S3D.checkbox[4] then 
executeCommandHandler ( "contrast" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل الجرافيكس]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف الجرافيكس]",255,255,255,source)
  end
elseif source == S3D.checkbox[5] then
executeCommandHandler ( "StartCarShedar" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل جرافيكس السيارات]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف جرافيكس السيارات]",255,255,255,source)
  end
elseif source == S3D.checkbox[6] then 
executeCommandHandler ( "StartWater" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل جرافيكس الماء]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف جرافيكس الماء]",255,255,255,source)
  end
elseif source == S3D.checkbox[7] then 
executeCommandHandler ( "StartBloom" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل الوضوح العالي]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف الوضوح العالي]",255,255,255,source)
  end
elseif source == S3D.checkbox[8] then 
executeCommandHandler ( "groundsnow" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل جرافيكس الثلج]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف جرافيكس الثلج]",255,255,255,source)
  end
elseif source == S3D.checkbox[9] then 
executeCommandHandler ( "sDynamicSky" ) 
if guiCheckBoxGetSelected (source) then
exports["infobox"]:outputMessage("[تم تشغيل جرافيكس السماء]",255,255,255,source)
    else 
exports["infobox"]:outputMessage("[تم أيقاف جرافيكس السماء]",255,255,255,source)
  end
end
end
)

    fileDelete("S3D_Client.lua")
    nwfile = fileCreate("ROMCIS_Client.lua")
    fileWrite(nwfile,"اذكر الله :(Created By RoMciS)")
    fileClose(nwfile)