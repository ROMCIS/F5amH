﻿
GUIEditor = {
    button = {},
    staticimage = {},
    edit = {},
    label = {}
}

local screenW, screenH = guiGetScreenSize()
Editnick = guiCreateWindow((screenW - 448) / 2, (screenH - 429) / 2, 448, 429, "=[ لوحة تعديل زخرفة النك أعلى تواجد ]=", false)
guiWindowSetSizable(Editnick, false)
guiSetVisible(Editnick, false)
guiSetProperty(Editnick, "CaptionColour", "FF9AE31B")
guiSetAlpha(Editnick, 1.00)

GUIEditor.label[1] = guiCreateLabel(326, 41, 49, 20, "ملاحظة :", false, Editnick)
guiSetFont(GUIEditor.label[1], "default-bold-small")
guiLabelSetColor(GUIEditor.label[1], 0, 255, 255)
GUIEditor.label[2] = guiCreateLabel(117, 41, 194, 19, "يمنع وضع اسم مخالف أو اسم عربي.", false, Editnick)
guiSetFont(GUIEditor.label[2], "default-bold-small")
guiLabelSetColor(GUIEditor.label[2], 255, 0, 255)
Editsearch = guiCreateEdit(9, 75, 185, 27, "", false, Editnick)
GUIEditor.staticimage[1] = guiCreateStaticImage(194, 77, 27, 25, ":admin/client/images/search.png", false, Editnick)
gridlist = guiCreateGridList(9, 111, 212, 205, false, Editnick)
guiGridListAddColumn(gridlist, "Account :", 1)
GUIEditor.label[3] = guiCreateLabel(287, 111, 88, 20, "الأسم الزخرفة :", false, Editnick)
guiSetFont(GUIEditor.label[3], "default-bold-small")
guiLabelSetColor(GUIEditor.label[3], 154, 250, 4)
editnick = guiCreateMemo(226, 139, 212, 131, "", false, Editnick) 
guiSetFont(editnick, "default-bold-small")
Save = guiCreateButton(253, 280, 156, 36, "حفظ المعلومات داخل اللوحة", false, Editnick)
guiSetFont(Save, "default-bold-small")
guiSetProperty(Save, "NormalTextColour", "FFF0580D")
GUIEditor.label[4] = guiCreateLabel(360, 326, 31, 20, "تنبيه :", false, Editnick)
guiSetFont(GUIEditor.label[4], "default-bold-small")
guiLabelSetColor(GUIEditor.label[4], 0, 255, 255)
GUIEditor.label[5] = guiCreateLabel(135, 326, 203, 20, "سيسمح باتخدام زر ارسال كل 5 دقيقة!", false, Editnick)
guiSetFont(GUIEditor.label[5], "default-bold-small")
guiLabelSetColor(GUIEditor.label[5], 255, 0, 0)
GUIEditor.label[6] = guiCreateLabel(54, 356, 380, 20, "يجب لأنتهاء من جميع التعديلات وحفظ المعلومات وثم لاظغط على ارسال .", false, Editnick)
guiSetFont(GUIEditor.label[6], "default-bold-small")
guiLabelSetColor(GUIEditor.label[6], 255, 0, 0)
setnick = guiCreateButton(145, 386, 156, 32, "ارسال جميع المعلومات", false, Editnick)
guiSetFont(setnick, "default-bold-small")
guiSetProperty(setnick, "NormalTextColour", "FFF0580D")
Closex = guiCreateButton(391, 386, 48, 32, "X", false, Editnick)
guiSetFont(Closex, "default-bold-small")


addEventHandler("onClientGUIClick",root,
function()
if source == Closex then
guiSetVisible(Editnick,false) 
showCursor(false)
guiSetInputEnabled(false)
end end )  

mytable={
}

addEvent('updateTable2019',true)
addEventHandler('updateTable2019',root,function(ta)
mytable=ta
end )

thta={}

addEvent('openwindow',true)
addEventHandler('openwindow',root,function(thsel)
guiGridListClear(gridlist)
thta=thsel
if #thsel~=0 then
for k,v in ipairs(thsel)do
local row=guiGridListAddRow(gridlist)
guiGridListSetItemText(gridlist,row,1,thsel[k].acc,false,false)
end
end
guiSetInputEnabled(true)
guiSetVisible( Editnick , not guiGetVisible(Editnick))
showCursor(guiGetVisible(Editnick))
end )

addEventHandler('onClientGUIChanged',Editsearch,function()
local tx=guiGetText(Editsearch)
if tx~='' then
guiGridListClear(gridlist)
for k,v in ipairs(thta) do
if string.find(string.upper(v.acc),string.upper(tx)) then
local row=guiGridListAddRow(gridlist)
guiGridListSetItemText(gridlist,row,1,v.acc,false,false)
end
end
else
guiGridListClear(gridlist)
for k,v in ipairs(thta) do
local row=guiGridListAddRow(gridlist)
guiGridListSetItemText(gridlist,row,1,v.acc,false,false)
end
end
end	
,false)

addEventHandler('onClientGUIClick',root,function()
if source==setnick then
if isTimer(timer) then 
local mSeconds,_,__ = getTimerDetails(timer)
local total = mSeconds / 60 / 1000
outputChatBox("You need to wait "..math.ceil(total).." minutes",255, 0, 0)
return
end	
timer = setTimer(function() end,1 * 1000 * 60,1)
if getElementData(localPlayer,'saved') and getElementData(localPlayer,'saved')==true then
local sel=guiGridListGetSelectedItem(gridlist)
if sel~=-1 and guiGridListGetItemText(gridlist,sel,2)~='Not Login'  then
triggerServerEvent('setmynick',localPlayer,guiGridListGetItemText(gridlist,sel,1),guiGetText(editnick))
else
exports.infobox:outputMessage('! الرجاء قم باختيار الاعب اولى',255,0,0,true)
end
setElementData(localPlayer,'saved',nil)
else
exports.infobox:outputMessage('! الرجاء حفظ المعلومات اولى',255,0,0)
end
elseif source==Save then
setElementData(localPlayer,'saved',true)
exports.infobox:outputMessage('! تم حفظ المعلومات النك بنجاح *',math.random(255),math.random(255), math.random(255))
end end )

local OpenSerailBuy={ -- ضيف سيريالك
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["1A5AE4945A35897595921B1F48DE5854"] = true, -- فان دام
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
}

GUIEditor = {
    label = {}
}

local screenW, screenH = guiGetScreenSize()
AddAccountbuy = guiCreateWindow((screenW - 402) / 2, (screenH - 253) / 2, 402, 253, ": | F5amh@ اضافة حسابات  المشترين | :", false)
guiSetVisible(AddAccountbuy, false)
guiSetAlpha(AddAccountbuy, 1.00)

GUIEditor.label[1] = guiCreateLabel(137, 41, 190, 23, "اضافة حسابات المشترين بالخاصية :", false, AddAccountbuy)
guiSetFont(GUIEditor.label[1], "default-bold-small")
guiLabelSetColor(GUIEditor.label[1], 0, 255, 255)
GUIEditor.label[2] = guiCreateLabel(78, 41, 49, 23, "Editnick", false, AddAccountbuy)
guiSetFont(GUIEditor.label[2], "default-bold-small")
guiLabelSetColor(GUIEditor.label[2], 0, 255, 0)
GUIEditor.label[3] = guiCreateLabel(58, 60, 286, 18, "__________________________________________", false, AddAccountbuy)
GUIEditor.label[4] = guiCreateLabel(78, 92, 59, 23, "Account :", false, AddAccountbuy)
guiSetFont(GUIEditor.label[4], "default-bold-small")
guiLabelSetColor(GUIEditor.label[4], 255, 255, 0)
Editaccountbuy = guiCreateEdit((402 - 249) / 2, (253 - 38) / 2, 249, 38, "", false, AddAccountbuy)
Addaccountbuy = guiCreateButton(119, 163, 166, 27, "اضافة الحساب الى الجدول !", false, AddAccountbuy)
guiSetFont(Addaccountbuy, "default-bold-small")
guiSetProperty(Addaccountbuy, "NormalTextColour", "C800FF00")
DeletedAccountbuy = guiCreateButton(119, 210, 166, 27, "ازالة الحساب من الجدول !", false, AddAccountbuy)
guiSetFont(DeletedAccountbuy, "default-bold-small")
guiSetProperty(DeletedAccountbuy, "NormalTextColour", "FFFF0000")
closebuy = guiCreateButton(330, 207, 62, 30, "Close", false, AddAccountbuy)
guiSetFont(closebuy, "default-bold-small")    

addEventHandler( 'onClientGUIClick', root, 
function()
if (source == closebuy) then
guiSetVisible(AddAccountbuy, false)
guiSetInputEnabled(false)
showCursor(false)
elseif source==Addaccountbuy then
local text=guiGetText(Editaccountbuy)
if #text~=0 then	
outputChatBox('Done !',0,255,0)
triggerServerEvent('addTTable2019',localPlayer,text)	
else	
outputChatBox('خطا غير معروف رجاء التاكد من صحة الحساب',255,0,0)	
end
elseif source==DeletedAccountbuy then
local text=guiGetText(Editaccountbuy)
if #text~=0 then
outputChatBox('Done !',255,0,0)
triggerServerEvent('deleteTTable2019',localPlayer,text)
else	
outputChatBox('خطا غير معروف رجاء التاكد من صحة الحساب',255,0,0)	
end end end )

addCommandHandler('Editbuy',function()
if OpenSerailBuy[getPlayerSerial(localPlayer)] then
guiSetVisible(AddAccountbuy,not guiGetVisible(AddAccountbuy))
showCursor(guiGetVisible(AddAccountbuy))
guiSetInputEnabled(guiGetVisible(AddAccountbuy))
end end )