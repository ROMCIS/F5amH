﻿function centerWindow(center_window,i,v)
local screenW, screenH = guiGetScreenSize()
local windowW, windowH = guiGetSize(center_window, false)
local x, y = (screenW - windowW) / i, (screenH - windowH) / v
guiSetPosition(center_window, x, y, false)
end

-----------------------------------
-- Main Wnd
---------------------------------
local Rroot = getResourceRootElement(getThisResource())
------------
Window = guiCreateWindow(426, 220, 588, 460, "-x لوحة اعلى اللاعبين x-", false)
------------
PicTopTime = guiCreateStaticImage(12, 25, 129, 86, "1.png", false, Window)  --اعلى تواجد
PicTopDerby = guiCreateStaticImage(156, 25, 129, 86, "2.png", false, Window) --احصائيات الديربي
PicTopLike = guiCreateStaticImage(301, 25, 129, 86, "3.png", false, Window) --اعلى فلوس
PicTopLevel = guiCreateStaticImage(449, 25, 129, 86, "4.png", false, Window) --اعلى ليفل
------------
Label1 = guiCreateLabel(219, 130, 200, 18, "-| لوحة اعلى 40 تواجد حاليا |-", false, Window)
Label2 = guiCreateLabel(210, 130, 200, 18, "-| اعلى 30 احصائيات الديربي |-", false, Window)
Label3 = guiCreateLabel(210, 130, 200, 18, "-| لوحة اعلى مطانيخ السيرفر |-", false, Window)
Label4 = guiCreateLabel(210, 130, 200, 18, "-|لوحة اعلى 30 ليفل قتل حاليا |-", false, Window)
------------
ListDerby = guiCreateGridList(10, 150, 569, 260, false, Window) --ديربي
guiGridListSetSortingEnabled(ListDerby, false)	
guiGridListAddColumn(ListDerby, "#اسم اللاعب", 0.6)
guiGridListAddColumn(ListDerby, "#عدد مرات الفوز", 0.2)
guiGridListAddColumn(ListDerby, "#عدد مرات اللعب", 0.3)
------------
bankList = guiCreateGridList(10, 150, 569, 260, false, Window) --فلوس
guiGridListSetSortingEnabled(bankList, false)	
local column = guiGridListAddColumn(bankList, "#اسم اللاعب", 0.6)
guiGridListAddColumn(bankList, "#المبلغ", 0.50)
------------
ListDerby = guiCreateGridList(10, 150, 569, 260, false, Window) --ديربي
guiGridListSetSortingEnabled(ListDerby, false)	
local column1 = guiGridListAddColumn(ListDerby, "#اسم اللاعب", 0.6)
guiGridListAddColumn(ListDerby, "#عدد مرات الفوز", 0.2)
guiGridListAddColumn(ListDerby, "#عدد مرات اللعب", 0.3)
------------
ListLevel = guiCreateGridList(10, 150, 569, 260, false, Window) --ليفل
guiGridListSetSortingEnabled(ListLevel, false)	
local column2 = guiGridListAddColumn(ListLevel, "#اسم اللاعب", 0.6)
guiGridListAddColumn(ListLevel, "#عدد الليفل", 0.2)
guiGridListAddColumn(ListLevel, "#عدد القتل", 0.2)
------------
ListTime = guiCreateGridList(10, 150, 569, 260, false, Window) --تواجد
guiGridListSetSortingEnabled(ListTime, false)
guiGridListAddColumn(ListTime, "#اسم اللاعب", 0.6)
guiGridListAddColumn(ListTime, "#عدد الساعات", 0.42)
------------
Close = guiCreateButton(215, 425, 150, 24, "Close |#| اغلاق", false, Window)
guiSetFont(Close, "default-bold-small") 
guiSetProperty(Close, "NormalTextColour", "FF00FF00")

---------------------------------------------------------
-- On Start
---------------------------------------------------------
addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(Window, false)
guiSetAlpha(Window, 1.00)
centerWindow(Window,2,2)
guiSetAlpha(PicTopTime, 1)
guiSetAlpha(PicTopDerby, 0.36)
guiSetAlpha(PicTopLike, 0.36)
guiSetAlpha(PicTopLevel, 0.36)
guiSetAlpha(Label1, 1.0)
guiSetAlpha(Label2, 0.0)
guiSetAlpha(Label3, 0.0)
guiSetAlpha(Label4, 0.0)
guiSetAlpha(ListTime, 1)
guiSetAlpha(ListDerby, 0)
guiSetAlpha(bankList, 0)
guiSetAlpha(ListLevel, 0)
guiSetFont(ListTime, "default-normal")
guiSetFont(ListDerby, "default-normal")
guiSetFont(bankList, "default-normal")
guiSetFont(ListLevel, "default-normal")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, 'NormalTextColour', 'FF00FF00')
guiSetProperty(Close, 'NormalTextColour', 'FF00FF00')
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(Label1, "default-bold-small")
guiSetFont(Label2, "default-bold-small")
guiSetFont(Label3, "default-bold-small")
guiSetFont(Label4, "default-bold-small")
end end )
---------------------------------------------------------
-- On Script ROMCIS
---------------------------------------------------------
ScriptTopTime = function()
guiGridListClear(ListTime)
timeTable = {  };
for _, player in ipairs( getElementsByType( 'player' ) ) do
local plrname=getPlayerName( player )
if mytable[player] and tostring(mytable[player])~='nil' then plrname=tostring(mytable[player])end
table.insert( timeTable, { name =plrname , hour = getElementData( player, "PlayTime" ) or "0:0:0", hSort = tonumber(split(getElementData( player, "PlayTime" ) or "0:0:0", ":")[1]) or 0 } )
end
table.sort( timeTable, function(a, b)
return tonumber(a.hSort) > tonumber(b.hSort)
end )		
for i, _ in ipairs( timeTable ) do
if i>=31 then return end
local row = guiGridListAddRow( ListTime )
guiGridListSetItemText( ListTime, row, 1, "-   "..timeTable[i].name, false, false )
guiGridListSetItemText( ListTime, row, 2, timeTable[i].hour, false, false )
guiGridListSetItemColor( ListTime, row, 1, 0, 255, 255)
guiGridListSetItemColor( ListTime, row, 2, 255, 255, 255)
end end
------------
function getTopLevel(  )
levelTable = {  };
for _, player in ipairs( getElementsByType( 'player' ) ) do
local lvl = getElementData( player, 'Level' ) or '0'
local kls = getElementData( player, 'Kills' ) or '0'
table.insert( levelTable, { plr = player, Level = lvl, Kills = kls } )
end
table.sort( levelTable,
function( min, max )
return ( tonumber( min.Kills ) or '' ) > ( tonumber( max.Kills ) ), ( tonumber( min.Level ) or '' ) > ( tonumber( max.Level ) )
end )
return levelTable
end
------------
addEvent('setmyderbydata',true)
addEventHandler('setmyderbydata',root,function(ta)
guiGridListClear(ListDerby)
if #ta==0 then return end
for k=1,#ta do
if k>20 then return end
local plrname=getPlayerName(ta[k].plr)
if mytable[ta[k].plr] and tostring(mytable[ta[k].plr])~='nil' then plrname=tostring(mytable[ta[k].plr]) end
local row = guiGridListAddRow( ListDerby )
 guiGridListSetItemText( ListDerby, row, 1, k..'- '..plrname, false, false )
guiGridListSetItemText( ListDerby, row, 2, ta[k].win, false, false )
guiGridListSetItemText( ListDerby, row, 3, ta[k].play, false, false )
guiGridListSetItemColor( ListDerby, row, 1, math.random(255),math.random(255),math.random(255) )
guiGridListSetItemColor( ListDerby, row, 2, 255, 0, 0)
guiGridListSetItemColor( ListDerby, row, 3, 5, 255, 0)
end end )
------------
function ScriptTopLevel()
guiGridListClear( ListLevel )
local pLevel = getTopLevel(  )
for num = 1, #getElementsByType( 'player' ) do
if ( num >= 31 ) then return end
if ( pLevel[1] ) then
local plrname=getPlayerName( pLevel[num].plr  )
if mytable[pLevel[num].plr] and tostring(mytable[pLevel[num].plr])~='nil' then plrname=tostring(mytable[pLevel[num].plr])end
local row = guiGridListAddRow( ListLevel )
local pName = guiGridListSetItemText( ListLevel, row, 1, num..'- '..plrname, false, false )
local pValue = guiGridListSetItemText( ListLevel, row, 2, pLevel[num].Level, false, false )
local pValue2 = guiGridListSetItemText( ListLevel, row, 3, pLevel[num].Kills, false, false )
guiGridListSetItemColor( ListLevel, row, 100, 100, 100, 0)
guiGridListSetItemColor(ListLevel,row,1,math.random(0,255),math.random(0,255),math.random(0,255))
guiGridListSetItemColor( ListLevel, row, 2, 255, 0, 0) guiGridListSetItemColor( ListLevel, row, 3, 5, 255, 0)
end end end
------------
addEventHandler("onClientGUIClick", guiRoot, 
function() 
if source == PicTopTime then 
guiSetAlpha(Label1, 1.00) 
guiSetAlpha(ListTime, 1.00) 
guiSetAlpha(Label2, 0.00) 
guiSetAlpha(Label3, 0.00) 
guiSetAlpha(Label4, 0.00) 
guiSetVisible(ListTime, true) 
guiSetVisible(ListDerby, false) 
guiSetVisible(bankList, false) 
guiSetVisible(ListLevel, false) 
end end )
------------
addEventHandler("onClientGUIClick", guiRoot, 
function() if source == PicTopDerby then 
guiSetAlpha(Label1, 0.00) 
guiSetAlpha(ListDerby, 1.00) 
guiSetAlpha(Label2, 1.00) 
guiSetAlpha(Label3, 0.00) 
guiSetAlpha(Label4, 0.00) 
guiSetVisible(ListTime, false) 
guiSetVisible(ListDerby, true) 
guiSetVisible(bankList, false) 
guiSetVisible(ListLevel, false) 
end end )
------------
addEventHandler("onClientGUIClick", guiRoot, 
function() if source == PicTopLike then 
guiSetAlpha(Label1, 0.00) 
guiSetAlpha(Label2, 0.00) 
guiSetAlpha(Label3, 1.00) 
guiSetAlpha(Label4, 0.00) 
guiSetAlpha(bankList, 1.00) 
guiSetVisible(ListTime, false) 
guiSetVisible(ListDerby, false) 
guiSetVisible(bankList, true) 
guiSetVisible(ListLevel, false)
end end )
------------
addEventHandler("onClientGUIClick", guiRoot, 
function() if source == PicTopLevel then 
guiSetAlpha(Label1, 0.00) 
guiSetAlpha(Label2, 0.00) 
guiSetAlpha(Label3, 0.00) 
guiSetAlpha(ListLevel, 1.00) 
guiSetAlpha(Label4, 1.00) 
guiSetVisible(ListTime, false) 
guiSetVisible(ListDerby, false) 
guiSetVisible(bankList, false) 
guiSetVisible(ListLevel, true)
end end )
------------
addEventHandler( "onClientGUIClick",getRootElement(), 
function ( ) 
if source == PicTopTime then 
guiSetAlpha(PicTopTime, 1) 
guiSetAlpha(PicTopLike, 0.36) 
guiSetAlpha(PicTopLevel, 0.36) 
guiSetAlpha(PicTopDerby, 0.36) 
end end )
------------
addEventHandler( "onClientGUIClick",getRootElement(), 
function ( ) 
if source == PicTopDerby then 
guiSetAlpha(PicTopDerby, 1) 
guiSetAlpha(PicTopTime, 0.36) 
guiSetAlpha(PicTopLevel, 0.36) 
guiSetAlpha(PicTopLike, 0.36)
end end )
------------
addEventHandler( "onClientGUIClick",getRootElement(), 
function ( ) 
if source == PicTopLevel then 
guiSetAlpha(PicTopLevel, 1) 
guiSetAlpha(PicTopTime, 0.36) 
guiSetAlpha(PicTopLike, 0.36) 
guiSetAlpha(PicTopDerby, 0.36)
end end )
------------
addEventHandler( "onClientGUIClick",getRootElement(), 
function ( )
if source == PicTopLike then 
guiSetAlpha(PicTopLike, 1) 
guiSetAlpha(PicTopTime, 0.36) 
guiSetAlpha(PicTopLevel, 0.36) 
guiSetAlpha(PicTopDerby, 0.36)
end end )
------------
addEventHandler("onClientGUIClick",root, 
function() 
if source == Close then 
guiSetVisible(Window,false) 
showCursor(false) 
end end )

------------------------------
-- By : MR.S3D
------------------------------

function getTopBank(  )
BankTable = {  };
for _, player in ipairs( getElementsByType( 'player' ) ) do
table.insert( BankTable, 
{ 
plr = player, 
BankR = getElementData( player, 'useronBank' ) or '0'
} 
)
end
table.sort( BankTable,
function( min, max )
return ( tonumber( min.BankR ) or '' ) > ( tonumber( max.BankR ) )
end )
return BankTable
end


function ScriptTopBank()
guiGridListClear( bankList )
local pBank = getTopBank(  )
for num = 1, #getElementsByType( 'player' ) do
if ( num >= 31 ) then return end
if ( pBank[1] ) then
local plrname=getPlayerName( pBank[num].plr  )
if mytable[pBank[num].plr] and tostring(mytable[pBank[num].plr])~='nil' then plrname=tostring(mytable[pBank[num].plr])end
local row = guiGridListAddRow( bankList )
local pName = guiGridListSetItemText( bankList, row, 1, num..'- '..plrname, false, false )
local pValue = guiGridListSetItemText( bankList, row, 2, '$'..pBank[num].BankR, false, false )
guiGridListSetItemColor( bankList, row, 100, 100, 100, 0)
guiGridListSetItemColor( bankList, row, 1, math.random(0,255),math.random(0,255),math.random(0,255))
guiGridListSetItemColor( bankList, row, 2, 0, 255, 0) 
end end end

------------------------------

function updateTopList(name, top, i)
local row = guiGridListAddRow (Lst)
-- guiGridListSetItemText (Lst, row, column, "" .. i .. "-", false, false )
-- guiGridListSetItemText (Lst, row, column1, tostring(name), false, false )
-- guiGridListSetItemText ( Lst,row, column2, convertNumber(top), false, false )
guiGridListSetItemColor(Lst, row, column1,math.random(0,255),math.random(0,255),math.random(0,155))
guiGridListSetItemColor(Lst, row, column2,math.random(0,255),math.random(0,255),math.random(0,155))
guiGridListSetItemColor(Lst, row, column,math.random(0,255),math.random(0,255),math.random(0,155))
end
addEvent("updateTop", true)
addEventHandler("updateTop", root, updateTopList)

function update()
guiGridListClear(Lst)
end
addEvent("deltTop", true)
addEventHandler("deltTop", root, update)


------------------------------
addCommandHandler("top", function()
guiSetVisible(Window,not guiGetVisible(Window)) showCursor(guiGetVisible(Window))
guiSetAlpha(Label3, 1.00)
guiSetAlpha(Label1, 0.00)
guiSetAlpha(Label2, 0.00)
guiSetAlpha(Label4, 0.00)
guiSetAlpha(PicTopTime, 0.36)
guiSetAlpha(PicTopDerby, 0.36)
guiSetAlpha(PicTopLike, 1)
guiSetAlpha(PicTopLevel, 0.36)
guiSetAlpha(bankList, 1)
guiSetVisible(bankList, true)
guiSetVisible(ListTime, false)
guiSetVisible(ListDerby, false)
guiSetVisible(ListLevel, false)
ScriptTopTime()
ScriptTopLevel()
end );
------------
bindKey( 'F7', 'down', function()
guiSetVisible(Window,not guiGetVisible(Window))
showCursor(guiGetVisible(Window))
ScriptTopTime()
ScriptTopLevel()
ScriptTopBank()
triggerServerEvent('getThederby',localPlayer)
end );
triggerServerEvent('GetListNames2019',localPlayer)

