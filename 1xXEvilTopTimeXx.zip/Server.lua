﻿function OutPut(message, player, r, g, b) 
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEventHandler('onPlayerLogin',root,function(_,acc)
local acc=getAccountName(acc)
setElementData(source,'accname',acc)
triggerClientEvent(root,'updateTable2019',root,getTable())
end )

addEventHandler('onPlayerLogout',root,function(_,acc)
local acc=getAccountName(acc)
if getElementData(source,'accname') then
removeElementData(source,'accname')
end end )

local db=dbConnect('sqlite','s3d.db')
dbExec(db,'CREATE TABLE IF NOT EXISTS thetable (acc)')

addEvent("getThederby",true)
addEventHandler("getThederby",root,
function( )
local ta={}
for k,v in ipairs(getElementsByType('player'))do
local acc=getPlayerAccount(v)
if not isGuestAccount(acc) then
local da1=getAccountData(acc,'derplay') or 0
local da2=getAccountData(acc,'derwin') or 0
table.insert(ta,{plr=v,play=da1,win=da2})
end
end
table.sort(ta,function(a,b) return tonumber(a.win)>tonumber(b.win) end)
triggerClientEvent(source,'setmyderbydata',source,ta)
end )

-- addEvent("getThederby",true)
-- addEventHandler("getThederby",root,
-- function( )
-- local ta={}
-- for k,v in ipairs(getElementsByType('player'))do
-- local acc=getPlayerAccount(v)
-- if not isGuestAccount(acc) then
-- local da1=getAccountData(acc,'playder') or 0
-- local da2=getAccountData(acc,'wintime') or 0
-- table.insert(ta,{plr=v,play=da1,win=da2})
-- end
-- end
-- table.sort(ta,function(a,b) return tonumber(a.win)>tonumber(b.win) end)
-- triggerClientEvent(source,'setmyderbydata',source,ta)
-- end )

function getTable()
local ta={}	
for k,v in ipairs(getElementsByType('player'))do
local acc=getPlayerAccount(v)
if not isGuestAccount(acc) then
local data=getAccountData(acc,'mynick')
if data then
ta[v]=data
end
end
end
return ta
end

addEvent('getTheTableofnames',true)
addEventHandler('getTheTableofnames',root,function(plr)
triggerClientEvent(source,'updateTable2019',source,getTable())
end )

addEvent('setmynick',true)
addEventHandler('setmynick',root,function(acc,str)
local acc=getAccount(acc)
if  acc then
setAccountData(acc,'mynick',str)
OutPut('! تم إرسال معلومات النك بنجاح *',source,math.random(255),math.random(255), math.random(255),true)
end
triggerClientEvent('updateTable2019',root,getTable())
end )

addEvent('GetListNames2019',true)
addEventHandler('GetListNames2019',root,function()
triggerClientEvent('updateTable2019',root,getTable())
end )

addEvent('addTTable2019',true)
addEventHandler('addTTable2019',root,function(acc)
if getAccount(acc) then
local sel=dbPoll(dbQuery(db,'SELECT * FROM thetable WHERE acc=?',acc),-1)		
if #sel~=0 then outputChatBox('the account is already in table',source,255,0,0) return end
dbExec(db,'INSERT INTO thetable VALUES(?)',acc)		
else		
outputChatBox('رجاء التاكد من الحساب !',source,255,0,0,true)
end end )

addEvent('deleteTTable2019',true)
addEventHandler('deleteTTable2019',root,function(tacc)
local acc=getAccount(tacc)
if acc then
local sel=dbPoll(dbQuery(db,'SELECT * FROM thetable WHERE acc=?',tacc),-1)	
if #sel==0 then outputChatBox('the account is not in table',source,255,0,0) return end	
dbExec(db,'DELETE FROM thetable WHERE acc=?',tacc)	
setAccountData(acc,'mynick',nil)
triggerClientEvent('updateTable2019',root,getTable())
else	
outputChatBox('رجاء التاكد من الحساب !',source,255,0,0,true)		
end end)

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end

setTimer( 
	function ( )
		for _, aPlayer in next, getElementsByType 'player' do
			setElementData ( aPlayer, 'xTopsMoeny', getPlayerMoney ( aPlayer ) )
			setElementData ( aPlayer, "BankR", "$"..convertNumber(getPlayerMoney ( aPlayer )))
		end
	end
, 30000, 0 )

addEventHandler ( "onPedWasted", root,
	function ( _, attacker )
		if isElement ( attacker ) then
			if getElementType ( attacker ) == "player" then
				if getElementData ( source, "zombie" ) then
					setElementData ( attacker, "kills", ( getElementData ( attacker, "kills" ) or 0 )+1 )
					checkLevel ( attacker, getElementData ( attacker, "kills" ) )
				end
			end
		end
	end
)

addEventHandler ( "onPlayerQuit", root,
	function ( )
		local playerAcc = getPlayerAccount ( source )
		if playerAcc and not isGuestAccount ( playerAcc ) then
			local score = getElementData ( source, "kills" )
			local level = getElementData ( source, "Level" )
			if score then
				setAccountData ( playerAcc, "kills", score )
			end		
			if level then
				setAccountData ( playerAcc, "Level", level )
			end
		end
	end
)

addEventHandler ( "onPlayerLogin", root,
	function ( _, playerAcc )
		local score = getAccountData ( playerAcc, "kills" )
		local level = getAccountData ( playerAcc, "Level" )
		if score then
			setTimer ( setElementData, 1000, 1, source, "kills", score )
		end
		if level then
			setElementData ( source, "Level", level )
		end		
	end
)

local playerWeapons = { }
 
addEventHandler ( "onPlayerWasted", root,
    function ( )
        if ( not playerWeapons [ source ] ) then
            playerWeapons [ source ] = { }
        end
        for slot = 0, 12 do
            local weapon = getPedWeapon ( source, slot )
            if ( weapon > 0 ) then
                local ammo = getPedTotalAmmo ( source, slot )
                if ( ammo > 0 ) then
                    playerWeapons [ source ] [ weapon ] = ammo
                end
            end
        end
    end
)
 
addEventHandler ( "onPlayerSpawn", root,
    function ( )
        if ( playerWeapons [ source ] ) then
            for weapon, ammo in pairs ( playerWeapons [ source ] ) do
                giveWeapon ( source, tonumber ( weapon ), tonumber ( ammo ) )
            end
        end
 
        playerWeapons [ source ] = nil
    end
)

addCommandHandler('Editnick',function(plr,cmd,...)
local acc=getPlayerAccount(plr)
if not isGuestAccount(acc) and ( isObjectInACLGroup('user.'..getAccountName(acc),aclGetGroup('Console'))) then
triggerClientEvent(plr,'openwindow',plr,dbPoll(dbQuery(db,'SELECT * FROM thetable'),-1))
end
end )