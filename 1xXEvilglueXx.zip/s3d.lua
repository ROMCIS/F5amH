﻿vehicle = nil
function glue()
	local player = getLocalPlayer()
	local Tick = getTickCount()
	if tick and tick + tonumber(3000) > Tick then
		return outputChatBox('انتظر قليلا ثم حاول مرة أخرى',255,0,0)
	else
		tick = getTickCount()
	end
	if not getPlayerOccupiedVehicle(player) then
		vehicle = getPlayerContactElement(player)
		if vehicle and getElementType(vehicle) == "vehicle" then
			
			local px, py, pz = getElementPosition(player)
			local vx, vy, vz = getElementPosition(vehicle)
			local sx = px - vx
			local sy = py - vy
			local sz = pz - vz
			
			local rotpX = 0
			local rotpY = 0
			local rotpZ = getPlayerRotation(player)
			
			local rotvX,rotvY,rotvZ = getVehicleRotation(vehicle)
			
			local t = math.rad(rotvX)
			local p = math.rad(rotvY)
			local f = math.rad(rotvZ)
			
			local ct = math.cos(t)
			local st = math.sin(t)
			local cp = math.cos(p)
			local sp = math.sin(p)
			local cf = math.cos(f)
			local sf = math.sin(f)
			
			local z = ct*cp*sz + (sf*st*cp + cf*sp)*sx + (-cf*st*cp + sf*sp)*sy
			local x = -ct*sp*sz + (-sf*st*sp + cf*cp)*sx + (cf*st*sp + sf*cp)*sy
			local y = st*sz - sf*ct*sx + cf*ct*sy
			
			local rotX = rotpX - rotvX
			local rotY = rotpY - rotvY
			local rotZ = rotpZ - rotvZ
			
			local slot = getPlayerWeaponSlot(player)
			if not gluErR then
				gluErR = true
				addEventHandler("onClientRender", getRootElement(), gluEr)
			end	
	        setElementData(localPlayer,'glue',true)
			dimR = getElementDimension(localPlayer)
			--outputDebugString("gluing ".. getPlayerName(player) .." to " .. getVehicleName(vehicle) .. "(offset: "..tostring(x)..","..tostring(y)..","..tostring(z).."; rotation:"..tostring(rotX)..","..tostring(rotY)..","..tostring(rotZ)..")")
			triggerServerEvent("gluePlayer", player, slot, vehicle, x, y, z, rotX, rotY, rotZ)
			unbindKey("x","down",glue)
			bindKey("x","down",unglue)
			bindKey("jump","down",unglue)
		end
	end
end
addCommandHandler("glue",glue)

addEventHandler("onClientElementDestroy", getRootElement(), function ()
	if vehicle and vehicle == source then
		if getElementData(localPlayer,'glue')  then
			unglue()
		end
	end
end)

addEventHandler("onClientVehicleEnter", getRootElement(),
    function(thePlayer)
        if thePlayer == getLocalPlayer() then
			if getElementData(thePlayer,'glue')  then
				unglue()
			end
        end
    end
)

addEventHandler("onClientElementDestroy", getRootElement(), function ()
	if vehicle and vehicle == source then
		if getElementData(localPlayer,'glue')  then
			unglue()
		end
	end
end)

function gluEr()
	if getElementData(localPlayer,'glue')  then
		local dim = getElementDimension(localPlayer)
		if dimR and dimR == dim then
		else
			setElementDimension(localPlayer,dimR or 0)
		end
	end
end

function unglue ()
	local player = getLocalPlayer()
	setElementData(localPlayer,'glue',false)		
	triggerServerEvent("ungluePlayer", player)
	unbindKey("jump","down",unglue)
	unbindKey("x","down",unglue)
	bindKey("x","down",glue)
	vehicle = nil
end
addCommandHandler("unglue",unglue)

bindKey("x","down",glue)