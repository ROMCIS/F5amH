function skin()
txd = engineLoadTXD ( "46.txd" )
engineImportTXD ( txd, 46 )
dff = engineLoadDFF ( "46.dff", 0 )
engineReplaceModel ( dff, 46 )

txd1 = engineLoadTXD ( "124.txd" )
engineImportTXD ( txd1, 124 )
dff1 = engineLoadDFF ( "124.dff", 0 )
engineReplaceModel ( dff1, 124 )

end
setTimer(skin,3000,1)


