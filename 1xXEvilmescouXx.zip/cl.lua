﻿----------------------
-- Setting
----------------------
local Key = ""

local Admin = {
{'King Of Time', 25,'Time'},
{'V.I.P', 35,'V.I.P'},
{'VotePolice', 40,'VotePolice'},
{'Police', 60,'police'},
{'VoteModerator', 95,'VoteModerator'},
{'Moderator', 130,'Moderator'},
{'Moderator2', 150,'Moderator2'},
{'SuperModerator', 170,'SuperModerator'},
{'SuperModerator2', 180,'SuperModerator2'},
{'Head.Admin', 300,'Head.Admin'},
{'Speical Admin', 350,'DE'},
{'Prince of Server', 400,'Prince'},
{'Leader Admin', 450,'Leader'},
{'Professional Admin', 500,'Professional'},
{'V.I.P Admin', 550,'Vip-Admin'},
{'Admin Top', 600,'AdminTop'},
{'Admin Plus', 650,'AdminPlus'},
{'Best Admin', 700,'BestAdmin'},
{'Admin Boss', 750,'AdminBoss'},
{'King Of Server', 800,'KingOfServer'},
{'Big admin', 850,'Bigadmin'},
{'Admin Monitor', 900,'AdminMonitor'},
{'Emperor Of Server', 950,'EmperorOfServer'},
{'Admin Official', 1000,'AdminOfficial'},
{'Admin Prime', 1050,'AdminPrime'},
{'Admin General', 1100,'AdminGeneral'},
{'KING ADMIN ', 1500,'KINGADMIN'},
{'ADMIN POWER', 1800,'ADMINPOWER'},
{'ADMIN F5AMH', 2000,'ADMINF5AMH'},
{'ADMIN M7TRF', 2200,'ADMINM7TRF'},
{'PRINCE ADMIN', 2500,'PRINCEADMIN'},
{'Senior Admin', 3000,'ADMINSENIOR'},
{'SPECIALPRINCE', 3500,'SPECIALPRINCE'},
}
----------------------
-- Admin', 200,'Admin
----------------------

GiveAdmin = {
    gridlist = {},
    Window = {},
    button = {}
}
local screenW, screenH = guiGetScreenSize()
GiveAdmin.Window[1] = guiCreateWindow((screenW - 296) / 2, (screenH - 368) / 2, 296, 368, "=[ لــوحة ألترقــيآت ]=", false)
guiSetVisible(GiveAdmin.Window[1],false);
guiWindowSetSizable(GiveAdmin.Window[1], false)
guiSetProperty(GiveAdmin.Window[1], "CaptionColour", "FF4DFF00")
guiSetAlpha(GiveAdmin.Window[1], 1.00)
GiveAdmin.gridlist[1] = guiCreateGridList(10, 21, 277, 285, false, GiveAdmin.Window[1])
guiSetFont(GiveAdmin.gridlist[1], "default-bold-small")
guiGridListAddColumn(GiveAdmin.gridlist[1], "#", 0.2)
guiGridListAddColumn(GiveAdmin.gridlist[1], "#Group", 0.5)
guiGridListAddColumn(GiveAdmin.gridlist[1], "#Time", 0.4)
guiGridListAddColumn(GiveAdmin.gridlist[1], "#Group", 0.6);
guiSetAlpha(GiveAdmin.gridlist[1],0.75)
GiveAdmin.button[1] = guiCreateButton(70, 317, 154, 25, "تـــرقيةة |#| Promotion", false, GiveAdmin.Window[1])
guiSetFont(GiveAdmin.button[1], "default-bold-small")
guiSetProperty(GiveAdmin.button[1], "NormalTextColour", "FFFF0006")
GiveAdmin.button[2] = guiCreateButton(250, 332, 36, 32, "X", false, GiveAdmin.Window[1])
guiSetFont(GiveAdmin.button[2], "default-bold-small")
guiSetProperty(GiveAdmin.button[2], "NormalTextColour", "FF990909")




for k,v in ipairs ( Admin ) do
row = guiGridListAddRow(GiveAdmin.gridlist[1]);
guiGridListSetItemText(GiveAdmin.gridlist[1],row,1,'+',false,false);
guiGridListSetItemText(GiveAdmin.gridlist[1],row,2,v[1],false,false);
guiGridListSetItemText(GiveAdmin.gridlist[1],row,3,v[2],false,false);
guiGridListSetItemText(GiveAdmin.gridlist[1],row,4,v[3],false,false);
guiGridListSetItemColor(GiveAdmin.gridlist[1],row,1,200,200,0);
guiGridListSetItemColor(GiveAdmin.gridlist[1],row,3,255,0,0);
end

xMainFunctions_ = function ( )
 local row, col = guiGridListGetSelectedItem ( GiveAdmin.gridlist[1] ) 
local Price = tostring ( guiGridListGetItemText(GiveAdmin.gridlist[1],row,3 ));
local Group = tostring ( guiGridListGetItemText(GiveAdmin.gridlist[1],row,4 ));
local Name = tostring ( guiGridListGetItemText(GiveAdmin.gridlist[1],row,2 ));
   if ( row and col and row ~= -1 and col ~= -1 ) then
triggerServerEvent("Accept:the:request",localPlayer,Group,Price,Name);
  else
  exports.infobox:outputMessage("الرجاء اختيار رتبةة !",255,0,0,true)
  end
end
addEventHandler("onClientGUIClick",GiveAdmin.button[1],xMainFunctions_,false);

xBindFunction_ = function ()
	guiSetVisible(GiveAdmin.Window[1],not guiGetVisible(GiveAdmin.Window[1]));
	showCursor(guiGetVisible(GiveAdmin.Window[1]));
end
bindKey(Key,"down",xBindFunction_);
addEventHandler ( "onClientGUIClick", resourceRoot,
function (    )

if ( source == GiveAdmin.button[2] ) then -- هنا اسم الزر

guiSetVisible(GiveAdmin.Window[1],false)-- هنا اسم اللوحة

showCursor(false)
	         guiSetInputEnabled(false)
end
end)

addCommandHandler('رتب',
function()
if (guiGetVisible(GiveAdmin.Window[1]) == true) then
guiSetVisible(GiveAdmin.Window[1],false)
showCursor(false)
else
guiSetVisible(GiveAdmin.Window[1],true)
showCursor(true)
end
end
)
---------------------------