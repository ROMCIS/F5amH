﻿-----------------------
-- ** Buy Admin's Script
-- Created By MiX_AL-GARBIH
-- Ver 1.0.0
-- Mail : MX.WESTERNN@GMAIL.com
-- 
----------------------


local ForbiddenGroup = "Admin-F" -- اسم قروب المخالفين
 
xAddToGroupFunction_ = function ( Group,Price,Name )
    local account = getAccountName(getPlayerAccount(source));
    if isGuestAccount(getPlayerAccount(source)) then return outputChatBox("* يجب عليك التسجيل اولاً",source,255,0,0,true); end
    if isObjectInACLGroup("user."..account, aclGetGroup(tostring(Group))) then return outputChatBox("* لديك هذه الرتبة فعلاً",source,255,0,0,true); end
    if isObjectInACLGroup("user."..account, aclGetGroup(ForbiddenGroup)) then return outputChatBox("* انت مخالف",source,255,0,0,true); end
    local sValue = getElementData( source,'PlayTime' )
    if not sValue then sValue = '0:0:0' end
    local data = split(sValue,':')
    local hour = tonumber( data[1] )  
    if hour == nil or not tonumber(hour) then hour = 0 end
    if ( hour >= tonumber(Price))  then
             revmoeOtherGroups ( source )
        aclGroupAddObject (aclGetGroup( tostring(Group)),"user."..account);
        outputChatBox("* ==[ تم ترقية بنجاح تهانينا ]=="..Name,source,0,255,0,true);
    else
        outputChatBox("* ليس لديك ساعات كافية",source,255,0,0,true);
    end
end
addEvent("Accept:the:request",true)
addEventHandler("Accept:the:request",root,xAddToGroupFunction_)
 
function revmoeOtherGroups (  element  )
 if ( element and isElement ( element ) ) then
  if ( getPlayerAccount ( element ) and not isGuestAccount ( getPlayerAccount ( element ) ) ) then
   for _, v in ipairs( aclGroupList (   ) ) do
    if ( isObjectInACLGroup ( "user."..getAccountName ( getPlayerAccount ( element ) ), v ) ) then
           aclGroupRemoveObject ( v, "user."..getAccountName ( getPlayerAccount ( element ) ) )
        end
      end
    end
  end
end
