local screenW, screenH = guiGetScreenSize()
local x, y = (screenW/1366), (screenH/768)

function FaHaD()
local speed = 1.0
tickk = getTickCount()/tonumber(speed)/1100
theAlpha = math.abs(math.sin(-tickk))*255
        dxDrawImage(x*650, y*10, x*87, y*87, "FiveM.png", 0, 0, 0, tocolor(255, 255, 255, theAlpha), false)
dxDrawText("F5amh Server | فخامة الهجولة ترحب بكم ",x*1380, y*230, x*20, y*10, tocolor(255, 255, 255, theAlpha), 1.70, "default-bold","center","center",false,false,false,true)
end

function removeFahaD()
	removeEventHandler("onClientRender", root, FaHaD)
end
addEvent("removeFahaD", true)
addEventHandler("removeFahaD", root, removeFahaD)


function addFahaD()
addEventHandler("onClientRender", root,FaHaD) 
end
addEvent("addFahaD", true)
addEventHandler("addFahaD", root, addFahaD)

addEventHandler ( "onClientResourceStart", resourceRoot, 
function (  ) 
addEventHandler("onClientRender",getRootElement(),FaHaD) 
end )