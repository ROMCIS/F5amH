local screenW, screenH = guiGetScreenSize()
local x, y = (screenW/1366), (screenH/768)

Serial = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["DE75A78DFDBE9918A725E38238F5F094"] = true, -- كريزي
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
}

S3D = {
    gridlist = {},
    staticimage = {},
    button = {},
    label = {}
}

S3D.staticimage[1] = guiCreateWindow(1034, 390, 248, 430, "-| نظام التنبيهات |-", false)
guiSetVisible(S3D.staticimage[1], false)
guiSetAlpha(S3D.staticimage[1], 1.00)

S3D.label[1] = guiCreateLabel(78, 10, 93, 16, "", false, S3D.staticimage[1])
guiSetFont(S3D.label[1], "default-bold-small")
S3D.gridlist[1] = guiCreateGridList(15, 37, 214, 351, false, S3D.staticimage[1])
guiGridListAddColumn(S3D.gridlist[1], "#", 0.8)
guiSetAlpha(S3D.gridlist[1], 1.00)
local font0_font = guiCreateFont("FaHaD.ttf", 13)
guiSetFont(S3D.gridlist[1], font0_font) 
S3D.button[1] = guiCreateButton(25, 393, 201, 27, "أغلاق |#| Close", false, S3D.staticimage[1])
guiSetFont(S3D.button[1], "default-bold-small")
guiSetProperty(S3D.button[1], "NormalTextColour", "FFFF0000")    

S3D.staticimage[2] = guiCreateWindow(11, 349, 350, 227, "الرسالة الي بتطلع بالانذار", false)
guiSetVisible(S3D.staticimage[2], false)
guiWindowSetSizable(S3D.staticimage[2], false)
guiSetAlpha(S3D.staticimage[2], 1.00)

memo = guiCreateMemo(11, 26, 329, 160, "", false, S3D.staticimage[2])
local font = guiCreateFont("FaHaD.ttf", 9)
guiSetFont(S3D.gridlist[1], font) 
        S3D.button[2] = guiCreateButton(11, 192, 137, 25, "Press To Finish", false, S3D.staticimage[2])
        guiSetFont(S3D.button[2], "default-bold-small")
        guiSetProperty(S3D.button[2], "NormalTextColour", "FFFFFFFF")    
S3D.label[3] = guiCreateLabel(252, 206, 88, 17, "F5amh [FaHaD]", false, S3D.staticimage[2])
guiSetFont(S3D.label[3], "default-bold-small")    


bindKey ( "/", "down", 
    function ( ) 
local PlayerSerial = getPlayerSerial(localPlayer)
if ( Serial[PlayerSerial] ) then  
guiSetVisible( S3D.staticimage[1], not guiGetVisible ( S3D.staticimage[1] ) )
showCursor ( guiGetVisible ( S3D.staticimage[1] ) )
    end 
end
) 

RoMcIS = {
{"انذار وزارة الداخلية    "},
{"ترحيب    "},
{"ادارة السيرفر    "},
{"صاحب السيرفر    "},
}

for i,ha in ipairs(RoMcIS) do
local row = guiGridListAddRow(S3D.gridlist[1])
guiGridListSetItemText(S3D.gridlist[1],row,1,ha[1],false,false)
guiGridListSetItemColor(S3D.gridlist[1],row,1,255, 255, 0)
end

addEventHandler('onClientGUIDoubleClick',S3D.gridlist[1],
function () 
local Row = guiGridListGetItemText ( S3D.gridlist[1], guiGridListGetSelectedItem ( S3D.gridlist[1] ), 1 )
local Sel = guiGridListGetSelectedItem( S3D.gridlist[1] )
if ( Sel == -1 ) then return end
if ( Row ) == "Edit RoMcIS" then
elseif ( Row ) == "انذار وزارة الداخلية    " then guiSetVisible (S3D.staticimage[1] ,false) guiSetVisible (S3D.staticimage[2] ,true)
elseif ( Row ) == "ترحيب    " then guiSetVisible (S3D.staticimage[1] ,false) guiSetVisible (S3D.staticimage[2] ,true)
elseif ( Row ) == "ادارة السيرفر    " then guiSetVisible (S3D.staticimage[1] ,false) guiSetVisible (S3D.staticimage[2] ,true)
elseif ( Row ) == "صاحب السيرفر    " then guiSetVisible (S3D.staticimage[1] ,false) guiSetVisible (S3D.staticimage[2] ,true)
end end )


addEventHandler("onClientGUIClick",root, 
function() 
if (source == S3D.button[1]) then 
showCursor(false) 
guiSetVisible(S3D.staticimage[1], false) 
elseif source==S3D.button[2] then
local text = guiGetText(memo)
guiSetVisible(S3D.staticimage[2], false)
showCursor(false) 
addEventHandler("onClientRender",root,intro)
end
end )

function intro(text)
local text = guiGetText(memo)
local speed = 1.2
tickk = getTickCount()/tonumber(speed)/1000
theAlpha = math.abs(math.sin(-tickk))*255
showChat(false)
showPlayerHudComponent("all", false)
triggerEvent('removeFahaD',source)
        dxDrawImage(x*0, y*0, x*1400, y*120, "s3d.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
dxDrawText("- سيرفر فخامة -",x*1380, y*70, x*20, y*7, tocolor(255, 255, 255, theAlpha), 1.70, "default-bold","center","center",false,false,false,true)
dxDrawText("=[ انذار ]=",x*1380, y*70, x*20, y*60, tocolor(255, 255, 255, 255), 1.50, "default-bold","center","center",false,false,false,true)
dxDrawText(""..text.."",x*1380, y*186, x*20, y*25, tocolor(255, 255, 255, 255), 1.20, "default-bold","center","center",false,false,false,true)
addEventHandler("onClientRender",root,intro2)
	end


function intro2()
setTimer(function()
removeEventHandler("onClientRender",root,intro)
showChat(true)
showPlayerHudComponent("all", true)
triggerEvent('addFahaD',source)
end,20000,1)
	end