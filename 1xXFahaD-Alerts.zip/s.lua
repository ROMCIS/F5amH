addEvent("fahad:add",true)
addEventHandler("fahad:add",root,
function(text)
triggerClientEvent(root, "Alerts:FahaD", text, root)
end
)