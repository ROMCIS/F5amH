﻿local Rroot = getResourceRootElement(getThisResource())
local screenW, screenH = guiGetScreenSize()

ROMCIS = {
    button = {},
    window = {},
    label = {}
}


ROMCIS.window[1] = guiCreateWindow((screenW - 312) / 2, (screenH - 331) / 2, 312, 331, "-| Random | عشوائي |-", false)

ROMCIS.label[1] = guiCreateLabel(175, 43, 127, 15, "-| اخذ موتر عشوائي |-", false, ROMCIS.window[1])
ROMCIS.label[2] = guiCreateLabel(169, 92, 133, 15, "-| اخذ سلاح عشوائي |-", false, ROMCIS.window[1])
ROMCIS.label[3] = guiCreateLabel(169, 142, 133, 15, "-| اخذ فلوس عشوائية |-", false, ROMCIS.window[1])
ROMCIS.label[4] = guiCreateLabel(163, 195, 139, 15, "-| اخذ ساعات عشوائية |-", false, ROMCIS.window[1])
ROMCIS.button[1] = guiCreateButton(18, 38, 124, 25, "Take |#| أخذ", false, ROMCIS.window[1])
ROMCIS.button[2] = guiCreateButton(18, 88, 124, 25, "Take |#| أخذ", false, ROMCIS.window[1])
ROMCIS.button[3] = guiCreateButton(18, 136, 124, 25, "Take |#| أخذ", false, ROMCIS.window[1])
ROMCIS.button[4] = guiCreateButton(18, 190, 124, 25, "Take |#| أخذ", false, ROMCIS.window[1])
ROMCIS.label[5] = guiCreateLabel(179, 246, 121, 15, "-| اخذ رتبة عشوائية |-", false, ROMCIS.window[1])
ROMCIS.button[5] = guiCreateButton(18, 242, 124, 25, "Take |#| أخذ", false, ROMCIS.window[1])
ROMCIS.button[6] = guiCreateButton(270, 294, 30, 27, "X", false, ROMCIS.window[1])
ROMCIS.label[6] = guiCreateLabel(8, 306, 121, 15, "#2020 | MR.ROMCIS", false, ROMCIS.window[1])
-- 
ROMCIS.window[2] = guiCreateWindow((screenW - 312) / 2, (screenH - 181) / 2, 312, 181, "-| Random | عشوائي |-", false)
ROMCIS.label[7] = guiCreateLabel(58, 27, 197, 32, "تنبيه : عند اخذك الشيئ المراد شرائه \nسيتم خصم منك مبلغ عشوائي      ", false, ROMCIS.window[2])
ROMCIS.button[7] = guiCreateButton(189, 132, 113, 30, "نعم |#| Yas", false, ROMCIS.window[2])
ROMCIS.button[8] = guiCreateButton(10, 132, 113, 30, "لا |#| No", false, ROMCIS.window[2])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(ROMCIS.window[1], false)
guiWindowSetSizable(ROMCIS.window[1], false)
guiSetAlpha(ROMCIS.window[1], 1.00)
guiSetVisible(ROMCIS.window[2], false)
guiWindowSetSizable(ROMCIS.window[2], false)
guiSetAlpha(ROMCIS.window[2], 1.00)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(ROMCIS.button[1], "NormalTextColour", "FF02F8EF")
guiSetProperty(ROMCIS.button[2], "NormalTextColour", "FF02F8EF")
guiSetProperty(ROMCIS.button[3], "NormalTextColour", "FF02F8EF")
guiSetProperty(ROMCIS.button[4], "NormalTextColour", "FF02F8EF")
guiSetProperty(ROMCIS.button[5], "NormalTextColour", "FF02F8EF")
guiSetProperty(ROMCIS.button[6], "NormalTextColour", "FFDB8622")
guiSetProperty(ROMCIS.button[7], "NormalTextColour", "FF0BFC00")
guiSetProperty(ROMCIS.button[8], "NormalTextColour", "FFFC0000")  
guiSetFont(v, "default-bold-small") 
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(ROMCIS.label[6], 126, 126, 126)  
guiSetFont(ROMCIS.label[7], "default-bold-small")   
end end ) 

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[1] ) then
		if isTimer(timer) then 
			local mSeconds,_,__ = getTimerDetails(timer)
			local total = mSeconds / 60 / 1000
exports["notices"]:addNotification("يرجى الأنتظار قليلا والمحاولة مرة اخرى",'warning');
			return
		end	
		timer = setTimer(function() end,5 * 10 * 60,1)
triggerServerEvent("ROMCIS:Car",localPlayer)
elseif ( source == ROMCIS.button[2] ) then

elseif ( source == ROMCIS.button[3] ) then
triggerServerEvent("ROMCIS:Money",localPlayer)
elseif ( source == ROMCIS.button[4] ) then
triggerServerEvent("ROMCIS:Time",localPlayer)
elseif ( source == ROMCIS.button[5] ) then
triggerServerEvent("ROMCIS:Rank",localPlayer)
elseif ( source == ROMCIS.button[6] ) then
guiSetVisible(ROMCIS.window[1], false)
showCursor(false)
elseif ( source == ROMCIS.button[7] ) then

elseif ( source == ROMCIS.button[8] ) then
guiSetVisible(ROMCIS.window[1], true)
guiSetVisible(ROMCIS.window[2], false)
end
end
)

function OpenROMCIS( )
guiSetVisible( ROMCIS.window[1], not guiGetVisible( ROMCIS.window[1] ) )
showCursor( guiGetVisible( ROMCIS.window[1] ) )
end
bindKey ( "F5", "down",OpenROMCIS)