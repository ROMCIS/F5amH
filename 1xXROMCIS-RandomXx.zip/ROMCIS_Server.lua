﻿local Sr = { }
timer = { }

myTable = {
"Console",
"Admin",
"SuperModerator",
"Moderator",
}


addEvent("ROMCIS:Rank",true)
addEventHandler("ROMCIS:Rank",root,
	function ()
local acc = getPlayerAccount(source) 
if not isObjectInACLGroup("user." .. getAccountName(acc),aclGetGroup("Admin-F")) then 	
		if not isGuestAccount(getPlayerAccount(source)) then
			if getPlayerMoney(source) >= 1000 then	
				takePlayerMoney(source,1000)
-- aclGroupAddObject(aclGetGroup(math.random(1, #myTable),"user." .. getAccountName(acc))
-- aclGroupAddObject(aclGetGroup("POLICE-MR.MAN"),"user." .. getAccountName(acc)) 
OutPut("[ Random System ]: تم الحصول على اللقب",source,0,255,0) 
			else
OutPut("[ Random System ] : لا تملك المال الكافي لشراء اللقب",source,255,0,0)
			end
		else
OutPut("[ Random System ]: يجب عليك تسجيل الدخول",source,255,0,0) 
			end
		else
OutPut("[ Random System ]: انت مخالف",source,255,0,0) 
		end
	end
)

function getPlayerTime ( Player )
	local TimeData = getElementData(Player,'PlayTime') or '0:0';
	if ( TimeData ) then
		return tonumber(split(TimeData,':')[1]) , tonumber(split(TimeData,':')[2]);
	end 
end

addEvent("ROMCIS:Time",true)
addEventHandler("ROMCIS:Time",root,
	function ()
if ( isTimer ( timer [ getPlayerSerial ( source ) ] ) ) then 
		local hour , mintue = getPlayerTime ( source ) -- نجيب ساعاته
local acc = getPlayerAccount(source) 
local Time = tonumber(math.random(25))
local RTime = tonumber(math.random(20))
if ( isTimer ( timer [ getPlayerSerial ( source ) ] ) ) then 
		if not isGuestAccount(getPlayerAccount(source)) then
		if ( hour >= 150 ) then -- نتحقق ان الساعات 40 او اكثر
triggerEvent ( "removeTime", source, getPlayerName(source),RTime )
setTimer(function( source )
triggerEvent ( "addTime", source, getPlayerName(source),Time )
outputChatBox ("[ Random System ]: You Got ( ".. Time .." ) Hours",source,0,255,0,true ) 
end,3000*1, 1, source)
outputChatBox("*[ Random System ]: ( ".. RTime .." ) : تم الخصم منك",source,255,255,0) 
timer [ getPlayerSerial ( source ) ] = setTimer ( function () end,86400000,1)
			else
OutPut("يجب أن يكون لديك 150 ساعة تواجد",source,255,0,0)
			end
		else
OutPut("[ Random System ]: يجب عليك تسجيل الدخول",source,255,0,0) 
			end
		else
	outputChatBox ("#000000[ #FFFFFFSupport #000000] | #ffffffلقد قمت مؤخراً بشكر لاعب أنتظر 24 ساعة",source,255,0,0,true)
		end
	end
end
)

addEvent("ROMCIS:Money",true)
addEventHandler("ROMCIS:Money",root,
	function ()
local acc = getPlayerAccount(source) 
local money = tonumber(math.random(500000))
local Take = tonumber(math.random(100000))
		if not isGuestAccount(getPlayerAccount(source)) then
			if getPlayerMoney(source) >= Take then	
takePlayerMoney(source,Take)
givePlayerMoney (source,money) 
OutPut("[ Random System ]: ( ".. money .." ) : تهانينا لقد اخذت",source,0,255,0) 
outputChatBox("*[ Random System ]: ( ".. Take .." ) : تم الخصم منك",source,255,255,0) 
			else
OutPut("[ Random System ] : لا تملك المال الكافي",source,255,0,0)
		end 
	else
OutPut("[ Random System ]: يجب عليك تسجيل الدخول",source,255,0,0) 
		end
end)

addEvent("ROMCIS:Car",true)
addEventHandler("ROMCIS:Car",root,
	function ()
local acc = getPlayerAccount(source) 
if( isElement ( Sr [ source ] ) ) then destroyElement( Sr [ source ] ) end
local x, y, z = getElementPosition ( source )
		if not isGuestAccount(getPlayerAccount(source)) then
			if getPlayerMoney(source) >= 250000 then	
				takePlayerMoney(source,250000)
        Sr [ source ] = createVehicle( math.random( "408","477" ), x, y, z)
        warpPedIntoVehicle ( source, Sr [ source ] )
OutPut("[ Random System ]: تم الحصول على السيارة",source,0,255,0) 
			else
OutPut("[ Random System ] : لا تملك المال الكافي لشراء السيارة",source,255,0,0)
			end
		else
OutPut("[ Random System ]: يجب عليك تسجيل الدخول",source,255,0,0) 
		end
	end
)
 
addEventHandler( "onVehicleExplode", resourceRoot,
	function( )
        setTimer( destroyElement, 2000, 1, source )
end )
 
addEventHandler( "onPlayerQuit", root, 
function( )
  if( isElement ( Sr [ source ] ) ) then
           destroyElement( Sr [ source ] )
       end
	   Sr [ source ] = nil
end )

function OutPut(message, player, r, g, b)
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end