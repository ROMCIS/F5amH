﻿command = "2"

local Rroot = getResourceRootElement(getThisResource())
local screenW, screenH = guiGetScreenSize()

S3D = {
    gridlist = {},
    button = {},
    window = {},
    edit = {},
    label = {}
}
 

S3D.window[1] = guiCreateWindow(496, 232, 466, 451, "-| لوحة استرجاع الحسابات |-", false)

S3D.label[1] = guiCreateLabel(132, 26, 190, 16, "مرحبا بك في لوحة استرجاع الحسابات", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(69, 46, 313, 16, "المفقوده حيث تمكنك هذه اللوحه من استرجاع حسابك المفقود", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(132, 62, 195, 17, "عن طريق تعبئة جميع الفراغات المطلوبه", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(115, 79, 222, 16, "وبعدها تقوم بإرسال طلب الاسترجاع للاداره", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(101, 95, 250, 16, "وسيتم الرد عليك في غضون 72 ساعه كحد اقصئ", false, S3D.window[1])
S3D.label[6] = guiCreateLabel(101, 111, 256, 16, "وفي حال لم يتم ارجاع الحساب يجب مراجعه الاداره", false, S3D.window[1])
S3D.label[7] = guiCreateLabel(138, 127, 185, 18, "وأحد اسباب عدم ارجاع الحساب هي", false, S3D.window[1])
S3D.label[8] = guiCreateLabel(27, 145, 413, 15, "الحساب ليس لك / اسم الحساب خاطئ / الحساب مملوك لشخص / اسباب اخرئ", false, S3D.window[1])
S3D.label[9] = guiCreateLabel(0, 160, 460, 15, "", false, S3D.window[1])
S3D.label[10] = guiCreateLabel(255, 179, 185, 18, "الفراغات اللتي تحمل علامه & إلزاميه", false, S3D.window[1])
S3D.label[11] = guiCreateLabel(249, 187, 201, 15, "|___________________________", false, S3D.window[1])
S3D.label[12] = guiCreateLabel(310, 212, 125, 17, "اسم الحساب المفقود &", false, S3D.window[1])
S3D.label[13] = guiCreateLabel(296, 239, 139, 15, "سيريال الحساب المفقود &", false, S3D.window[1])
S3D.label[14] = guiCreateLabel(310, 222, 125, 17, "", false, S3D.window[1])
S3D.label[15] = guiCreateLabel(296, 249, 139, 15, "-", false, S3D.window[1])
S3D.label[16] = guiCreateLabel(332, 264, 103, 15, "اخر تسجيل دخول &", false, S3D.window[1])
S3D.label[17] = guiCreateLabel(332, 274, 103, 15, "", false, S3D.window[1])
S3D.label[18] = guiCreateLabel(310, 289, 125, 15, "عدد الساعات المتوقعه :", false, S3D.window[1])
S3D.label[19] = guiCreateLabel(310, 299, 125, 15, "", false, S3D.window[1])
S3D.label[20] = guiCreateLabel(347, 314, 88, 16, "الأميل أو رقمك :", false, S3D.window[1])
S3D.label[21] = guiCreateLabel(347, 324, 88, 16, "", false, S3D.window[1])
S3D.edit[1] = guiCreateEdit(41, 207, 259, 22, "", false, S3D.window[1])
S3D.edit[2] = guiCreateEdit(41, 237, 245, 22, "", false, S3D.window[1])
S3D.edit[3] = guiCreateEdit(187, 264, 99, 21, "", false, S3D.window[1])
S3D.edit[4] = guiCreateEdit(227, 289, 59, 22, "", false, S3D.window[1])
S3D.edit[5] = guiCreateEdit(59, 321, 278, 46, "", false, S3D.window[1])
S3D.label[22] = guiCreateLabel(353, 360, 103, 17, "( تحذير | Warning )", false, S3D.window[1])
S3D.label[23] = guiCreateLabel(126, 377, 324, 17, "محاولة إزعاج الإداره آو إدخال معلومات وهميه يعرضك للعقوبه .!", false, S3D.window[1])
S3D.button[1] = guiCreateButton(347, 422, 106, 19, "إغلاق | Close", false, S3D.window[1]) 
S3D.button[2] = guiCreateButton(16, 422, 106, 19, "إرسال | Send", false, S3D.window[1])    

S3D.window[2] = guiCreateWindow(461, 301, 518, 299, ":: Control Of Acc System ::", false)

S3D.gridlist[1] = guiCreateGridList(10, 26, 498, 169, false, S3D.window[2])
guiGridListAddColumn(S3D.gridlist[1], "#", 0.2)
guiGridListAddColumn(S3D.gridlist[1], "Acc_Name", 0.3)
guiGridListAddColumn(S3D.gridlist[1], "Serial", 0.6)
guiGridListAddColumn(S3D.gridlist[1], "Last Login", 0.3)
guiGridListAddColumn(S3D.gridlist[1], "Time", 0.2)
guiGridListAddColumn(S3D.gridlist[1], "Eemil", 0.3)
S3D.label[24] = guiCreateLabel(5, 241, 509, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, S3D.window[2])
S3D.label[26] = guiCreateLabel(201, 222, 113, 15, "Created By ROMCIS", false, S3D.window[2])
guiSetFont(S3D.label[26], "default-bold-small")
guiLabelSetColor(S3D.label[26], 0, 234, 254)
S3D.label[25] = guiCreateLabel(5, 201, 509, 15, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, S3D.window[2]) 
S3D.button[3] = guiCreateButton(20, 262, 136, 23, "نسخ | Copy", false, S3D.window[2])
S3D.button[4] = guiCreateButton(362, 262, 136, 23, "حذف | Delate", false, S3D.window[2])    
S3D.button[5] = guiCreateButton(191, 262, 136, 23, "أغلاق | Close", false, S3D.window[2])      


addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
guiSetVisible(S3D.window[2], false)
guiWindowSetSizable(S3D.window[2], false)
guiSetAlpha(S3D.window[2], 1)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FFFC0000")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF35FC00") 
guiSetProperty(S3D.button[3], "NormalTextColour", "FF30FE00")
guiSetFont(S3D.button[3], "default-bold-small")
guiSetProperty(S3D.button[4], "NormalTextColour", "FFFE0B00") 
guiSetFont(S3D.button[4], "default-bold-small")
guiSetProperty(S3D.button[5], "NormalTextColour", "FFFFFC00")
guiSetFont(S3D.button[5], "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(S3D.label[1], 0, 254, 0)
guiLabelSetColor(S3D.label[2], 0, 254, 0)
guiLabelSetColor(S3D.label[3], 0, 254, 0)
guiLabelSetColor(S3D.label[4], 242, 158, 11)
guiLabelSetColor(S3D.label[5], 242, 158, 11)
guiLabelSetColor(S3D.label[6], 242, 158, 11)
guiLabelSetColor(S3D.label[7], 252, 0, 0)
guiLabelSetColor(S3D.label[8], 232, 252, 0)
guiLabelSetColor(S3D.label[10], 252, 0, 0)
guiLabelSetColor(S3D.label[11], 232, 252, 0)
guiSetFont(S3D.label[12], "default-bold-small")
guiLabelSetColor(S3D.label[12], 232, 252, 0)
guiSetFont(S3D.label[13], "default-bold-small")
guiLabelSetColor(S3D.label[13], 232, 252, 0)
guiSetFont(S3D.label[14], "default-bold-small")
guiLabelSetColor(S3D.label[14], 242, 158, 11)
guiSetFont(S3D.label[15], "default-bold-small")
guiLabelSetColor(S3D.label[15], 242, 158, 11)
guiSetFont(S3D.label[16], "default-bold-small")
guiLabelSetColor(S3D.label[16], 232, 252, 0)
guiSetFont(S3D.label[17], "default-bold-small")
guiLabelSetColor(S3D.label[17], 242, 158, 11)
guiSetFont(S3D.label[18], "default-bold-small")
guiLabelSetColor(S3D.label[18], 232, 252, 0)
guiSetFont(S3D.label[19], "default-bold-small")
guiLabelSetColor(S3D.label[19], 242, 158, 11)
guiSetFont(S3D.label[20], "default-bold-small")
guiLabelSetColor(S3D.label[20], 232, 252, 0)
guiSetFont(S3D.label[21], "default-bold-small")
guiLabelSetColor(S3D.label[21], 242, 158, 11)
guiSetFont(S3D.label[22], "default-bold-small")
guiLabelSetColor(S3D.label[22], 252, 0, 0)
guiSetFont(S3D.label[23], "default-bold-small")
guiLabelSetColor(S3D.label[23], 232, 252, 0)
guiSetFont(S3D.label[24], "default-bold-small")
guiLabelSetColor(S3D.label[24], 254, 1, 1)
guiSetFont(S3D.label[25], "default-bold-small")
guiLabelSetColor(S3D.label[25], 254, 1, 1)   
guiSetFont(S3D.label[26], "default-bold-small")
guiLabelSetColor(S3D.label[26], 0, 234, 254)
end end ) 

function openn()
	triggerServerEvent("Console",localPlayer)
end
addCommandHandler(command,openn)

addEvent("Yess",true)
addEventHandler("Yess",root,
	function ()
		if guiGetVisible(S3D.window[2]) then
			guiSetVisible(S3D.window[2],false)
			showCursor(false)
			guiSetInputEnabled(false)
		else
			guiSetVisible(S3D.window[2],true)
			showCursor(true)
			guiSetInputEnabled(true)
		end
	end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == S3D.button[1] ) then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end
)

addEventHandler("onClientGUIClick",root,
function ( )
if source == S3D.button[5] then
		if guiGetVisible(S3D.window[2]) then
			guiSetVisible(S3D.window[2],false)
			showCursor(false)
			guiSetInputEnabled(false)
		else
			guiSetVisible(S3D.window[2],true)
			showCursor(true)
end
end
end)


addCommandHandler('استرجاع',
function()
if (guiGetVisible(S3D.window[1]) == true) then
guiSetVisible(S3D.window[1],false)
showCursor(false)
else
guiSetVisible(S3D.window[1],true)
showCursor(true)
end
end
)

addEventHandler("onClientGUIClick",root,
function ( )
if source == S3D.button[2] then
local Edit1 = guiGetText(S3D.edit[1])
local Edit2 = guiGetText(S3D.edit[2])
local Edit3 = guiGetText(S3D.edit[3])
local Edit4 = guiGetText(S3D.edit[4])
local Edit5 = guiGetText(S3D.edit[5])
if Edit1 ~= "" or Edit2 ~="" or Edit3~="" or Edit4 ~="" or Edit5 ~="" then
triggerServerEvent("Add",localPlayer,Edit1,Edit2,Edit3,Edit4,Edit5)
outputChatBox("#000000 *[ #00ffff تم أرسال ب نجاح ^ #000000 ]*", 0 , 0 , 255 , true)
guiSetVisible(S3D.window[1],false)
showCursor(false)
guiSetInputEnabled(false)
else
outputChatBox(" هناك فراغ فارغ ، الرجاء تعبئته !", 255 , 255 , 255)
end
end
end)

addEvent( 's3d:refresh', true )
addEventHandler( 's3d:refresh', root,
function( Table )
	guiGridListClear( S3D.gridlist[1] )
		for i, _ in ipairs( Table ) do 
			local item = guiGridListAddRow( S3D.gridlist[1] )
			local dyaz = guiGridListSetItemText( S3D.gridlist[1], item, 1, i.." -" , false, false )
				local userName = guiGridListSetItemText( S3D.gridlist[1], item, 2, Table[i].userName, false, false )
					local Age = guiGridListSetItemText( S3D.gridlist[1], item, 3, Table[i].Age, false, false )
						local why = guiGridListSetItemText( S3D.gridlist[1], item, 4, Table[i].why, false, false )	
						local time = guiGridListSetItemText( S3D.gridlist[1], item, 5, Table[i].time, false, false )	
						local acc = guiGridListSetItemText( S3D.gridlist[1], item, 6, Table[i].acc, false, false )	
guiSetFont(S3D.gridlist[1], "default-bold-small")
	end
end )

addEvent( 's3d:refresh2', true ) addEventHandler( 's3d:refresh2', root, function(  ) guiGridListClear( S3D.gridlist[1] ) end )

addEventHandler( 'onClientResourceStart', resourceRoot,
function(  )
	triggerServerEvent( 's3d;refreshList', Cplayer )
end )

addEvent('s3d:List',true) 
addEventHandler('s3d:List',root, 
function()
guiGridListClear(S3D.gridlist[1])
end )