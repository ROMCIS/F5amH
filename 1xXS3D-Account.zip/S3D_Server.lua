local mainBase = dbConnect( 'sqlite', 's3d - accbase.db' )
dbExec( mainBase, ' CREATE TABLE IF NOT EXISTS `Dataa` ( userName, Age, why, time, acc ) ' )
 
addEvent( 'Add', true )
addEventHandler( 'Add', root,
function( userName , Age , why , time , acc )
local check = dbQuery( mainBase, ' SELECT * FROM `Dataa` WHERE userName = ? ', userName )
dbExec( mainBase, ' INSERT INTO `Dataa` VALUES(?,?,?,?,?) ', userName, Age, why, time, acc, 'false' )
refresh( )
end)

function refreshList(  )
	local check = dbQuery( mainBase, ' SELECT * FROM `Dataa` ')
		local mainTable = dbPoll( check, -1 )
		if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then triggerClientEvent( root, 's3d:refresh2', root ) return end
	triggerClientEvent( root, 's3d;refreshList', root, mainTable )
end
addEvent( 's3d:refresh2', true ) addEventHandler( 's3d:refresh2', root, refreshList )

addEvent("Console",true)
addEventHandler("Console",root,

	function ()
	
		if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(source)),aclGetGroup("Console")) then
		
			triggerClientEvent(source,"Yess",source)

			else
			
			outputChatBox(" * You Are Not A Admin !",source,0,255,255,true)
			
		end
		
	end
)