local Rroot = getResourceRootElement(getThisResource())

S3D = {
    edit = {},
    button = {},
    window = {},
    label = {},
    radiobutton = {}
}

local screenW, screenH = guiGetScreenSize()
S3D.window[1] = guiCreateWindow((screenW - 347) / 2, (screenH - 386) / 2, 347, 386, "-| نظام المخالفات | F5amh Server |-", false)

S3D.label[1] = guiCreateLabel(67, 30, 214, 18, "تنبية : اللوحة مراقبة من داخل الاستضافة", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(53, 58, 238, 17, "يرجى التأكد من صحة السبب قبل صك المخالف", false, S3D.window[1])
S3D.edit[1] = guiCreateEdit(10, 103, 252, 32, "", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(281, 110, 52, 15, "الحساب :", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(281, 173, 42, 15, "السبب :", false, S3D.window[1])
S3D.edit[2] = guiCreateEdit(10, 163, 252, 32, "أدخل السبب ( هــام جدا )", false, S3D.window[1])
S3D.button[1] = guiCreateButton(17, 268, 151, 36, "أرسـال الـمـعلـومـات", false, S3D.window[1])
S3D.radiobutton[1] = guiCreateRadioButton(219, 219, 39, 15, "يوم", false, S3D.window[1])
S3D.radiobutton[2] = guiCreateRadioButton(113, 219, 55, 14, "يومين", false, S3D.window[1])
S3D.radiobutton[3] = guiCreateRadioButton(10, 219, 55, 14, "3 أيام", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(281, 219, 42, 15, "المدة :", false, S3D.window[1])
S3D.button[2] = guiCreateButton(182, 268, 151, 36, "الـسـجـل | Log", false, S3D.window[1])
S3D.button[3] = guiCreateButton(103, 314, 151, 36, "X", false, S3D.window[1])
S3D.label[6] = guiCreateLabel(10, 365, 131, 15, "Beta Version | ROMCIS", false, S3D.window[1])
  
addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1.00)
guiSetProperty(S3D.window[1], "CaptionColour", "FF00FFDD")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF00FF00")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF00FF00")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFFF0000")
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(S3D.label[1], 255, 0, 0)
guiLabelSetColor(S3D.label[2], 0, 255, 0)
guiLabelSetColor(S3D.label[6], 127, 127, 127)  
end
for _, v in ipairs(getElementsByType('gui-radiobutton',Rroot)) do
guiSetFont(v, "default-bold-small")
guiSetProperty(v, "NormalTextColour", "FF00F800")
guiRadioButtonSetSelected(v, false)
for _, v in ipairs(getElementsByType('gui-edit',Rroot)) do
guiSetFont(v, "default-bold-small")
end end end ) 

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == S3D.button[3] ) then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end
)

addEventHandler("onClientGUIClick",root,
function ( )
if source == S3D.button[1] then
Acc = guiGetText(S3D.edit[1])
Why = guiGetText(S3D.edit[2])
Time = guiGetText(S3D.edit[1])
if ( guiGetText(S3D.edit[1]) == "" ) then
exports.infobox:outputMessage('فضلا أدخل الحساب ليتم ارساله للأستضافة للتحق من صحته!',255,0,0,source)
			return
		end
if ( guiGetText(S3D.edit[2]) == "" ) then
exports.infobox:outputMessage('فضلا أدخل السبب ليتم ارساله للأستضافة للتحق من صحته!',255,0,0,source)
else
		if not ( guiRadioButtonGetSelected( S3D.radiobutton[1] ) or guiRadioButtonGetSelected( S3D.radiobutton[2] ) or guiRadioButtonGetSelected( S3D.radiobutton[3] ) ) then
exports.infobox:outputMessage('فضلا يجب اختيار مدة المخالفة !',255,0,0,source)	
			return
		end
if guiRadioButtonGetSelected(S3D.radiobutton[1]) then
-- triggerServerEvent("AdminF:1",localPlayer,Edit1)
triggerServerEvent("AdminF:1",localPlayer,Acc,Time,Why)
exports.infobox:outputMessage('[ Server ]  تم مخالفة الحساب بنجاح',0,255,0,source) end
if guiRadioButtonGetSelected(S3D.radiobutton[2]) then
triggerServerEvent("AdminF:2",localPlayer,Edit1)
exports.infobox:outputMessage('[ Server ]  تم مخالفة الحساب بنجاح',0,255,0,source) end
if guiRadioButtonGetSelected(S3D.radiobutton[3]) then
triggerServerEvent("AdminF:3",localPlayer,Edit1)
exports.infobox:outputMessage('[ Server ]  تم مخالفة الحساب بنجاح',0,255,0,source)
end 
end
end
end)


addCommandHandler('s3d.k9',
function()
if (guiGetVisible(S3D.window[1]) == true) then
guiSetVisible(S3D.window[1],false)
showCursor(false)
else
guiSetVisible(S3D.window[1],true)
showCursor(true)
end
end
)