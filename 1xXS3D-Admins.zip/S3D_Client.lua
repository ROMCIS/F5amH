﻿local Serials ={ 
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
}

local sX, sY = guiGetScreenSize(); 
local visible = true

addEvent ( "RoMcISDATA", true ) 
addEventHandler ( "RoMcISDATA", getRootElement(),
function(message) txt = message; 
end)

function Rom()
if ( txt ) then
dxDrawText ( "Admin :", 14 - 1, 191 - 1, 66 - 1, 209 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Admin :", 14 + 1, 191 - 1, 66 + 1, 209 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)		
dxDrawText ( "Admin :", 14 - 1, 191 + 1, 66 - 1, 209 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Admin :", 14 + 1, 191 + 1, 66 + 1, 209 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Admin :", 14, 191, 66, 209, tocolor(0,255,255), 1.00, "default-bold", "left", "top",false)	

dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 - 1, 191 - 1, 1117 - 1, 210 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 + 1, 191 - 1, 1117 + 1, 210 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 - 1, 191 + 1, 1117 - 1, 210 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 + 1, 191 + 1, 1117 + 1, 210 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText (txt, 61, 191, 1117, 210, tocolor(255, 255, 255, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
end
end

function Rom2()
if ( getElementData(resourceRoot,"RomNAME") ) then
dxDrawText("" .. string.gsub(getElementData(resourceRoot,"RomNAME"), "#%x%x%x%x%x%x", ""), 14 - 1, 213 - 1, 187 - 1, 232 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top", false, false, false, false, false)
dxDrawText("" .. string.gsub(getElementData(resourceRoot,"RomNAME"), "#%x%x%x%x%x%x", ""), 14 + 1, 213 - 1, 187 + 1, 232 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top", false, false, false, false, false)
dxDrawText("" .. string.gsub(getElementData(resourceRoot,"RomNAME"), "#%x%x%x%x%x%x", ""), 14 - 1, 213 + 1, 187 - 1, 232 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top", false, false, false, false, false)
dxDrawText("" .. string.gsub(getElementData(resourceRoot,"RomNAME"), "#%x%x%x%x%x%x", ""), 14 + 1, 213 + 1, 187 + 1, 232 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top", false, false, false, false, false)
dxDrawText("" .. string.gsub(getElementData(resourceRoot,"RomNAME"), "#%x%x%x%x%x%x", ""), 14, 213, 187, 232, tocolor(130, 130, 130, 255), 1.00, "default-bold", "left", "top", false, false, false, false, false)
end
end

addCommandHandler('HideAM_', function() 
if visible == true then 
removeEventHandler("onClientRender", getRootElement(  ),Rom) 
removeEventHandler("onClientRender", getRootElement(  ),Rom2) 
visible = false else end end)
addCommandHandler('ShowAM_',   function() 
if visible == false then 
addEventHandler("onClientRender", getRootElement(  ),Rom) 
addEventHandler("onClientRender", getRootElement(  ),Rom2) 
visible = true else end end)

bindKey ( "i", "down", "chatbox", "AM" )

setTimer ( function () 
addEventHandler("onClientRender",getRootElement(),Rom) 
addEventHandler("onClientRender",getRootElement(),Rom2) 
end, 3500, 1)

addEventHandler ( "onClientResourceStart", resourceRoot, 
function (  ) 
setTimer ( function() 
triggerServerEvent ( "ShowAM", localPlayer ) end, 3500, 1 ) 
end )

addEvent ( "s3d_hide", true ) 
addEventHandler ( "s3d_hide", getRootElement(),
function (  ) 
removeEventHandler("onClientRender", getRootElement(  ),Rom) 
removeEventHandler("onClientRender", getRootElement(  ),Rom2) 
end)

addEvent ( "s3d_show", true ) 
addEventHandler ( "s3d_show", getRootElement(),
function (  ) 
addEventHandler("onClientRender", getRootElement(  ),Rom) 
addEventHandler("onClientRender", getRootElement(  ),Rom2) 
end)

ROMCIS = {
    edit = {},
    button = {},
    window = {},
    label = {}
}


Change = guiCreateWindow(592, 367, 322, 216, "=[ Change Name AM ]=", false)
guiWindowSetSizable(Change, false)
guiSetAlpha(Change, 1.00)
guiSetProperty(Change, "CaptionColour", "FF00E3D5")
guiSetVisible(Change,false)
ROMCIS.label[2] = guiCreateLabel(20, 42, 96, 24, "Change :", false, Change)
guiSetFont(ROMCIS.label[2], "default-bold-small")
guiLabelSetColor(ROMCIS.label[2], 227, 213, 0)
ROMCIS.edit[2] = guiCreateEdit(30, 83, 252, 31, "", false, Change)
ROMCIS.button[4] = guiCreateButton(91, 170, 136, 31, "Close !", false, Change)
guiSetFont(ROMCIS.button[4], "default-bold-small")
guiSetProperty(ROMCIS.button[4], "NormalTextColour", "FFE30000")
ROMCIS.button[5] = guiCreateButton(91, 129, 136, 31, "Change !", false, Change)
guiSetFont(ROMCIS.button[5], "default-bold-small")
guiSetProperty(ROMCIS.button[5], "NormalTextColour", "FF00FF00") 

addEventHandler("onClientMouseEnter",resourceRoot,
function()
if ( source == ROMCIS.button[4] ) then
guiLabelSetColor(ROMCIS.button[4], 255, 255, 255)
end
end
)

addCommandHandler('s3d.nick',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('عذرآ انت لا تمتلك الخاصية . . !', 255, 0, 0, true) return end
guiSetVisible(Change,not guiGetVisible(Change))
showCursor(guiGetVisible(Change))
end)

addEventHandler("onClientGUIClick",root,
function()
if (source == ROMCIS.button[4]) then
guiSetVisible(Change,false)
showCursor(false)
end end)

addEventHandler("onClientGUIClick",root,
function()
if (source == ROMCIS.button[5]) then
local Text = guiGetText(ROMCIS.edit[2])
	setElementData ( resourceRoot, "RomNAME", Text)
end end )