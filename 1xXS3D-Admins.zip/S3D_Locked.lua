﻿RoMcIS = {
	{"العاجل مغلق"},
	{"العاجل مغلق مؤقتآ"},
	{"العاجل مغلق مؤقتآ (:"},
	{"-"},
	{"-"},
	{"-"},
	{"-"},
	{"-"},
	{"-"},
}

local Rroot = getResourceRootElement(getThisResource())

local Serials ={ 
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
}

S3D = {
    gridlist = {},
    label = {},
    button = {},
    edit = {}
}


Locked = guiCreateWindow(556, 279, 321, 347, "=[ Locked AM | T.S ]=", false)
S3D.label[1] = guiCreateLabel(36, 30, 255, 15, "الرسالة التي تريد الظهور بشات عندما يكون مغلق", false, Locked)
S3D.gridlist[1] = guiCreateGridList(10, 64, 302, 154, false, Locked)
guiGridListAddColumn(S3D.gridlist[1], "T.S", 1.2)
S3D.edit[1] = guiCreateEdit(30, 233, 261, 23, "", false, Locked)
S3D.button[1] = guiCreateButton(10, 266, 131, 24, "=[ Locked ]=", false, Locked)
S3D.button[2] = guiCreateButton(180, 266, 131, 24, "=[ Open ]=", false, Locked)
S3D.button[3] = guiCreateButton(95, 305, 131, 24, "=[ Close ]=", false, Locked)

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(Locked, false)
guiWindowSetSizable(Locked, false)
guiSetAlpha(Locked, 1)
guiSetProperty(Locked, "CaptionColour", "FF00FED7")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF17FC00")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF17FC00")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFFB0000") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(S3D.label[1], 233, 253, 0)
end end ) 

addEventHandler("onClientGUIClick",root, 
function() 
if (source == S3D.button[3]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(Locked, false) 
elseif (source==S3D.button[1]) then
local txt=guiGetText(S3D.edit[1])
if #txt<=0 then exports.infobox:outputMessage("يرجى إدخال الرسالة التنبهية",255,0,0,true) return end
triggerServerEvent("Rom_Lockedfuck",localPlayer,txt)
elseif (source==S3D.button[2]) then
triggerServerEvent("Rom_Openfuck",localPlayer)
end end )	

for i,ha in ipairs(RoMcIS) do
local row = guiGridListAddRow(S3D.gridlist[1])
guiGridListSetItemText(S3D.gridlist[1],row,1,ha[1],false,false)
guiSetFont( S3D.gridlist[1] , "default-bold-small")
guiGridListSetItemColor(S3D.gridlist[1],row,1,math.random ( 0, 255),math.random ( 0, 255 ),math.random ( 0, 255 ))
end

function clickButtons( )
if ( source == S3D.gridlist[1] ) then
local Sel = guiGridListGetSelectedItem( S3D.gridlist[1] )
if ( Sel ~= -1 ) then
guiSetText( S3D.edit[1], guiGridListGetItemText( S3D.gridlist[1], Sel, 1 ) )
end
end
end
addEventHandler( 'onClientGUIClick', root, clickButtons )

addCommandHandler('s3d_am1', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(Locked,not guiGetVisible(Locked)) 
showCursor(guiGetVisible(Locked)) 
guiSetInputEnabled(guiGetVisible(Locked)) 
triggerServerEvent('Rom_GetAllfuck', localPlayer) 
triggerServerEvent('Active_Dev1', localPlayer)
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )