﻿addEventHandler ( "onResourceStart", resourceRoot, function (  )
executeSQLQuery("CREATE TABLE IF NOT EXISTS Server_Savenum1 (Message, Server)")
executeSQLQuery("CREATE TABLE IF NOT EXISTS mstrmsg (Message)")
end )

function getCloseMsg()
local msg = executeSQLQuery ( "SELECT * FROM mstrmsg " )
if #msg~=0 then
return msg[1]['Message']
end
return false
end

addEvent("Rom_Lockedfuck",true)
addEventHandler("Rom_Lockedfuck",root,function (txt)
local player=source
local msg=getCloseMsg()
if msg then executeSQLQuery("DELETE FROM mstrmsg WHERE Message=?",msg) end
executeSQLQuery("INSERT INTO mstrmsg VALUES(?)",txt)
setElementData(resourceRoot,"LockedAM",true)
OutPut('! تم إقفال العاجل بنجاح *',player,255,0,0) 
end)

addEvent("Rom_Openfuck",true)
addEventHandler("Rom_Openfuck",root,function (txt)
local player=source
if ( getElementData(resourceRoot,"LockedAM") == true ) then
setElementData(resourceRoot,"LockedAM",false)
OutPut('! تم فتح العاجل بنجاح *',player,50,255,0)
else
OutPut('! العاجل مفتوح مسبقا *',player,255,0,0)
end end)

local db=dbConnect('sqlite','Rom_SaveSerial.db')
dbExec( db, ' CREATE TABLE IF NOT EXISTS `AddServer_Rom` (Serial) ' )
function check ( thePlayer, commandName, ... )
local accName = getAccountName ( getPlayerAccount ( thePlayer ) ) 
local veve = { ... }
local message = table.concat ( veve, " " )
local CheckResults = dbQuery( db, ' SELECT * FROM `AddServer_Rom` WHERE Serial = ? ', getPlayerSerial(thePlayer) )
local GetData = dbPoll( CheckResults, -1 )
if ( getElementData(resourceRoot,"LockedAM") == true ) then return outputChatBox(getCloseMsg(),thePlayer,255,0,0,true) end
if ( type ( GetData ) == 'table' and #GetData == 0 or not GetData ) then return end
-- exports["dxmessages"]:outputDx(root, "", "success")
local ROMCISPro= '[ '..getPlayerName(thePlayer)..' ] : تم تعديل العاجل من قبل المسؤول السيرفر | لطفا الانتباه إليه'
triggerEvent ( "tounsi_AllMessage", root,player,ROMCISPro,4,2,'#33ff000',true)
-- setTimer ( function () 
setElementData ( resourceRoot, "DATARom", message);
setElementData(resourceRoot,"RomNAME",getPlayerName(thePlayer));
SaveMessage (  )
triggerClientEvent ( "RoMcISDATA", getRootElement(  ), getElementData ( resourceRoot, "DATARom" ) )
-- end, 5000, 1)
end
addCommandHandler( "AM", check )

function OutPut(message, player, r, g, b) 
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

function getPlayerFromSerial ( serial )
assert ( type ( serial ) == "string" and #serial == 32, "getPlayerFromSerial - invalid serial" )
for index, player in ipairs ( getElementsByType ( "player" ) ) do
if ( getPlayerSerial ( player ) == serial ) then
return player
end
end
return false
end

addEvent('RoMcIS_Check',true)
addEventHandler('RoMcIS_Check',root,
function( Pserial )
local CheckedSerial = getPlayerFromSerial( Pserial )
if (CheckedSerial == nil or not CheckedSerial) then return OutPut('يجب على الاعب الإتصال بالسيرفر لى يتم تفعيل سرياله', source, 255,0,0, false) end
local CheckResults = dbQuery( db, ' SELECT * FROM `AddServer_Rom` WHERE Serial = ? ', Pserial )
local GetData = dbPoll( CheckResults, -1 )
if ( type ( GetData ) == 'table' and #GetData == 0 or not GetData ) then
dbExec(db, ' INSERT INTO `AddServer_Rom` (Serial) VALUES(?) ', Pserial )
OutPut('تم تفعيل المستخدم بنجاح ! تهانينا ^', source, 50,255,0, false)
RefreshImPlayers()
else
OutPut('! تم تفعيل السريال مسبقا يرجى الإنتباه', source, 240,255,0, false)
end
end)

function RefreshImPlayers()
local CheckThatPlSS = dbQuery( db, ' SELECT * FROM `AddServer_Rom` ' )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return triggerClientEvent(source, 'RoMcIS_gridlist', source) end
triggerClientEvent(source, "RoMcIS_AddPlayers", source, checkData)
end
addEvent( 'Rom_GetAllfuck', true )
addEventHandler( 'Rom_GetAllfuck', root, RefreshImPlayers)

addEvent('RoMcIS_RemoveSerial',true)
addEventHandler('RoMcIS_RemoveSerial',root,
function( Player )
local SerialCheck = getPlayerFromSerial( Player ) 
local CheckThatPlSS = dbQuery( db, ' SELECT * FROM `AddServer_Rom` WHERE Serial = ? ', Player )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return end
dbExec(db, ' DELETE FROM `AddServer_Rom` WHERE Serial = ? ', Player )
OutPut('تم إزالة السريال !', source, 50,255,0, false)
RefreshImPlayers()
end)

addEvent ( "ShowAM", true ) 
addEventHandler ( "ShowAM", root, 
function (  ) getMessage (  ) 
end )

SaveMessage = function (  )
local msg = executeSQLQuery ( "SELECT * FROM Server_Savenum1 WHERE Server = '" .. getServerName ( ) .."'" )
if ( #msg ~= 0  )   then
return executeSQLQuery("UPDATE Server_Savenum1 SET Message=? WHERE Server=? ", tostring ( getElementData ( resourceRoot, "DATARom"  ) ), getServerName ( ) )
else
return executeSQLQuery("INSERT INTO Server_Savenum1 (Message,Server) VALUES(?,?)", tostring ( getElementData ( resourceRoot, "DATARom" ) ), getServerName ( ) ) end end 
getMessage = function (  )
local msg = executeSQLQuery ( "SELECT * FROM Server_Savenum1" )
if ( #msg ~= 0  ) then
setElementData ( resourceRoot, "DATARom", msg[1]["Message"] )
return 
setTimer ( triggerClientEvent, 3500, 1, "RoMcISDATA", getRootElement(  ), getElementData ( resourceRoot, "DATARom" ) )
else
return 
setTimer ( triggerClientEvent, 3500, 1, "RoMcISDATA", getRootElement(  ), " " ) 
end end 