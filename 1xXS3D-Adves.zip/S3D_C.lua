function centerWindow(center_window)
  local screenW, screenH = guiGetScreenSize()
  local windowW, windowH = guiGetSize(center_window, false)
  local x, y = (screenW - windowW) / 2, (screenH - windowH) / 2
  guiSetPosition(center_window, x, y, false)
end

local Rroot = getResourceRootElement(getThisResource())

local Serials ={ 
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
}

S3D = {
    button = {},
    window = {},
    label = {},
    edit = {}
}
local screenW, screenH = guiGetScreenSize()
S3D.window[1] = guiCreateWindow((screenW - 384) / 2, (screenH - 163) / 2, 384, 163, "=[ Wzarh Control Adves ]=", false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1.00)
guiSetProperty(S3D.window[1], "CaptionColour", "FFFC005F")
guiSetVisible(S3D.window[1],false)

S3D.label[3] = guiCreateLabel(62, 33, 261, 15, "Adves : تعديل الرسالة الإدارية لـشاشـات الاعبين", false, S3D.window[1])
guiSetFont(S3D.label[3], "default-bold-small")
S3D.edit[1] = guiCreateEdit(9, 58, 365, 25, "", false, S3D.window[1])
S3D.button[1] = guiCreateButton(102, 93, 180, 21, "Change Adves", false, S3D.window[1])
guiSetFont(S3D.button[1], "default-bold-small")
guiSetProperty(S3D.button[1], "NormalTextColour", "FFFD0047")
Close = guiCreateButton(102, 124, 180, 18, "X", false, S3D.window[1])
guiSetFont(Close, "default-bold-small")
guiSetProperty(Close, "NormalTextColour", "FF158993")

addEventHandler("onClientGUIClick",root, 
function() 
if (source == Close) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(S3D.window[1], false) 
elseif (source == S3D.button[1]) then 
local txt=guiGetText( S3D.edit[1])
if #txt<=0 then outputChatBox("يجب عليك ادخال العاجل",255,0,0,true) return end
triggerServerEvent("chngadv",localPlayer,txt)
end end )

addCommandHandler('s3d.adves', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1])) 
showCursor(guiGetVisible(S3D.window[1])) 
guiSetInputEnabled(guiGetVisible(S3D.window[1])) 
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )