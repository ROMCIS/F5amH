﻿local sX, sY = guiGetScreenSize();
local visible = true

addEvent ( "Dev_Management", true )
addEventHandler ( "Dev_Management", getRootElement(),function(message)
txt = message;
end)

function Dev2 ()
if ( txt ) then
dxDrawText ( "Adves :", 14 - 1, 242 - 1, 66 - 1, 209 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Adves :", 14 + 1, 242 - 1, 66 + 1, 209 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)		
dxDrawText ( "Adves :", 14 - 1, 242 + 1, 66 - 1, 209 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Adves :", 14 + 1, 242 + 1, 66 + 1, 209 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "top",false)	
dxDrawText ( "Adves :", 14, 242, 66, 209, tocolor(254, 63, 63), 1.00, "default-bold", "left", "top",false)	

dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 - 1, 290 - 1, 1117 - 1, 210 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 + 1, 290 - 1, 1117 + 1, 210 - 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 - 1, 290 + 1, 1117 - 1, 210 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText("" .. string.gsub(txt, "#%x%x%x%x%x%x", ""), 61 + 1, 290 + 1, 1117 + 1, 210 + 1, tocolor(0, 0, 0, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)
dxDrawText (txt, 61, 290, 1117, 210, tocolor(255, 255, 255, 255), 1.00, "default-bold", "left", "center", true, true, false, true, false)

else
end
end
addCommandHandler('HideManagement_',   function() if visible == true then    removeEventHandler("onClientRender", getRootElement(  ),Dev2) visible = false else end end)
addCommandHandler('ShowManagement_',   function() if visible == false then   addEventHandler("onClientRender", getRootElement(  ),Dev2) visible = true else end end)
addEventHandler("onClientRender", getRootElement(),Dev2)
addEventHandler( "onClientResourceStart", resourceRoot, function () setTimer ( function() triggerServerEvent ( "ShowManagement", localPlayer ) end, 3500, 1 ) end )