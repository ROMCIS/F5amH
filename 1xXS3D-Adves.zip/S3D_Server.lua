function OutPut(message, player, r, g, b) 
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEventHandler ( "onResourceStart", resourceRoot, function (  )
executeSQLQuery("CREATE TABLE IF NOT EXISTS SQL_Dev (Message, Server)")
end)
addEvent("chngadv",true)addEventHandler("chngadv",root,function (txt)
local message = txt	
setElementData ( resourceRoot, "DevSave", message);
SaveMessage (  )
triggerClientEvent ( "Dev_Management", getRootElement(  ), getElementData ( resourceRoot, "DevSave" ) )
end)
 
addEvent ( "ShowManagement", true ) addEventHandler ( "ShowManagement", root, function () getMessage () end )

SaveMessage = function (  )
local msg = executeSQLQuery ( "SELECT * FROM SQL_Dev WHERE Server = '" .. getServerName ( ) .."'" )
if ( #msg ~= 0  )   then
return executeSQLQuery("UPDATE SQL_Dev SET Message=? WHERE Server=? ", tostring ( getElementData ( resourceRoot, "DevSave"  ) ), getServerName ( ) )
else
return executeSQLQuery("INSERT INTO SQL_Dev (Message,Server) VALUES(?,?)", tostring ( getElementData ( resourceRoot, "DevSave" ) ), getServerName ( ) ) end end 
getMessage = function (  )
local msg = executeSQLQuery ( "SELECT * FROM SQL_Dev" )
if ( #msg ~= 0  ) then
setElementData ( resourceRoot, "DevSave", msg[1]["Message"] )
return setTimer ( triggerClientEvent, 3500, 1, "Dev_Management", getRootElement(  ), getElementData ( resourceRoot, "DevSave" ) )
else
return setTimer ( triggerClientEvent, 3500, 1, "Dev_Management", getRootElement(  ), " " ) 
end end