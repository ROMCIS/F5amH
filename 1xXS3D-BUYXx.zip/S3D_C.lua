﻿local Serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["1A5AE4945A35897595921B1F48DE5854"] = true, -- فان دام
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
}

Cplayer = getLocalPlayer(  )
local Rroot = getResourceRootElement(getThisResource())

ROMCIS = {
    button = {},
    window = {},
    label = {}
}

ROMCIS.window[2] = guiCreateWindow(572, 309, 308, 183, "-| Control Of : F5amh Buy System |-", false)
guiWindowSetSizable(ROMCIS.window[2], false)
guiSetAlpha(ROMCIS.window[2], 1.00)
guiSetProperty(ROMCIS.window[2], "CaptionColour", "FF00FBFD")

ROMCIS.label[15] = guiCreateLabel(47, 27, 212, 18, "-[ T.S | التحكم في لوحة الشراء | T.S ]-", false, ROMCIS.window[2])
ROMCIS.button[5] = guiCreateButton(10, 80, 131, 33, ": أغلاق البيع :", false, ROMCIS.window[2])
ROMCIS.button[6] = guiCreateButton(167, 80, 131, 33, ": فتح البيع :", false, ROMCIS.window[2])
ROMCIS.label[16] = guiCreateLabel(117, 55, 69, 15, "حـالـة الـبـيـع", false, ROMCIS.window[2])
ROMCIS.button[7] = guiCreateButton(89, 131, 131, 33, ": Close | اغلاق :", false, ROMCIS.window[2]) 


addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(ROMCIS.window[2], false)
guiWindowSetSizable(ROMCIS.window[2], false)
guiSetAlpha(ROMCIS.window[2], 0.97)
guiSetProperty(ROMCIS.window[2], "CaptionColour", "FF0C00FE")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(ROMCIS.button[5], "NormalTextColour", "FFFA0000")
guiSetProperty(ROMCIS.button[6], "NormalTextColour", "FF1DFB00")
guiSetProperty(ROMCIS.button[7], "NormalTextColour", "FFFA0000")   
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(ROMCIS.label[15], 5, 0, 254)
guiLabelSetColor(ROMCIS.label[16], 252, 0, 208)
guiSetFont(v, "default-bold-small")
end end ) 

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[7] ) then
guiSetVisible(ROMCIS.window[2], false)
showCursor(false)
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[5] ) then
state_Sell = 'close'
guiSetSize( S3D.window[1], 664, 202, false)
guiSetText( S3D.label[5], 'مغلق لفترة مؤقتآ !.' )
exports.infobox:outputMessage("[ F5amh: تم اغلاق حالة البيع بنجاح ]",255,0,0,true)
triggerServerEvent( 'ROMCIS;changeSellState', Cplayer, state_Sell )
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == ROMCIS.button[6] ) then
state_Sell = 'open'
guiSetSize( S3D.window[1], 664, 583, false)
guiSetText( S3D.label[5], '   مفتوح الأن !.      ' )
exports.infobox:outputMessage("[ F5amh: تم فتح حالة البيع بنجاح ]",50,255,0,true)
triggerServerEvent( 'ROMCIS;changeSellState', Cplayer, state_Sell )
--triggerServerEvent( 'ROMCIS;changeSpecialState', Cplayer, specialState, specialValue )
end
end
)

addEvent( 'ROMCIS;refreshWindow', true )
addEventHandler( 'ROMCIS;refreshWindow', root,
function( state )
	if ( state == 'open' ) then guiSetSize( S3D.window[1], 664, 583, false) guiSetText( S3D.label[5], '   مفتوح الأن !.      ' )
		else
         guiSetSize( S3D.window[1], 664, 202, false) guiSetText( S3D.label[5], 'مغلق لفترة مؤقتآ !.' )
end
end )


addEventHandler( 'onClientResourceStart', resourceRoot,
function(  )
	triggerServerEvent( 'ROMCIS;refreshWindow', Cplayer )
end )

addCommandHandler('edit.buy',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('عذرآ انت لا تمتلك الخاصية . . !', 255, 0, 0, true) return end
guiSetVisible(ROMCIS.window[2],not guiGetVisible(ROMCIS.window[2]))
showCursor(guiGetVisible(ROMCIS.window[2]))
end)

addCommandHandler('s3d.unlocked',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('يجب ان تمتلك صلاحية الادمنية', 255, 0, 0, true) return end
state_Sell = 'open'
guiSetSize( S3D.window[1], 664, 583, false)
guiSetText( S3D.label[5], '   مفتوح الأن !.      ' )
exports.infobox:outputMessage("تم فتح البيع والشراء",50,255,0,true)
triggerServerEvent( 'ROMCIS;changeSellState', Cplayer, state_Sell )
end)

addCommandHandler('s3d.locked',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('يجب ان تمتلك صلاحية الادمنية', 255, 0, 0, true) return end
state_Sell = 'close'
guiSetSize( S3D.window[1], 664, 202, false)
guiSetText( S3D.label[5], 'مغلق لفترة مؤقتآ !.' )
exports.infobox:outputMessage("تم اغلاق البيع والشراء",255,0,0,true)
triggerServerEvent( 'ROMCIS;changeSellState', Cplayer, state_Sell )
end)