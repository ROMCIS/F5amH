﻿local reports = {}
table.insert (reports,"Nawaf") -- نضيف للجدول اسم نواف
local Rroot = getResourceRootElement(getThisResource())

S3D = {
    checkbox = {},
    label = {},
    radiobutton = {},
    button = {},
    window = {},
    edit = {},
    combobox = {}
}
 

S3D.window[1] = guiCreateWindow(382, 171, 664, 583, "=[ لوحة الشراء ]=", false)

S3D.label[14] = guiCreateLabel(308, 24, 48, 15, "تعليمات :", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(159, 70, 495, 15, "*جميع بطايق الشحن والبايبل يتم وضعها في هذه اللوحه حماية للاعب من النصب وسرقة المال!.", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(5, 116, 643, 15, "*الأدارة غير مسؤولة تماما عن أي تعاملات خارج هذه اللوحة | للعلم أن كل 200 ساعة ب 20 ريال غير شاملة الضريبة المضافه!.", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(546, 154, 58, 15, "حالة البيع :", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(404, 162, 110, 20, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(404, 152, 105, 17, "   مفتوح الأن !.      ", false, S3D.window[1])
S3D.label[6] = guiCreateLabel(404, 172, 110, 20, "▬▬▬▬▬▬▬▬▬▬▬▬▬▬", false, S3D.window[1])
S3D.label[7] = guiCreateLabel(43, 202, 386, 14, "┃┃┃ ملاحظة : سعر كل 1200 ساعة 115 سوآ - اللقب الخاص = 60 سواآ ┃┃┃", false, S3D.window[1])
S3D.label[8] = guiCreateLabel(112, 265, 542, 15, "| يمنع تجاوز شراء الساعات أو مجموع ساعات الاعب = 3500 | زخرفة اسمك اف7 اعلى الاعبين 40 سوآ !.", false, S3D.window[1])
S3D.label[9] = guiCreateLabel(190, 313, 354, 15, "طريقة الشحن : يتم اضافة جميع الأرقام وبعدها يتم ارسال المعلومات.", false, S3D.window[1])
S3D.label[10] = guiCreateLabel(534, 374, 81, 16, "طريقة الشحن :", false, S3D.window[1])
S3D.label[11] = guiCreateLabel(517, 416, 114, 15, "الشيء المراد شرائه :", false, S3D.window[1])
S3D.label[12] = guiCreateLabel(517, 459, 114, 15, "أرقام بطاقات الشحن :", false, S3D.window[1])
S3D.label[13] = guiCreateLabel(303, 490, 122, 15, "جميع الأرقام المضافة :", false, S3D.window[1])
S3D.radiobutton[1] = guiCreateRadioButton(395, 374, 78, 15, "سوا - Swa", false, S3D.window[1])
S3D.radiobutton[2] = guiCreateRadioButton(106, 374, 94, 15, "بيبال - Paypal", false, S3D.window[1])
S3D.checkbox[1] = guiCreateCheckBox(395, 415, 59, 16, "ساعات", false, false, S3D.window[1])
S3D.checkbox[2] = guiCreateCheckBox(238, 415, 97, 16, "لقب خاص - تاج", false, false, S3D.window[1])
S3D.checkbox[3] = guiCreateCheckBox(36, 415, 154, 16, "زخرفة اعلى اللاعبين اف9", true, false, S3D.window[1])
S3D.checkbox[4] = guiCreateCheckBox(36, 451, 97, 16, "النك العربي", true, false, S3D.window[1])
S3D.button[1] = guiCreateButton(604, 25, 50, 35, "X", false, S3D.window[1])
S3D.button[2] = guiCreateButton(158, 453, 112, 31, "اضافة الرقم المكتوب", false, S3D.window[1])
S3D.button[3] = guiCreateButton(519, 510, 112, 31, "حذف الرقم المختار", false, S3D.window[1])
S3D.button[4] = guiCreateButton(11, 494, 112, 47, "ارسال المعلومات", false, S3D.window[1])
S3D.edit[1] = guiCreateEdit(280, 451, 180, 33, "", false, S3D.window[1])
S3D.combobox[1] = guiCreateComboBox(224, 515, 275, 58, "", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 0.97)
guiSetProperty(S3D.window[1], "CaptionColour", "FF0C00FE")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF00E3FD")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF19E487")
guiSetProperty(S3D.button[3], "NormalTextColour", "FF19E487")
guiSetProperty(S3D.button[4], "NormalTextColour", "FF19E487") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-checkbox',Rroot)) do
guiCheckBoxSetSelected( v, false )
guiSetProperty(S3D.checkbox[1], "NormalTextColour", "FF36FE00")
guiSetProperty(S3D.checkbox[2], "NormalTextColour", "FF36FE00")
guiSetProperty(S3D.checkbox[3], "NormalTextColour", "FF36FE00")
guiSetProperty(S3D.checkbox[4], "NormalTextColour", "FF36FE00")
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-radiobutton',Rroot)) do
guiSetProperty(v, "NormalTextColour", "FF36FE00")
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(S3D.label[1], 247, 96, 5)
guiLabelSetColor(S3D.label[2], 247, 96, 5)
guiLabelSetColor(S3D.label[3], 248, 251, 0)
guiLabelSetColor(S3D.label[4], 226, 13, 53)
guiLabelSetColor(S3D.label[5], 0, 227, 253)
guiLabelSetColor(S3D.label[6], 226, 13, 53)
guiLabelSetColor(S3D.label[7], 0, 227, 253)
guiLabelSetColor(S3D.label[8], 0, 227, 253)
guiLabelSetColor(S3D.label[9], 11, 252, 0)
guiLabelSetColor(S3D.label[10], 248, 251, 0)
guiLabelSetColor(S3D.label[11], 248, 251, 0)
guiLabelSetColor(S3D.label[12], 248, 251, 0)
guiLabelSetColor(S3D.label[13], 248, 251, 0)
guiLabelSetColor(S3D.label[14], 248, 251, 0)  
guiSetFont(v, "default-bold-small")
end end ) 

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == S3D.button[1] ) then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end
)

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == S3D.button[2] ) then
local CN1 = guiGetText( S3D.edit[1] )
if ( not tonumber( CN1 ) ) then
exports.infobox:outputMessage("يجب أن يتكون رقم بطاقة الشحن من أرقام فقط !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local Set = tonumber ( guiGetText ( S3D.edit[1] ) )
if ( Set <= 1000000000 ) then
exports.infobox:outputMessage("يجب أن يتكون رقم بطاقة الشحن من 10 أرقام أو اكثر !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local add=guiGetText(S3D.edit[1])
if #add<=0 then exports.infobox:outputMessage("عفوا محاولة غير صحيحة لايوجد رقم !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local Data = guiGetText(S3D.edit[1])
guiComboBoxAddItem(S3D.combobox[1],Data)
exports.infobox:outputMessage("تهانينا تم اضافة الرقم بنجاح !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
if hasReport(number) then
exports.infobox:outputMessage("الرقم مضاف مسبقا لايمكنك اضافته مرة اخرى !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source)
	elseif ( source == S3D.checkbox[1] ) then
guiCheckBoxSetSelected( S3D.checkbox[2], false )
guiCheckBoxSetSelected( S3D.checkbox[3], false )
guiCheckBoxSetSelected( S3D.checkbox[4], false )
	elseif ( source == S3D.checkbox[2] ) then
guiCheckBoxSetSelected( S3D.checkbox[1], false )
guiCheckBoxSetSelected( S3D.checkbox[3], false )
guiCheckBoxSetSelected( S3D.checkbox[4], false )
	elseif ( source == S3D.checkbox[3] ) then
guiCheckBoxSetSelected( S3D.checkbox[2], false )
guiCheckBoxSetSelected( S3D.checkbox[1], false )
guiCheckBoxSetSelected( S3D.checkbox[4], false )
	elseif ( source == S3D.checkbox[4] ) then
guiCheckBoxSetSelected( S3D.checkbox[2], false )
guiCheckBoxSetSelected( S3D.checkbox[3], false )
guiCheckBoxSetSelected( S3D.checkbox[1], false )
elseif ( source == S3D.button[3] ) then
local Sel = guiComboBoxGetSelected( S3D.combobox[1] )
if ( Sel == -1 ) then
exports.infobox:outputMessage("عفوا محاولة غير صحيحة لايوجد رقم !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local item = guiComboBoxGetSelected ( S3D.combobox[1] )
guiComboBoxRemoveItem(S3D.combobox[1],item)
exports.infobox:outputMessage("تهانينا تم حذف الرقم !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source)
elseif ( source == S3D.button[4] ) then
local CB1 = guiRadioButtonGetSelected( S3D.radiobutton[1] )
local CB2 = guiRadioButtonGetSelected( S3D.radiobutton[2] )
if ( CB1 == false and CB2 == false ) then
exports.infobox:outputMessage ("يجب عليك أختيار طريقة الدفع",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local Co1 = guiGetText( S3D.combobox[1] )
if ( not tonumber( Co1 ) ) then
exports.infobox:outputMessage ("يجب أدخال رقم بطاقة واحد على ألأقل أو اكثر من رقم",math.random(0, 255), math.random(0, 255), math.random(0, 255),source) return end
local CZ1 = guiCheckBoxGetSelected( S3D.checkbox[1] )
local CZ2 = guiCheckBoxGetSelected( S3D.checkbox[2] )
local CZ3 = guiCheckBoxGetSelected( S3D.checkbox[3] )
local CZ4 = guiCheckBoxGetSelected( S3D.checkbox[4] )
if ( CZ1 == false and CZ2 == false and CZ3 == false and CZ4 == false ) then
exports.infobox:outputMessage("يجب عليك أختيار الشيء المراد شرائه !",math.random(0, 255), math.random(0, 255), math.random(0, 255),source)
end
end
end
)


function hasReport(number) -- فنكشن يعلمنا اذا الاسم عليه بلاغ
    for i,v in ipairs ( reports ) do -- نسوي للوب للجدول
      if v == number then -- اذا الاسم المعطى يساوي يلي باللوب
      return true -- نرجع ترو اذا صح وبيوقف اللوب
      end
    end
  return false   -- نرجع فولس اذا انتهى اللوب وماتطابق
end

hasReport("Nawaf") -- true
hasReport("Ahmed") -- false


addCommandHandler('شراء',
function()
if (guiGetVisible(S3D.window[1]) == true) then
guiSetVisible(S3D.window[1],false)
showCursor(false)
else
guiSetVisible(S3D.window[1],true)
showCursor(true)
end
end
)