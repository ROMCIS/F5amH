﻿local RSDB = dbConnect( 'sqlite', 'S3D - BuySysteam' )
dbExec( RSDB, ' CREATE TABLE IF NOT EXISTS `Rent_System-SysStats` ( sellState, specialState, specialValue ) ' )

function refreshWindow(  )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then return end
		local state = mainTable[1]['sellState']
	triggerClientEvent( root, 'ROMCIS;refreshWindow', root, state )
		local specialState = mainTable[1]['specialState']
		local specialValue = mainTable[1]['specialValue']
end
addEvent( 'ROMCIS;refreshWindow', true )
addEventHandler( 'ROMCIS;refreshWindow', root, refreshWindow )


addEvent( 'ROMCIS;changeSpecialState', true )
addEventHandler( 'ROMCIS;changeSpecialState', root,
function( specialState, specialValue )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then
		dbExec( RSDB, ' INSERT INTO `Rent_System-SysStats` VALUES(?,?,?) ', nil, specialState, specialValue )
			else
		dbExec( RSDB, ' UPDATE `Rent_System-SysStats` SET specialState = ?, specialValue = ? ', specialState, specialValue )
	end
-- outputChatBox( '', source, 255, 255, 255, true )
	refreshList(  )
refreshWindow(  )
end )

addEvent( 'ROMCIS;changeSellState', true )
addEventHandler( 'ROMCIS;changeSellState', root,
function( state )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then
				dbExec( RSDB, ' INSERT INTO `Rent_System-SysStats` VALUES(?,?,?) ', state, nil, nil )
			else
		dbExec( RSDB, ' UPDATE `Rent_System-SysStats` SET sellState = ? ', state )
	end
-- outputChatBox( '', source, 255, 255, 255, true )
refreshWindow(  )
end )
