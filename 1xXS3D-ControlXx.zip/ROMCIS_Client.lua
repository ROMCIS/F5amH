local Rroot = getResourceRootElement(getThisResource())

List = {
 {"1 min"},
 {"2 mins"},
 {"5 mins"},
 {"10 mins"},
 {"10 Day"},
 {"20 Day"},
 {"1 Day"},
 {"2 Day"},
}

S3D = {
    gridlist = {},
    window = {},
    label = {},
    button = {},
    edit = {}
}

S3D_Control = guiCreateWindow(487, 221, 467, 459, "=[ Control Player ]=", false)

S3D.edit[3] = guiCreateEdit(10, 34, 174, 33, "Search :", false, S3D_Control)  
S3D.gridlist[1] = guiCreateGridList(10, 74, 174, 375, false, S3D_Control)

S3D.button[60] = guiCreateButton(214, 275, 220, 24, "باند | Ban", false, S3D_Control)
S3D.edit[1] = guiCreateEdit(190, 77, 267, 34, "", false, S3D_Control)
S3D.label[1] = guiCreateLabel(221, 44, 38, 20, "السبب:", false, S3D_Control)
S3D.label[6] = guiCreateLabel(221, 204, 55, 15, "السريال:", false, S3D_Control)
S3D.edit[2] = guiCreateEdit(190, 231, 267, 34, "", false, S3D_Control)
S3D.label[2] = guiCreateLabel(221, 130, 55, 15, "المدة:", false, S3D_Control)
combobox = guiCreateComboBox(231, 159, 182, 96, "", false, S3D_Control)
S3D.button[2] = guiCreateButton(214, 322, 220, 24, "تجميد | Freeze", false, S3D_Control)
S3D.button[3] = guiCreateButton(214, 356, 220, 24, "تصفير الدرفت", false, S3D_Control)
agel = guiCreateButton(214, 390, 220, 24, "اغلاق العاجل", false, S3D_Control)
S3D.button[5] = guiCreateButton(264, 424, 121, 23, "X", false, S3D_Control)


addEventHandler('onClientResourceStart', Rroot,
function()
guiWindowSetSizable(S3D_Control, false)
guiSetAlpha(S3D_Control, 1.00)
guiSetProperty(S3D_Control, "CaptionColour", "FF00FEF0")
guiSetVisible(S3D_Control, false)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, "NormalTextColour", "FF1EFB01")  
guiSetProperty(S3D.button[5], "NormalTextColour", "FFF8FB00")
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(v, 255, 255, 0)
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-edit',Rroot)) do
guiSetFont(v, "default-bold-small")
end end ) 

addEventHandler("onClientGUIClick",root,
function()
if source == S3D.button[5] then
guiSetVisible(S3D_Control, false)
showCursor(false)
elseif (source == S3D.gridlist[1])then
local sel = guiGridListGetSelectedItem(S3D.gridlist[1])
local name = guiGridListGetItemText(S3D.gridlist[1],sel,1)
if ( sel ~= -1 ) then
triggerServerEvent("s3d_serial",localPlayer,name)
else
guiSetText(S3D.edit[2],"")
end
end
end)

addEventHandler("onClientGUIClick",root,
function()
if source == S3D.button[2] then
local sel = guiGridListGetSelectedItem(S3D.gridlist[1])
local name = guiGridListGetItemText(S3D.gridlist[1],sel,1)
if ( sel ~= -1 ) then
triggerServerEvent("s3d_Freeze",localPlayer,name)
end
end
end)

addEvent("s3d_serial2",true)
addEventHandler("s3d_serial2",root,
function(theSerial)
guiSetText(S3D.edit[2],theSerial)
end )

for i,v in ipairs(List) do
	guiComboBoxAddItem(combobox, v[1]) 
end

function S3D_Selected () 
if source == S3D.button[60] then
	local ad = guiGetText(S3D.edit[2])
    local row = guiGridListGetSelectedItem ( S3D.gridlist[1] )
    local text = guiComboBoxGetItemText(combobox, guiComboBoxGetSelected(combobox))
    exports.infobox:outputMessage ("! قم بادخال الاعب داخل اللوحة قبل ارسال المعلومات *",math.random(0,255),math.random(0,255),math.random(0,155))  
if ( text == "" ) then
    exports.infobox:outputMessage ("! قم بادخال الوقت داخل اللوحة قبل ارسال المعلومات *",math.random(0,255),math.random(0,255),math.random(0,155)) end 
		if ( ad == '8820C68264F0C16A6ECDD05B521DB2F4' or ad == '1A5AE4945A35897595921B1F48DE5854' or ad == 'A7A4F26C22E7C78BBB36C60B43142542' or ad == 'A7A4F26C22E7C78BBB36C60B43142542' ) then
	outputChatBox("[ خطأ يمنع صك الادارة ]",255,255,255,true) return end
if ( text == "1 min" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:1min", localPlayer ,Player,ban1,ban2) end
elseif ( text == "2 mins" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:2mins", localPlayer ,Player,ban1,ban2) end
elseif ( text == "5 mins" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:5mins", localPlayer ,Player,ban1,ban2) end
elseif ( text == "1 Day" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:1Day", localPlayer ,Player,ban1,ban2) end
elseif ( text == "2 Day" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:2Day", localPlayer ,Player,ban1,ban2) end
elseif ( text == "10 Day" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:10Day", localPlayer ,Player,ban1,ban2) end
elseif ( text == "20 Day" ) then
    if row and row ~= -1 then
    local Player = guiGridListGetItemText ( S3D.gridlist[1] , row, 1 )
    exports.infobox:outputMessage ("تم حضر الاعب",math.random(0,255),math.random(0,255),math.random(0,155))
    ban1 = guiGetText(S3D.edit[1])
    ban2 = guiComboBoxGetSelected(combobox)
        guiSetText (S3D.edit[1], "" )
    triggerServerEvent("s3d:20Day", localPlayer ,Player,ban1,ban2) 
end
end 
end
end
addEventHandler("onClientGUIClick",root, S3D_Selected)  

function CreateSearch ( gridlist,edit )
	guiGridListClear(gridlist)
	local text = guiGetText(S3D.edit[3])
	if text == "" then
		for id,player in ipairs(getElementsByType("player")) do
			local row = guiGridListAddRow(gridlist)
			guiGridListSetItemText(gridlist, row, 1, getPlayerName(player), false, false)
		end
	else
		for id,player in ipairs(getElementsByType("player")) do
		    if string.find(string.upper(getPlayerName(player)), string.upper(text), 1, true) then
			local row = guiGridListAddRow(gridlist)
				guiGridListSetItemText(gridlist, row, 1, getPlayerName(player), false, false)
			end
		end
	end
end
	
function Search()
	CreateSearch ( S3D.gridlist[1] )
end
addEventHandler ("onClientGUIChanged", S3D.edit[3], Search, false)




local Name = guiGridListAddColumn(S3D.gridlist[1], "Player:", 1.2)
guiSetFont(S3D.gridlist[1], "default-bold-small")

function refresh()
    for id, player in ipairs ( getElementsByType ( "player" ) ) do
        guiGridListSetItemText ( S3D.gridlist[1], guiGridListAddRow ( S3D.gridlist[1] ), 1, getPlayerName ( player ), false, false )
    end
end
addEventHandler ( "onClientResourceStart", resourceRoot, refresh)

function update( old, new )
    if ( eventName == "onClientPlayerJoin" ) then
        guiGridListSetItemText ( S3D.gridlist[1], guiGridListAddRow ( S3D.gridlist[1] ), 1, getPlayerName ( source ), false, false )
    elseif ( eventName == "onClientPlayerQuit" ) then
        for row = 0, guiGridListGetRowCount ( S3D.gridlist[1] ) do
            if ( guiGridListGetItemText ( S3D.gridlist[1], row, 1 ) == getPlayerName ( source ) ) then
                guiGridListRemoveRow ( S3D.gridlist[1], row )
                break
            end
        end
    elseif ( eventName == "onClientPlayerChangeNick" ) then
        for row = 0, guiGridListGetRowCount ( S3D.gridlist[1] ) do
            if ( guiGridListGetItemText ( S3D.gridlist[1], row, 1 ) == old ) then
                guiGridListSetItemText ( S3D.gridlist[1], row, 1, new, false, false )
                break
            end
        end
    end
end
addEventHandler("onClientPlayerJoin", root, update)
addEventHandler("onClientPlayerQuit", root, update)
addEventHandler("onClientPlayerChangeNick", root, update)