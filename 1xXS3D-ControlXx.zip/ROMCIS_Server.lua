addEvent("s3d:1min",true)
addEventHandler("s3d:1min",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,60 )
	end	
end
)

addEvent("s3d:2mins",true)
addEventHandler("s3d:2mins",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,120 )
	end	
end
)

addEvent("s3d:5mins",true)
addEventHandler("s3d:5mins",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,300 )
	end	
end
)

addEvent("s3d:10mins",true)
addEventHandler("s3d:10mins",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,3000 )
	end	
end
)

addEvent("s3d:1Day",true)
addEventHandler("s3d:1Day",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,86400 )
	end	
end
)

addEvent("s3d:2Day",true)
addEventHandler("s3d:2Day",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,127800 )
	end	
end
)

addEvent("s3d:10Day",true)
addEventHandler("s3d:10Day",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,8640000 )
	end	
end
)

addEvent("s3d:20Day",true)
addEventHandler("s3d:20Day",root , 
    function ( player, ban1 )
    local Player3 = getPlayerFromName ( player )
    if ( Player3 ) then
	   local theBannedSerial = getPlayerSerial( Player3 )
addBan( nil, nil, theBannedSerial , player, ban1 ,1728000 )
	end	
end
)

addEvent("s3d_serial",true)
addEventHandler("s3d_serial",root,
function(name)
local Player = getPlayerFromName(name)
local theSerial = getPlayerSerial(Player)
triggerClientEvent(source,"s3d_serial2",source,""..theSerial.."")
end )

addEvent("s3d_Freeze",true)
addEventHandler("s3d_Freeze",root,
function(name)
local Player = getPlayerFromName(name)
local theSerial = getPlayerSerial(Player)
setElementFrozen ( Player, false)
end )
