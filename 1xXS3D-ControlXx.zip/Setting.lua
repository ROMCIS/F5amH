local Serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["1A5AE4945A35897595921B1F48DE5854"] = true, -- فان دام
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
}

addCommandHandler('s3d.admin',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('عذرآ انت لا تمتلك الخاصية . . !', 255, 0, 0, true) return end
guiSetVisible(S3D_Control,not guiGetVisible(S3D_Control))
showCursor(guiGetVisible(S3D_Control))
end)