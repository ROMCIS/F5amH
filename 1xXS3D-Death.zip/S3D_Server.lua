﻿function toggleGodMode ( thePlayer )
    local account = getPlayerAccount ( thePlayer )
    if ( not account or isGuestAccount ( account ) ) then
        return
    end
    local accountName = getAccountName ( account )
    if ( isObjectInACLGroup ( "user.".. accountName, aclGetGroup ( "Managers" ) ) ) then
        local state = ( not getElementData ( thePlayer, "invincible" ) )
        setElementData ( thePlayer, "invincible", state )
        outputChatBox ( "خاصية عدم الموت ".. ( state and "فعالة" or "غير فعالة" ) .."", thePlayer, 255, 0, 0 )
    end
end
addCommandHandler ( "mot", toggleGodMode )