﻿local Rroot = getResourceRootElement(getThisResource())

S3D = {
    label = {},
    radiobutton = {},
    edit = {},
    button = {},
    window = {},
    combobox = {},
    memo = {}
}

S3D.window[1] = guiCreateWindow(520, 243, 428, 476, "==[ نموذج تغيير اسم الحساب ]==", false)

S3D.memo[1] = guiCreateMemo(9, 24, 410, 110, "لتغيير اسم حسابك بالسيرفر يرجى منك ارسال المعلومات داخل اللوحة. \nنوع بطاقة الشحن : 50 سوا أو 10 دولار كاش يو              \nفي حال ارسال المعلومات سيتم الرد عليك خلال 24 ساعة           \nيجب أن يكون الحساب الجديد مسجل بالسيرفر وساعته 0 وخاص بك    \nبعد ذلك سيتم نقل ساعات حسابك القديم الى الحساب الجديد       ", false, S3D.window[1])
guiMemoSetReadOnly(S3D.memo[1], true)
S3D.radiobutton[1] = guiCreateRadioButton(171, 215, 113, 17, "سوا | STC SAWA", false, S3D.window[1])
S3D.radiobutton[2] = guiCreateRadioButton(17, 215, 107, 17, "كاش يو | cashu", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(299, 144, 110, 17, "اسم حسابك الحالي:", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(305, 175, 104, 17, "اسم حسابك الجديد:", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(304, 215, 95, 17, "نوع بطاقة الشحن:", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(304, 251, 105, 17, "أرقام بطاقة الشحن:", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(300, 331, 119, 17, "قائمة الأرقام المضافة:", false, S3D.window[1])
S3D.edit[1] = guiCreateEdit(63, 138, 230, 27, "", false, S3D.window[1])
guiEditSetReadOnly(S3D.edit[1], true)
S3D.edit[2] = guiCreateEdit(63, 171, 232, 27, "", false, S3D.window[1])
S3D.edit[3] = guiCreateEdit(93, 242, 201, 32, "", false, S3D.window[1])
S3D.button[1] = guiCreateButton(93, 284, 201, 32, "اضافة هذا الرقم الى القائمة", false, S3D.window[1])
S3D.button[2] = guiCreateButton(17, 326, 67, 34, "حذف الرقم", false, S3D.window[1])
S3D.button[3] = guiCreateButton(93, 388, 201, 32, "ارسال المعلومات", false, S3D.window[1])
S3D.button[4] = guiCreateButton(93, 430, 201, 32, "X", false, S3D.window[1])
S3D.combobox[1] = guiCreateComboBox(93, 331, 201, 52, "", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 0.91)
guiSetProperty(S3D.window[1], "CaptionColour", "FFFCFA00")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, "NormalTextColour", "FF36FE00")
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-radiobutton',Rroot)) do
guiSetFont(v, "default-bold-small")
guiSetProperty(v, "NormalTextColour", "FF0005FF")
guiRadioButtonSetSelected(v, false)
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiLabelSetColor(S3D.label[1], 0, 254, 245)
guiLabelSetColor(S3D.label[2], 0, 254, 245)
guiLabelSetColor(S3D.label[3], 0, 254, 245)
guiLabelSetColor(S3D.label[4], 0, 254, 245)
guiLabelSetColor(S3D.label[5], 0, 254, 245)
guiSetFont(v, "default-bold-small")
end end ) 

addEvent("s3d_x",true)
addEventHandler("s3d_x",root,
function()
triggerServerEvent("s3d_getcc",localPlayer)
end )


addEvent("s3d_acc",true)
addEventHandler("s3d_acc",root,
function(userName)
guiSetText(S3D.edit[1],userName)
end )

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == S3D.button[4] ) then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end
)

addCommandHandler('حساب',
function()
if (guiGetVisible(S3D.window[1]) == true) then
triggerServerEvent("s3d_acc2",localPlayer)
guiSetVisible(S3D.window[1],false)
showCursor(false)
else
triggerServerEvent("s3d_acc2",localPlayer)
guiSetVisible(S3D.window[1],true)
showCursor(true)
end
end
) 