﻿addEvent("s3d_acc2",true)
addEventHandler("s3d_acc2",root,
function()
if not ( isGuestAccount(getPlayerAccount(source)) ) then
local user = getPlayerAccount(source)
local userName = getAccountName(getPlayerAccount(source))
local Money = getAccountData(user,"MoneyBank") or 0
triggerClientEvent(source,"s3d_acc",source,userName,Money)
end end )


addEvent("s3d_getcc",true)
addEventHandler("s3d_getcc",root,
function()
if not ( isGuestAccount(getPlayerAccount(source)) ) then
local user = getPlayerAccount(source)
local userName = getAccountName(getPlayerAccount(source))
local Money = getAccountData(user,"MoneyBank") or 0
triggerClientEvent(source,"s3d_acc",source,userName,Money)
end end )