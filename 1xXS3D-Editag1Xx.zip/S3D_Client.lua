﻿local Rrooot = getResourceRootElement(getThisResource())

local Serials ={ 
['8820C68264F0C16A6ECDD05B521DB2F4'] = true, -- رومسيس
['1A5AE4945A35897595921B1F48DE5854'] = true, -- فان دام
['A7A4F26C22E7C78BBB36C60B43142542'] = true, -- فهد
['DE75A78DFDBE9918A725E38238F5F094'] = true, -- كريزي
}

ROMCIS = {
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}


ROMCIS.window[1] = guiCreateWindow(584, 273, 361, 386, "-| Serials Add : Wzrah Buy Tag |-", false)
ROMCIS.label[1] = guiCreateLabel(11, 79, 43, 17, "Serial :", false, ROMCIS.window[1])
ROMCIS.gridlist[1] = guiCreateGridList(11, 102, 341, 203, false, ROMCIS.window[1])
guiGridListAddColumn(ROMCIS.gridlist[1], "Serial", 1.2)
ROMCIS.edit[1] = guiCreateEdit(79, 315, 224, 26, "", false, ROMCIS.window[1])
ROMCIS.button[1] = guiCreateButton(31, 351, 136, 24, "تفعيل السريال", false, ROMCIS.window[1])
ROMCIS.button[2] = guiCreateButton(195, 351, 136, 24, "ازاله السريال", false, ROMCIS.window[1])
ROMCIS.button[3] = guiCreateButton(313, 28, 29, 29, "X", false, ROMCIS.window[1])
ROMCIS.window[2] = guiCreateWindow(548, 367, 370, 213, "-| Wzrah تفعيل حسابات التاجات الخاصة |-", false)
ROMCIS.label[2] = guiCreateLabel(30, 65, 55, 16, "Account :", false, ROMCIS.window[2])
ROMCIS.edit[2] = guiCreateEdit(96, 58, 169, 33, "", false, ROMCIS.window[2])
ROMCIS.button[4] = guiCreateButton(112, 101, 139, 25, "اضافة حساب", false, ROMCIS.window[2])
ROMCIS.button[5] = guiCreateButton(112, 136, 139, 25, "حذف حساب", false, ROMCIS.window[2])
ROMCIS.button[6] = guiCreateButton(112, 171, 139, 25, "X", false, ROMCIS.window[2])

addEventHandler('onClientResourceStart', Rrooot,
function()
guiSetVisible(ROMCIS.window[1], false)
guiSetVisible(ROMCIS.window[2], false)
guiWindowSetSizable(ROMCIS.window[1], false)
guiWindowSetSizable(ROMCIS.window[2], false)
guiSetAlpha(ROMCIS.window[1], 1)
guiSetAlpha(ROMCIS.window[2], 1)
guiSetProperty(ROMCIS.window[1], "CaptionColour", "FF00FED7")
guiSetProperty(ROMCIS.window[2], "CaptionColour", "FF7C9039")
for _, v in ipairs(getElementsByType('gui-button',Rrooot)) do
guiSetProperty(ROMCIS.button[1], "NormalTextColour", "FF56FF40")
guiSetProperty(ROMCIS.button[2], "NormalTextColour", "FFFF0000")
guiSetProperty(ROMCIS.button[3], "NormalTextColour", "FFFEFC00") 
---
guiSetProperty(ROMCIS.button[4], "NormalTextColour", "FF56FF40")
guiSetProperty(ROMCIS.button[5], "NormalTextColour", "FFFF0000")
guiSetProperty(ROMCIS.button[6], "NormalTextColour", "FFFFFFFF") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rrooot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(ROMCIS.label[1], 253, 66, 66)
guiLabelSetColor(ROMCIS.label[2], 253, 66, 66)
end end ) 

addEventHandler("onClientGUIClick",root, 
function() 
if (source == ROMCIS.button[3]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(ROMCIS.window[1], false) 
elseif (source == ROMCIS.button[1]) then
local serial = guiGetText(ROMCIS.edit[1])
if ( serial == '' or guiEditGetCaretIndex( ROMCIS.edit[1] ) < 32 or guiEditGetCaretIndex( ROMCIS.edit[1] ) > 32 ) then exports.infobox:outputMessage('يوجد خلل فني ف السكريبت',50,255,0,true) return end 
if ( serial == '') then return end  triggerServerEvent('AddSerial_Dev1', localPlayer, serial) 
elseif (source == ROMCIS.button[2] ) then
local tounsi_text = guiGridListGetSelectedItem(ROMCIS.gridlist[1])
if ( tounsi_text ~= -1) then
local tounsi_remove = guiGridListGetItemText(ROMCIS.gridlist[1], tounsi_text, 1)
triggerServerEvent( 'RemoveSerial_Dev1', localPlayer, tounsi_remove )
else 
exports.infobox:outputMessage('يرجى أختيار الاعب من القائمة', 240,255,0, false) 
end
end
end )

addEventHandler("onClientGUIClick",root, 
function() 
if (source == ROMCIS.button[6]) then 
showCursor(false) 
guiSetInputEnabled(false) 
guiSetVisible(ROMCIS.window[2], false) 
elseif source==ROMCIS.button[4] then
local acc=guiGetText(ROMCIS.edit[2])
if acc=='' then exports.infobox:outputMessage('قم كتابة أسم الحساب',255,255,255,true) return end
triggerServerEvent('addPlrTagacc',localPlayer,acc)
elseif source==ROMCIS.button[5] then
local acc=guiGetText(ROMCIS.edit[2])
if acc=='' then outputChatBox('#ff0000* please enter valid account',255,255,255,true) return end
triggerServerEvent('RemovePlrTagacc',localPlayer,acc)
end
end )

addEvent('Refresh_Dev1',true)
addEventHandler('Refresh_Dev1',root,
function(TagData)
guiGridListClear(ROMCIS.gridlist[1])
for i, v in ipairs (TagData) do
local Row = guiGridListAddRow(ROMCIS.gridlist[1])
local TheSerial = guiGridListSetItemText(ROMCIS.gridlist[1], Row, 1, TagData[i].PlayerSerial, false, false)
end end)

addEvent('List_Dev',true) 
addEventHandler('List_Dev',root, 
function()
guiGridListClear(ROMCIS.gridlist[1])
end )

addCommandHandler('s3d_tag2', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(ROMCIS.window[1],not guiGetVisible(ROMCIS.window[1])) 
showCursor(guiGetVisible(ROMCIS.window[1])) 
guiSetInputEnabled(guiGetVisible(ROMCIS.window[1])) 
triggerServerEvent('Rom_GetAllfuck', localPlayer) 
triggerServerEvent('Active_Dev1', localPlayer)
triggerServerEvent('ActiveSerialsAllAccount_Dev', localPlayer)
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )

addCommandHandler('s3d_tag1', function() 
if Serials[getPlayerSerial(localPlayer)] then 
guiSetVisible(ROMCIS.window[2],not guiGetVisible(ROMCIS.window[2])) 
showCursor(guiGetVisible(ROMCIS.window[2])) 
guiSetInputEnabled(guiGetVisible(ROMCIS.window[2])) 
triggerServerEvent('Rom_GetAllfuck', localPlayer) 
triggerServerEvent('Active_Dev1', localPlayer)
triggerServerEvent('ActiveSerialsAllAccount_Dev', localPlayer)
else
triggerServerEvent ( "ban_anti", localPlayer,'لاينصح به :)')		
end end )