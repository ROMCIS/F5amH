﻿function dev(center_window)
  local screenW, screenH = guiGetScreenSize()
  local windowW, windowH = guiGetSize(center_window, false)
  local x, y = (screenW - windowW) / 2, (screenH - windowH) / 2
  guiSetPosition(center_window, x, y, false)
end

local Rroot = getResourceRootElement(getThisResource())

Dev = {
    window = {},
    button = {},
    label = {},
    gridlist = {},
    edit = {}	
}

S3D = {
    label = {},
    staticimage = {}
}

        EditTag_S3D = guiCreateWindow(366, 162, 708, 577, "=[ F5amh | Edit Tag ]=", false)

        S3D.label[1] = guiCreateLabel(624, 27, 55, 21, "تعليمات :", false, EditTag_S3D)
        S3D.label[2] = guiCreateLabel(463, 48, 216, 21, "* Name: تضع به أسمك مثال ( F5amh )", false, EditTag_S3D)
        S3D.label[3] = guiCreateLabel(445, 69, 227, 19, "* Tag: تضع به لقبك مثال ( Admin Server )", false, EditTag_S3D)
        S3D.label[4] = guiCreateLabel(509, 88, 163, 18, "* Chat Color: تغيير لون كلامك", false, EditTag_S3D)
        S3D.label[5] = guiCreateLabel(223, 106, 449, 18, "يمنع وضع الأسم عربي + يمنع بعض تاجات العربيه وتكون فقط لرتبه النائب والمساعد .*", false, EditTag_S3D)
        S3D.label[6] = guiCreateLabel(298, 182, 55, 21, "Name:", false, EditTag_S3D)
        S3D.label[7] = guiCreateLabel(479, 174, 135, 19, "معلومات عن التاج :", false, EditTag_S3D)
        S3D.label[8] = guiCreateLabel(298, 270, 41, 17, "Tag:", false, EditTag_S3D)
        S3D.label[9] = guiCreateLabel(298, 358, 73, 21, "Chat Color:", false, EditTag_S3D)
        S3D.label[10] = guiCreateLabel(367, 358, 227, 19, "لرئية شكل التاج في الشات قبل الحفظ!", false, EditTag_S3D)
        S3D.label[11] = guiCreateLabel(243, 426, 220, 17, "==================================", false, EditTag_S3D)
        S3D.label[12] = guiCreateLabel(47, 505, 614, 19, "تنبيه: سيسمح لك بأستخدام هذا الزر كل 5 دقيقة || يجب الأنتهاء من تعديل التاجات الذي تريد تعديلها وحفظ المعلومات", false, EditTag_S3D)
        S3D.label[13] = guiCreateLabel(128, 530, 452, 19, "وفي حال لأنتهاء من كل تاجات المعدله عليك الظغط على ارسال !", false, EditTag_S3D)
        S3D.label[14] = guiCreateLabel(243, 555, 220, 17, "==================================", false, EditTag_S3D)
        S3D.staticimage[1] = guiCreateStaticImage(244, 134, 28, 31, "img/search.png", false, EditTag_S3D)
        S3D.staticimage[2] = guiCreateStaticImage(421, 164, 42, 39, "img/info.png", false, EditTag_S3D)			
		
        GridList_S3D = guiCreateGridList(10, 174, 272, 242, false, EditTag_S3D)
        guiGridListAddColumn(GridList_S3D, "Account :", 1)

		Edit_Name = guiCreateEdit(10, 134, 234, 30, "", false, EditTag_S3D)	
		Edit_Acc = guiCreateEdit(298, 291, 380, 57, "", false, EditTag_S3D)	
		Edit_Tag = guiCreateEdit(298, 203, 380, 57, "", false, EditTag_S3D)
		
		Edit_Color = guiCreateEdit(298, 383, 79, 33, "#FFFFFF", false, EditTag_S3D)
		guiEditSetMaxLength(Edit_Color, 7)	

        S3D_ShowChat = guiCreateButton(397, 383, 102, 35, "اظهار بالشات !", false, EditTag_S3D)
        S3D_SaveAll = guiCreateButton(513, 383, 175, 35, "حفظ المعلومات داخل اللوحة !", false, EditTag_S3D)
        -- S3D_Log = guiCreateButton(513, 430, 175, 35, "Log / لوقـ !", false, EditTag_S3D)
        S3D_SendAll = guiCreateButton(227, 447, 252, 48, "إرسال جميع المعلومات إلى الأستضافة !", false, EditTag_S3D)
        S3D_Close = guiCreateButton(657, 534, 41, 33, "X", false, EditTag_S3D)		

        Dev.window[4] = guiCreateWindow(420, 255, 600, 391, "=[ لـوحة مراقـبة الـتاجات الخـاصة ]=", false)


        Dev.gridlist[3] = guiCreateGridList(10, 30, 581, 238, false, Dev.window[4])
        guiGridListAddColumn(Dev.gridlist[3], "Log:", 100)
		
        Dev.button[14] = guiCreateButton(548, 342, 43, 39, "X", false, Dev.window[4])
        Dev.button[12] = guiCreateButton(124, 327, 158, 39, "Refresh | تحديث", false, Dev.window[4])
        Dev.button[13] = guiCreateButton(423, 278, 158, 39, "Copy | نسخ", false, Dev.window[4])
		Dev.button[15] = guiCreateButton(312, 327, 158, 39, "Delete | حذف السجلات", false, Dev.window[4])
        Dev.edit[7] = guiCreateEdit(178, 278, 235, 39, "Search | بحث", false, Dev.window[4])    

addEventHandler('onClientResourceStart', Rroot,
function()
guiWindowSetSizable(EditTag_S3D, false)
guiWindowSetSizable(Dev.window[4], false)
guiSetAlpha(EditTag_S3D, 1.00)
guiSetAlpha(Dev.window[4], 1.00)
guiSetVisible(EditTag_S3D, false)
guiSetVisible(Dev.window[4], false)
guiSetProperty(EditTag_S3D, "CaptionColour", "FF0FB6FA")
dev(EditTag_S3D)
dev(Dev.window[4])
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetFont(v, "default-bold-small")
guiSetProperty(v, "NormalTextColour", "FF0CFE00")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetHorizontalAlign(v, "center", false)
guiLabelSetColor(v, 224, 79, 79)
guiLabelSetColor(S3D.label[6], 255, 255, 79)
guiLabelSetColor(S3D.label[7], 0, 255, 0)
guiLabelSetColor(S3D.label[8], 255, 255, 79)
guiLabelSetColor(S3D.label[9], 255, 255, 79)
guiLabelSetColor(S3D.label[10], 255, 0, 0)
guiLabelSetColor(S3D.label[11], 255, 255, 255)
guiLabelSetColor(S3D.label[12], 255, 0, 0)
guiLabelSetColor(S3D.label[13], 255, 0, 0)
guiLabelSetColor(S3D.label[14], 255, 255, 255)
end end )

local sql1={}
addEvent("MrTOUNSI_Tags",true)
addEventHandler("MrTOUNSI_Tags",root,function(sql)
guiGridListClear(Dev.gridlist[3])
sql1=sql
if #sql==0 then return end
for k=1,#sql do
local row=guiGridListAddRow(Dev.gridlist[3])
guiGridListSetItemText(Dev.gridlist[3],row,1,sql[k].log,false,false)
if sql[k].type=='delete' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,0)
elseif sql1[k].type=='change' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,255)
else
guiGridListSetItemColor(Dev.gridlist[3],row,1,255,255,255)
end
end
end)

function Dev_S()
guiGridListClear(Dev.gridlist[3])
local text = guiGetText(Dev.edit[7])
if #sql1~=0 then
guiGridListClear(Dev.gridlist[3])
for k=1,#sql1 do
if text~='' and (string.find(string.upper(sql1[k].log),string.upper(text))) then
local row=guiGridListAddRow(Dev.gridlist[3])		
guiGridListSetItemText(Dev.gridlist[3],row,1,sql1[k].log,false,false)
if sql1[k].type=='delete' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,0)
elseif sql1[k].type=='change' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,255)
else
guiGridListSetItemColor(Dev.gridlist[3],row,1,255,255,255)
end
else
if text=='' then
local row=guiGridListAddRow(Dev.gridlist[3])		
guiGridListSetItemText(Dev.gridlist[3],row,1,sql1[k].log,false,false)
if sql1[k].type=='delete' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,0) 
elseif sql1[k].type=='change' then guiGridListSetItemColor(Dev.gridlist[3],row,1,255,0,255)
else
guiGridListSetItemColor(Dev.gridlist[3],row,1,255,255,255)
end end end end end end

addEventHandler("onClientGUIChanged",root,
function ()
if (source == Dev.edit[7])then
Dev_S()
end end )

addEvent('cleargridlog_Dev',true)
addEventHandler('cleargridlog_Dev',root,function()
guiGridListClear(Dev.gridlist[3])
end)

addEventHandler("onClientGUIClick",root, 
function() 
if source == S3D_ShowChat then
local name,tag,color=guiGetText(Edit_Tag),guiGetText(Edit_Acc),guiGetText(Edit_Color)
outputChatBox(tag..name..color..' : T.S',255,255,255,true)
elseif source == S3D_SendAll then
local da=getElementData(localPlayer,'canpress')
if not da or da~=true then exports.infobox:outputMessage('قم بحفظ المعلومات أولا !',0,255,0,source)	return end 
local name,tag,color=guiGetText(Edit_Tag),guiGetText(Edit_Acc),guiGetText(Edit_Color)
if name~='' and tag~='' and color~='' then
local sel=guiGridListGetSelectedItem(GridList_S3D)
if sel~=-1 then
triggerServerEvent('setPlrTagacc',localPlayer,guiGridListGetItemText(GridList_S3D,sel,1),tag,name,color)
else
exports.infobox:outputMessage('قم بادخال الحساب الموجود',0,255,0,source)	
end
else
exports.infobox:outputMessage('قم بادخال معلومات التاج',0,255,0,source)
end 
guiSetEnabled(source,false) setTimer(guiSetEnabled,15000,1,S3D_SendAll,true)
elseif source == S3D_SaveAll then
setElementData(localPlayer,'canpress',true)
exports.infobox:outputMessage('تم حفظ جميع معلومات التاج بنجاح !',math.random(50, 255), math.random(50, 255), math.random(50, 255),source)
elseif source == S3D_Log then 
guiBringToFront(Dev.window[4])
guiSetVisible(Dev.window[4],not guiGetVisible(Dev.window[4])) 
showCursor(guiGetVisible(Dev.window[4])) 
guiSetInputEnabled(guiGetVisible(Dev.window[4])) 
triggerServerEvent('getallLogs_Tags',localPlayer)
guiSetText(Dev.edit[7],'Search | بحث')
elseif source == S3D_Close then 
guiSetVisible(EditTag_S3D,false) 
guiSetInputEnabled(false) 
showCursor(false)
setElementData(localPlayer,'canpress',nil)
elseif source == Dev.button[14] then 
guiSetVisible(Dev.window[4],false) 
guiSetVisible(EditTag_S3D,false) 
guiSetInputEnabled(false) 
showCursor(false)
elseif ( source == Dev.button[13] ) then
local sel = guiGridListGetSelectedItem ( Dev.gridlist[3] )
if ( sel ~= -1 ) then
local TheText = guiGridListGetItemText ( Dev.gridlist[3], sel, 1 )
setClipboard ( ''..TheText..'' )
guiSetEnabled(source,false) setTimer(guiSetEnabled,3000,1,Dev.button[13],true)
end
elseif source==Dev.button[15] then
triggerServerEvent('clearlog_Dev',localPlayer)
guiSetEnabled(source,false) setTimer(guiSetEnabled,3000,1,Dev.button[15],true)
elseif ( source == Dev.button[12] ) then
guiGridListClear ( Dev.gridlist[3] )
triggerServerEvent('getallLogs_Tags',localPlayer)
guiSetEnabled(source,false) setTimer(guiSetEnabled,500,1,Dev.button[12],true)
end end )

addCommandHandler('Edittag',
function()
triggerServerEvent('Open_Dev1', localPlayer)
end)

addEvent('OpenEdittag_Dev1',true)
addEventHandler('OpenEdittag_Dev1',root,
function ()
triggerServerEvent('getAll_Dev1',localPlayer)
setElementData(localPlayer,'canpress',nil)
guiSetVisible( EditTag_S3D, not guiGetVisible( EditTag_S3D ) )
showCursor( guiGetVisible( EditTag_S3D ) )
guiSetInputEnabled(guiGetVisible(EditTag_S3D))
end )

local tab={}

addEvent('PlayerGridlist_Dev',true)
addEventHandler('PlayerGridlist_Dev',root,function(sel)
guiGridListClear(GridList_S3D)
tab=sel
if #sel==0 then return end
for k=1,#sel do
local row=guiGridListAddRow(GridList_S3D)
guiGridListSetItemText(GridList_S3D,row,1,sel[k].acc,false,false)
end end)
 
addEventHandler('onClientGUIChanged',Edit_Name,function()
local txt=guiGetText(source)
guiGridListClear(GridList_S3D)
if txt=='' then
for k=1,#tab do
local row=guiGridListAddRow(GridList_S3D)
guiGridListSetItemText(GridList_S3D,row,1,tab[k].acc,false,false)
end
else
for k=1,#tab do
if string.find(string.upper(tab[k].acc),string.upper(txt)) then
local row=guiGridListAddRow(GridList_S3D)
guiGridListSetItemText(GridList_S3D,row,1,tab[k].acc,false,false)
end
end
end
end,false)