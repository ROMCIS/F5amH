﻿local TheDb = dbConnect('sqlite', 'TOUNSI_Serials.db')
local db=dbConnect('sqlite','TOUNSI_Account.db')

dbExec(TheDb, ' CREATE TABLE IF NOT EXISTS `InformationTag` (PlayerSerial) ' )
dbExec(db,'CREATE TABLE IF NOT EXISTS YeahNice (acc TEXT, tag TEXT, isactive TEXT,color TEXT,isactive2 TEXT)')

function getPlayerFromSerial ( serial )
assert ( type ( serial ) == "string" and #serial == 32, "getPlayerFromSerial - invalid serial" )
for index, player in ipairs ( getElementsByType ( "player" ) ) do
if ( getPlayerSerial ( player ) == serial ) then
return player
end
end
return  false
end

function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

function strtobool(str)
return (str=='true')
end

addEvent('addPlrTagacc',true)
addEventHandler('addPlrTagacc',root,function(acc)
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',acc),-1)
if #sel==0 then
if not getAccount(acc) then OutPut('يرجى التاكد من الاسم الحساب', source, 255,0,0, false) return end
dbExec(db,'INSERT INTO YeahNice VALUES(?,?,?,?,?)',acc,'','false','','true')
OutPut('('..acc..') : تم تفعيل الحساب', source, 50,255,0, false)
else
OutPut('الحساب تم إضافته من قبل', source, 240,255,0, false)
end
end)

addEvent('RemovePlrTagacc',true)
addEventHandler('RemovePlrTagacc',root,function(acc)
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',acc),-1)
if #sel~=0 then
if not getAccount(acc) then outputChatBox('#ff0000* the account is not exist in server',source,255,255,255,true) return end
dbExec(db,'DELETE FROM YeahNice WHERE acc=?',acc)
outputChatBox('#33ff00* account has been deleted',source,255,255,255,true)
else
outputChatBox('#ff0000* the account is not have tag option',source,255,255,255,true)	
end end)

addEvent('setPlrTagacc',true)
addEventHandler('setPlrTagacc',root,function(acc,tag,thet,color)
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',acc),-1)
if #sel~=0 then
if not getAccount(acc) then outputChatBox('#ff0000* the account is not exist in server',source,255,255,255,true) return end
local color=color or '#ffffff'
dbExec(db,'UPDATE YeahNice SET tag=?,isactive=?,color=? WHERE acc=?',tag,thet,color,acc)
OutPut('! تم إرسال معلومات التاج بنجاح *',source,math.random(50, 255), math.random(50, 255), math.random(50, 255),true)
local time = getRealTime()
local hours = time.hour 
local minutes = time.minute
local sec = time.second
local day = time.monthday
local month = time.month +1
local year = time.year +1900	
local time=''..year..'/'..month..'/'..day..'/ '..hours..':'..minutes..':'..sec..''	
local txt=""..time.."  Log: "..getPlayerName(source).."("..getAccountName(getPlayerAccount(source))..") serial["..getPlayerSerial(source).."] Give | Account("..acc..")("..getAccountSerial(getAccount(acc))..") Tag : "..tag..thet..""
triggerEvent('MrTOUNSI_Tags',source,txt)	
end end)

addCommandHandler('tag',function(plr)
local acc=getPlayerAccount(plr)
if not isGuestAccount(acc) then
local accname=getAccountName(acc)
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',accname),-1)
if #sel~=0 then	
local state=strtobool(sel[1].isactive2)
dbExec(db,'UPDATE YeahNice SET isactive2=? WHERE acc=?',tostring( not state),accname)
if state then
outputChatBox('تم الغاء اللقب',plr,255,0,0,true)
else
outputChatBox('تم تفعيل اللقب',plr,0,255,0,true)
end end end end)

addEvent('AddSerial_Dev1',true)
addEventHandler('AddSerial_Dev1',root,
function( serial )
local SerialCheck = getPlayerFromSerial( serial )
if (SerialCheck == nil or not SerialCheck) then return OutPut('يجب على المستخدم الدخول !', source, 255,0,0, false) end
local CheckResults = dbQuery( TheDb, ' SELECT * FROM `InformationTag` WHERE PlayerSerial = ? ', serial )
local GetData = dbPoll( CheckResults, -1 )
if ( type ( GetData ) == 'table' and #GetData == 0 or not GetData ) then
dbExec(TheDb, ' INSERT INTO `InformationTag` (PlayerSerial) VALUES(?) ', serial)
OutPut('(Edittag) : رمز بأف8 ('..serial..') : تم تفعيل السريال', source, 50,255,0, false)
tounsi_refresh()
else
OutPut('! تم تفعيل السريال مسبقا يرجى الإنتباه', source, 240,255,0, false)
end end)

function tounsi_refresh()
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationTag` ' )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return triggerClientEvent('List_Dev', source) end
triggerClientEvent(source, "Refresh_Dev1", source, checkData)
end
addEvent( 'Active_Dev1', true )
addEventHandler( 'Active_Dev1', root, tounsi_refresh)

addEvent('RemoveSerial_Dev1',true)
addEventHandler('RemoveSerial_Dev1',root,
function( SerialRemove )
local SerialCheck = getPlayerFromSerial( SerialRemove )
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationTag` WHERE PlayerSerial = ? ', SerialRemove )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return end
dbExec(TheDb, ' DELETE FROM `InformationTag` WHERE PlayerSerial = ? ', SerialRemove )
OutPut('تم إزالة السريال !', source, 50,255,0, false)
tounsi_refresh()
end)

addEvent('getAll_Dev1',true)
addEventHandler('getAll_Dev1',root,function()
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice'),-1)
triggerClientEvent(source,'PlayerGridlist_Dev',source,sel)
end)

addEvent('Open_Dev1',true)
addEventHandler('Open_Dev1',root,
function( )
local CheckThatPlSS = dbQuery( TheDb, ' SELECT * FROM `InformationTag` WHERE PlayerSerial = ? ', getPlayerSerial(source) )
local checkData = dbPoll( CheckThatPlSS, -1 )
if ( type ( checkData ) == 'table' and #checkData == 0 or not checkData ) then return end
triggerClientEvent(source ,'OpenEdittag_Dev1', source)
end)


local db=dbConnect('sqlite','Log_TOUNSI.db')
dbExec(db,'CREATE TABLE IF NOT EXISTS TOUNSIAcccount (log)')

addEvent('MrTOUNSI_Tags',true)
addEventHandler('MrTOUNSI_Tags',root,function(msg)
dbExec(db,'INSERT INTO TOUNSIAcccount VALUES (?)',msg)
end)

addEvent('getallLogs_Tags',true)
addEventHandler('getallLogs_Tags',root,function()
local sel=dbPoll(dbQuery(db,'SELECT * FROM TOUNSIAcccount'),-1)
triggerClientEvent(source,'MrTOUNSI_Tags',source,sel)
end)

addCommandHandler('log',function(plr,cmd,...)
local acc=getPlayerAccount(plr)
if not isGuestAccount(acc) and ( isObjectInACLGroup('user.'..getAccountName(acc),aclGetGroup('DevGroup'))) then
triggerClientEvent(plr,'Dev_logOpenTags',plr)
else
outputChatBox('غير مصرح لك',plr,255,0,0,true)
end end)

local allowed={'Console'} -- رتبة حذف اللوق

addEvent('clearlog_Dev',true)
addEventHandler('clearlog_Dev',root,function()
local acc=getPlayerAccount(source)
if isGuestAccount(acc) then return end
for k,v in ipairs(allowed)do
if isObjectInACLGroup('user.'..getAccountName(acc),aclGetGroup(v)) then
dbExec(db,'DROP TABLE TOUNSIAcccount')
dbExec(db,'CREATE TABLE IF NOT EXISTS TOUNSIAcccount (log)')
local name=(string.gsub ( getPlayerName(source), '#%x%x%x%x%x%x', '' ) or getPlayerName(source))
dbExec(db,'INSERT INTO TOUNSIAcccount VALUES (?)','The log has deleted by : '..getAccountName(getPlayerAccount(source))..'')
local sel=dbPoll(dbQuery(db,'SELECT * FROM TOUNSIAcccount'),-1)
triggerClientEvent(root,'cleargridlog_Dev',root)
break
else
if k==#allowed then
outputChatBox("فقط صاحب السيرفر المصرح له باستخدام هذا الزر",source,255,0,0,true)
end end end end)
