﻿-----------------------------------
-- Main Wnd
---------------------------------

local Rroot = getResourceRootElement(getThisResource())

S3D = {
    button = {},
    window = {},
    label = {}
}

S3D.window[1] = guiCreateStaticImage(498, 229, 428, 353, "s3d.png", false)

S3D.label[1] = guiCreateLabel(68, 6, 240, 16, "([ لوحة تحكم للاعب | The Player Contorol]:.", false, S3D.window[1])
S3D.button[1] = guiCreateButton(9, 56, 409, 22, ".::( اخفاء الشات | Hide The Chat )::.", false, S3D.window[1])
S3D.button[2] = guiCreateButton(9, 82, 409, 22, ".::( اخفاء الدم / الدرع | Hide The Health - Armour Hud )::.", false, S3D.window[1])
S3D.button[3] = guiCreateButton(9, 108, 409, 22, ".::( | اخفاء الرادار | Hide The `Radar Small Map` )::.", false, S3D.window[1])
S3D.button[4] = guiCreateButton(10, 134, 409, 22, ".::( اخفاء نفسي اللاعب | Hide The Player My Self )::.", false, S3D.window[1])
S3D.button[5] = guiCreateButton(10, 160, 409, 22, ".::( وضع عشوآئي | Set a Random Weather )::.", false, S3D.window[1])  
S3D.button[6] = guiCreateButton(10, 186, 409, 22, ".::( تغير الوقت لى الساعه 12 | Change The Time To 12 PM )::.", false, S3D.window[1])  
S3D.button[7] = guiCreateButton(11, 212, 409, 22, ".::( قطع رأسي الاعب | Cut My Head My Self )::.", false, S3D.window[1])  
S3D.button[8] = guiCreateButton(11, 238, 409, 22, ".::( اخفاء سيارتي انا | Hide My Vehicle )::.", false, S3D.window[1]) 
S3D.button[9] = guiCreateButton(11, 264, 409, 22, ".::( شاشة سودآء الخروج من اللعب | Black Screen(FadeCamera) )::.", false, S3D.window[1])  
Close = guiCreateButton(11, 319, 409, 22, "إغلاق", false, S3D.window[1])  

addEventHandler('onClientResourceStart', Rroot,
function()
guiWindowSetSizable(S3D.window[1], false)
guiSetVisible(S3D.window[1],false)
-- centerWindow(S3D.window[1],2,2)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, 'NormalTextColour', 'FF00FD0B')
guiSetFont(v, "default-bold-small")  
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(v, 254, 0, 0)  
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[1] then 
playSoundFrontEnd(11)
elseif source == S3D.button[2] then
playSoundFrontEnd(11)
elseif source == S3D.button[3] then
playSoundFrontEnd(11)
elseif source == S3D.button[4] then
playSoundFrontEnd(11)
elseif source == S3D.button[5] then
playSoundFrontEnd(11)
elseif source == S3D.button[6] then
playSoundFrontEnd(11)
elseif source == S3D.button[7] then
playSoundFrontEnd(11)
elseif source == S3D.button[8] then
playSoundFrontEnd(11)
elseif source == S3D.button[9] then 
playSoundFrontEnd(11)
elseif source == Close then 
playSoundFrontEnd(11)
end end )

addEventHandler("onClientGUIClick",resourceRoot,
function()
if source == S3D.button[2] then executeCommandHandler ( "s3d_hud" )  
elseif source == S3D.button[3] then executeCommandHandler ( "s3d_radar" )  
elseif source == S3D.button[4] then executeCommandHandler ( "s3d_hide" )  
elseif source == S3D.button[5] then executeCommandHandler ( "s3d_weath" )  
elseif source == S3D.button[8] then executeCommandHandler ( "s3d_hidecar" )  
elseif source == S3D.button[9] then executeCommandHandler ( "s3d_fade" )   
end end )

addEventHandler("onClientGUIClick",resourceRoot,
function ()
if ( source == Close ) then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end
)

addCommandHandler('تحكم',
function()
if (guiGetVisible(S3D.window[1]) == true) then
guiSetVisible(S3D.window[1],false)
showCursor(false)
else
guiSetVisible(S3D.window[1],true)
showCursor(true)
end
end
)	
			
			
		local isChatVisible = true
addEventHandler ("onClientGUIClick",resourceRoot,function ()
    if ( source == S3D.button[1] ) then
    if isChatVisible then
        showChat (false)
        isChatVisible = false
            else
        showChat (true)
        isChatVisible = true
    end
    end
end)

addEventHandler("onClientGUIClick",resourceRoot,
function ( )
if ( source == S3D.button[7] ) then
triggerServerEvent("S3D_Head",localPlayer)
end
 end)

state = false
addCommandHandler ("s3d_radar",
function ()
if state then 
showPlayerHudComponent("radar",true)
else 
showPlayerHudComponent("radar",false)
end
state = not state
end)

state = false
addCommandHandler ("s3d_hide",
function ()
if state then 
setElementAlpha(getLocalPlayer(), 255)
else 
setElementAlpha(getLocalPlayer(), 0)
end
state = not state
end)

local state = false
local components = {"weapon", "ammo", "health", "clock", "money", "breath", "armour", "wanted"}

addCommandHandler("s3d_hud",
    function()
        if state then 
        end

        for _, component in ipairs(components) do
            setPlayerHudComponentVisible(component, state)
        end
        
        state = not state
    end
)

state = false
addCommandHandler ("s3d_fade",
function ()
if state then 
fadeCamera(true)
else 
fadeCamera(false)
end
state = not state
end)

state = false
addCommandHandler ("s3d_hidecar",
function ()
if state then 
setElementAlpha(getPedOccupiedVehicle(localPlayer), 255)
else 
setElementAlpha(getPedOccupiedVehicle(localPlayer), 0)
end
state = not state
end)

addEventHandler("onClientGUIClick",resourceRoot,
function ( )
  if source == S3D.button[6] then
setWeather ( 13 )
end
 end)

addEventHandler("onClientGUIClick",resourceRoot,
function ( )
  if source == S3D.button[5] then
setWeather ( math.random(0,255) )
end
 end)

addEventHandler('onClientResourceStop', resourceRoot,
	function()
		setWeather ( 13 )
		setElementAlpha(getPedOccupiedVehicle(localPlayer), 255)
                fadeCamera(true)
                setElementAlpha(getLocalPlayer(), 255)
                showPlayerHudComponent("radar",true)
                showChat (true)
                setPlayerHudComponentVisible(component, true)
	end
)


addEventHandler ( "onClientGUIClick",resourceRoot,
    function ( )
if source == S3D.button[1] then
if guiGetText(S3D.button[1]) == ".::( اخفاء الشات | Hide The Chat )::." then
guiSetText (S3D.button[1],".::( اضهار الشات | Show The Chat )::.")
else
guiSetText (S3D.button[1],".::( اخفاء الشات | Hide The Chat )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[2] then
if guiGetText(S3D.button[2]) == ".::( اخفاء الدم / الدرع | Hide The Health - Armour Hud )::." then
guiSetText (S3D.button[2],".::( اضهار الدم / الدرع | Show The Health - Armour Hud )::.")
else
guiSetText (S3D.button[2],".::( اخفاء الدم / الدرع | Hide The Health - Armour Hud )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[3] then
if guiGetText(S3D.button[3]) == ".::( | اخفاء الرادار | Hide The `Radar Small Map` )::." then
guiSetText (S3D.button[3],".::( | اضهار الرادار | Show The `Radar Small Map` )::.")
else
guiSetText (S3D.button[3],".::( | اخفاء الرادار | Hide The `Radar Small Map` )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[4] then
if guiGetText(S3D.button[4]) == ".::( اخفاء نفسي اللاعب | Hide The Player My Self )::." then
guiSetText (S3D.button[4],".::( اضهار نفسي اللاعب | Show The Player My Self )::.")
else
guiSetText (S3D.button[4],".::( اخفاء نفسي اللاعب | Hide The Player My Self )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[7] then
if guiGetText(S3D.button[7]) == ".::( قطع رأسي الاعب | Cut My Head My Self )::." then
guiSetText (S3D.button[7],".::( ارجاع رأسي الاعب | Return My Head My Self )::.")
else
guiSetText (S3D.button[7],".::( قطع رأسي الاعب | Cut My Head My Self )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[8] then
if guiGetText(S3D.button[8]) == ".::( اخفاء سيارتي انا | Hide My Vehicle )::." then
guiSetText (S3D.button[8],".::( اضهار سيارتي انا | Show My Vehicle )::.")
else
guiSetText (S3D.button[8],".::( اخفاء سيارتي انا | Hide My Vehicle )::.")
end
end end )

addEventHandler ( "onClientGUIClick",resourceRoot,
	function ( )
if source == S3D.button[9] then
if guiGetText(S3D.button[9]) == ".::( شاشة سودآء الخروج من اللعب | Black Screen(FadeCamera) )::." then
guiSetText (S3D.button[9],".::( ! الرجوع للعب | Back To Game(FadeCamera) )::.")
else
guiSetText (S3D.button[9],".::( شاشة سودآء الخروج من اللعب | Black Screen(FadeCamera) )::.")
end
end end )