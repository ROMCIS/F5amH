 addEvent("S3D_Head",true) 
 addEventHandler("S3D_Head",root, function ( )
 if ( isPedHeadless(source) ) then
 setPedHeadless(source,false)
 else
 setPedHeadless(source,true)
 end
 end)

addEvent('S3D_Contorol',true)
addEventHandler('S3D_Contorol',root,
function( )
triggerClientEvent(source ,'S3D_Contorol1', source)
end)
