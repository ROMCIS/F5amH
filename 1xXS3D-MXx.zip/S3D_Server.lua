﻿ addCommandHandler ( "s3d_send",
 function (thePlayer,_,money )  local money = tonumber(money)
 local name = getPlayerName(thePlayer)
 local accName = getAccountName ( getPlayerAccount ( thePlayer ) ) 
if ( s3d_serials[getPlayerSerial( thePlayer )] ) then -- outputChatBox('يجب ان تمتلك صلاحية الادمنية', 255, 0, 0, thePlayer)if isTimer(RoMcIS) then return OutPut("! يرجى الانتظار",thePlayer,255,255,0) ; endif money thenelse OutPut("! قم بكتابة المبلغ أولا",thePlayer,255,255,0)returnend if tonumber(money) <= 999999999 thenelse OutPut("! قم بتقليل المبلغ",thePlayer,255,255,0)returnend  givePlayerMoney (getRootElement(),money) 
		    outputChatBox("==============================", getRootElement(),255,0,0,true )
                      outputChatBox("==============================", getRootElement(),255,0,0,true )
		outputChatBox ( "*" .. name .. " | Has Been Sent [ ".. money .." ] Money To All Players", getRootElement(), 0, 255, 0, true )
        outputChatBox("==============================", getRootElement(),255,0,0,true )
        outputChatBox("==============================", getRootElement(),255,0,0,true )RoMcIS = setTimer(function () end,8500,1) 
 end
 end )function OutPut(message, player, r, g, b)triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)end