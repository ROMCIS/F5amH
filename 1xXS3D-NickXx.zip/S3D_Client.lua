﻿Cplayer = getLocalPlayer(  )

local screenW, screenH = guiGetScreenSize()

S3D = {
    checkbox = {},
    edit = {},
    button = {},
    window = {},
    label = {}
}

S3D.window[1] = guiCreateWindow(463, 267, 515, 366, "=][لوحة النــك العربي][=", false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1.00)
guiSetProperty(S3D.window[1], "CaptionColour", "FFFF1E00")
guiSetVisible(S3D.window[1], false)
S3D.edit[1] = guiCreateEdit(106, 63, 274, 31, "", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(381, 185, 119, 15, "لـ تفعيل النك العربي:", false, S3D.window[1])
guiSetFont(S3D.label[1], "default-bold-small")
guiLabelSetColor(S3D.label[1], 17, 223, 230)
S3D.label[2] = guiCreateLabel(69, 185, 331, 17, "سعر الأشتراك || 30 سوا شهر || 10 كاش يو شهرين.", false, S3D.window[1])
guiSetFont(S3D.label[2], "default-bold-small")
guiLabelSetColor(S3D.label[2], 8, 239, 8)  
S3D.label[3] = guiCreateLabel(68, 147, 352, 15, "*يجب عدم وضع نك مخالف وفي حال وضع ذلك سيتم سحب الخاصية.", false, S3D.window[1])
guiSetFont(S3D.label[3], "default-bold-small")
guiLabelSetColor(S3D.label[3], 247, 8, 40)  
S3D.label[5] = guiCreateLabel(395, 69, 102, 15, "النكــ العربي:.", false, S3D.window[1])
guiSetFont(S3D.label[5], "default-bold-small")
guiLabelSetColor(S3D.label[5], 17, 223, 230)
S3D.button[2] = guiCreateButton(272, 110, 138, 27, "وضع", false, S3D.window[1])
guiSetFont(S3D.button[2], "default-bold-small")
guiSetProperty(S3D.button[2], "NormalTextColour", "FFEFEF08")
S3D.button[5] = guiCreateButton(87, 110, 138, 27, "ازالة", false, S3D.window[1])
guiSetFont(S3D.button[5], "default-bold-small")
guiSetProperty(S3D.button[5], "NormalTextColour", "FFEFEF08")
guiSetVisible(S3D.button[2], false)
guiSetVisible(S3D.button[5], false)
---
S3D.button[11] = guiCreateButton(272, 110, 138, 27, "وضع", false, S3D.window[1])
guiSetFont(S3D.button[11], "default-bold-small")
guiSetProperty(S3D.button[11], "NormalTextColour", "FFEFEF08")
S3D.button[12] = guiCreateButton(87, 110, 138, 27, "ازالة", false, S3D.window[1])
guiSetFont(S3D.button[12], "default-bold-small")
guiSetProperty(S3D.button[12], "NormalTextColour", "FFEFEF08")
---
guiSetProperty(S3D.button[5], "NormalTextColour", "FFEFEF08")
S3D.button[3] = guiCreateButton(169, 236, 167, 31, "صــوره لـ النكـ العربي", false, S3D.window[1])
guiSetFont(S3D.button[3], "default-bold-small")
guiSetProperty(S3D.button[3], "NormalTextColour", "FFEFEF08")
S3D.button[9] = guiCreateButton(169, 277, 167, 29, "فتح لوحة الشراء", false, S3D.window[1])
guiSetFont(S3D.button[9], "default-bold-small")
guiSetProperty(S3D.button[9], "NormalTextColour", "FFEFEF08")
S3D.button[4] = guiCreateButton(466, 327, 39, 29, "✖", false, S3D.window[1])
guiSetProperty(S3D.button[4], "NormalTextColour", "FFEC0A0A")	

nicksPlayers = guiCreateWindow(251, 86, 307, 385, "=[ عــرض الأسماء العربية ]=", false)
guiWindowSetSizable(nicksPlayers, false)
guiSetAlpha(nicksPlayers, 1.00)
guiSetProperty(nicksPlayers, "CaptionColour", "FF00FEF6")
guiSetVisible(nicksPlayers, false)
SeditPlayers_nicksPlayers = guiCreateEdit(9, 26, 288, 33, "", false, nicksPlayers)
PlayersGrid_nicksPlayers = guiCreateGridList(32, 70, 241, 263, false, nicksPlayers)
guiGridListAddColumn(PlayersGrid_nicksPlayers, "# Players ...", 0.6)
guiGridListAddColumn(PlayersGrid_nicksPlayers, "", 0.6)
buttonPlayers_nicksPlayers = guiCreateButton(263, 343, 27, 28, "X", false, nicksPlayers)
guiSetFont(buttonPlayers_nicksPlayers, "default-bold-small")
guiSetProperty(buttonPlayers_nicksPlayers, "NormalTextColour", "FFFEEF00")
labelPlayers_nicksPlayers = guiCreateLabel(28, 349, 125, 22, "Name:", false, nicksPlayers)
guiSetFont(labelPlayers_nicksPlayers, "default-bold-small")    
labelPlayers_nicksPlayers2 = guiCreateLabel(77, 349, 120, 16, "", false, nicksPlayers)
guiSetFont(labelPlayers_nicksPlayers2, "default-bold-small")
guiLabelSetColor(labelPlayers_nicksPlayers2, 0, 255, 234)  
----------
nicksManager = guiCreateWindow((screenW - 512) / 2, (screenH - 454) / 2, 512, 454, ". : لوحة إدارة الأسماء العربية : .", false)
guiWindowSetSizable(nicksManager, false)
guiSetAlpha(nicksManager, 1.00)
guiSetVisible(nicksManager, false)
xClose_nicksManager = guiCreateButton(402, 422, 100, 22, "X", false, nicksManager)
guiSetFont(xClose_nicksManager, "default-bold-small")
guiSetProperty(xClose_nicksManager, "NormalTextColour", "FFFB0000")
belowlbl_nicksManager = guiCreateLabel(10, 31, 491, 20, "=[ المستخدمين الذين تم تفعيلهم مسبقا ]=", false, nicksManager)
guiSetFont(belowlbl_nicksManager, "default-bold-small")
guiLabelSetColor(belowlbl_nicksManager, 19, 191, 254)
guiLabelSetHorizontalAlign(belowlbl_nicksManager, "center", false)
guiLabelSetVerticalAlign(belowlbl_nicksManager, "center")
UsersGrid_nicksManager = guiCreateGridList(10, 56, 491, 158, false, nicksManager)
guiGridListAddColumn(UsersGrid_nicksManager, "الإسم الأصلي", 0.4)
guiGridListAddColumn(UsersGrid_nicksManager, "الإسم العربي", 0.4)
guiGridListAddColumn(UsersGrid_nicksManager, "حالة الخاصية", 0.4)
guiGridListAddColumn(UsersGrid_nicksManager, "تاريخ التفعيل", 0.4)
controllbl_nicksManager = guiCreateLabel(10, 219, 491, 20, "=[ التحكم بالمستخدمين ]=", false, nicksManager)
guiSetFont(controllbl_nicksManager, "default-bold-small")
guiLabelSetColor(controllbl_nicksManager, 19, 191, 254)
guiLabelSetHorizontalAlign(controllbl_nicksManager, "center", false)
delSelected_nicksManager = guiCreateButton(298, 249, 142, 23, "حذف المستخدم المحدد", false, nicksManager)
guiSetFont(delSelected_nicksManager, "default-bold-small")
guiSetProperty(delSelected_nicksManager, "NormalTextColour", "FF12FE60")
copySerSelected_nicksManager = guiCreateButton(69, 249, 142, 23, "نسخ سيريال المستخدم", false, nicksManager)
guiSetFont(copySerSelected_nicksManager, "default-bold-small")
guiSetProperty(copySerSelected_nicksManager, "NormalTextColour", "FF12FE60")
line1_nicksManager = guiCreateLabel(10, 276, 491, 15, "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ", false, nicksManager)
guiSetFont(line1_nicksManager, "default-bold-small")
guiLabelSetHorizontalAlign(line1_nicksManager, "center", false)
guiLabelSetVerticalAlign(line1_nicksManager, "center")
addnewlbl_nicksManager = guiCreateLabel(10, 301, 491, 20, "=[ إضافة المستخدمين الجدد ]=", false, nicksManager)
guiSetFont(addnewlbl_nicksManager, "default-bold-small")
guiLabelSetColor(addnewlbl_nicksManager, 19, 191, 254)
guiLabelSetHorizontalAlign(addnewlbl_nicksManager, "center", false)
pseriallbl_nicksManager = guiCreateLabel(328, 331, 173, 19, "* السيريال الخاص بالمستخدم :-", false, nicksManager)
guiSetFont(pseriallbl_nicksManager, "default-bold-small")
guiLabelSetColor(pseriallbl_nicksManager, 217, 7, 255)
guiLabelSetHorizontalAlign(pseriallbl_nicksManager, "right", false)
guiLabelSetVerticalAlign(pseriallbl_nicksManager, "center")
pSerialEdit_nicksManager = guiCreateEdit(20, 331, 308, 19, "", false, nicksManager)
addNewButton_nicksManager = guiCreateButton(102, 360, 142, 23, "تفعــيل المستخـــدم", false, nicksManager)
guiSetFont(addNewButton_nicksManager, "default-bold-small")
guiSetProperty(addNewButton_nicksManager, "NormalTextColour", "FFFF6215")
line2_nicksManager = guiCreateLabel(10, 393, 491, 15, "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ", false, nicksManager)
guiSetFont(line2_nicksManager, "default-bold-small")
guiLabelSetHorizontalAlign(line2_nicksManager, "center", false)
guiLabelSetVerticalAlign(line2_nicksManager, "center")
NicksLog_nicksManager = guiCreateButton(153, 422, 204, 22, "سجل نشاطات المستخدمين", false, nicksManager)
guiSetFont(NicksLog_nicksManager, "default-bold-small")
guiSetProperty(NicksLog_nicksManager, "NormalTextColour", "FFD1D900")
----------
nicksLog = guiCreateWindow((screenW - 624) / 2, (screenH - 346) / 2, 624, 346, ". : سجل النشاطات - الأسماء العربية : .", false)
guiWindowSetSizable(nicksLog, false)
guiSetAlpha(nicksLog, 1.00)
guiSetVisible(nicksLog, false)
xClose_nicksLog = guiCreateButton(178, 314, 266, 22, "X", false, nicksLog)
guiSetFont(xClose_nicksLog, "default-bold-small")
guiSetProperty(xClose_nicksLog, "NormalTextColour", "FFFB0000")
LogGrid_nicksLog = guiCreateGridList(10, 30, 604, 239, false, nicksLog)
guiGridListAddColumn(LogGrid_nicksLog, "الإسم الأصلي", 0.4)
guiGridListAddColumn(LogGrid_nicksLog, "الإسم العربي", 0.4)
guiGridListAddColumn(LogGrid_nicksLog, "لون الإسم", 0.2)
guiGridListAddColumn(LogGrid_nicksLog, "التاريخ", 0.4)
CopySer_nicksLog = guiCreateButton(130, 279, 158, 20, "نسخ سيريال المستخدم", false, nicksLog)
guiSetFont(CopySer_nicksLog, "default-bold-small")
guiSetProperty(CopySer_nicksLog, "NormalTextColour", "FFF8FF43")
ClearLog_nicksLog = guiCreateButton(336, 279, 158, 20, "إزالة سجل النشاطات", false, nicksLog)
guiSetFont(ClearLog_nicksLog, "default-bold-small")
guiSetProperty(ClearLog_nicksLog, "NormalTextColour", "FFF8FF43")
----------
ExWnd = guiCreateWindow((screenW - 334) / 2, (screenH - 549) / 2, 334, 549, "", false)
guiWindowSetSizable(ExWnd, false)
guiSetAlpha(ExWnd, 1.00)
guiSetVisible(ExWnd, false)
Picture_ExWnd = guiCreateStaticImage(42, 32, 249, 479, "s3d.png", false, ExWnd)
xClose_ExWnd = guiCreateButton(107, 521, 119, 18, "X", false, ExWnd)
guiSetFont(xClose_ExWnd, "default-bold-small")
guiSetProperty(xClose_ExWnd, "NormalTextColour", "FFFF0000")


function clickElements(  )
	if ( source == S3D.button[4] ) then
		guiSetVisible( S3D.window[1], false )
		guiSetInputEnabled( false )
		showCursor( false )
	elseif ( source == buttonPlayers_nicksPlayers ) then
		guiSetVisible( nicksPlayers, false )
		guiSetInputEnabled( false )
		showCursor( false )
	elseif ( source == xClose_nicksManager ) then
		guiSetVisible( nicksManager, false )
		guiSetInputEnabled( false )
		showCursor( false )
	elseif ( source == addNewButton_nicksManager ) then
		local pSerial = guiGetText( pSerialEdit_nicksManager )
			if ( pSerial == '' or guiEditGetCaretIndex( pSerialEdit_nicksManager ) < 32 or guiEditGetCaretIndex( pSerialEdit_nicksManager ) > 32 ) then 
			outputChatBox( '#FF0000* #FFFF00Arabic Nicks #FF0000: #FFFFFF عذرا لم يتم التعرف على السيريال الذي أدخلته, قم بأدخال السيريال بشكل صحيح !', 255, 255, 255, true ) return end
		triggerServerEvent( 'onServerAddUser', Cplayer, pSerial )
		guiSetEnabled( addNewButton_nicksManager, false )
		setTimer( guiSetEnabled, 2000, 1, addNewButton_nicksManager, true )
	elseif ( source == S3D.button[2] ) then
		local arabicName = guiGetText( S3D.edit[1] )
			if ( arabicName == '' or arabicName == '' ) then
			exports.infobox:outputMessage("! عذرا, لم تقم بكتابة إسم صحيح, قم بكتابة إسم ليتم التغيير له *",170,247,255,true) return end
				if ( getPlayerNametagText ( Cplayer ) == arabicName ) then
					exports.infobox:outputMessage("! عذرا, لايمكنك التغيير لهذا الإسم, انه اسمك الحالي *",170,247,255,true) return end
				if ( not setPlayerNametagText( Cplayer, arabicName ) ) then
					exports.infobox:outputMessage("! عذرا, الإسم الذي أدخلته لايمكن إستخدامه *",170,247,255,true) return end
			triggerServerEvent( 'onServerUpdateNick', Cplayer, arabicName )
				guiSetEnabled( S3D.button[2], false )
			setTimer( guiSetEnabled, 2000, 1, S3D.button[2], true )
exports.infobox:outputMessage("! تم تغيير النك ينجاح *",170,247,255,true)
	elseif ( source == NicksLog_nicksManager ) then
		guiSetVisible( nicksManager, false )
		guiSetVisible( nicksLog, true )
	elseif ( source == xClose_nicksLog ) then
		guiSetVisible( nicksLog, false )
		guiSetVisible( nicksManager, true )
	elseif ( source == delSelected_nicksManager ) then
		local Sel = guiGridListGetSelectedItem( UsersGrid_nicksManager )
			if ( Sel == -1 ) then
				outputChatBox( '#FF0000* #FFFF00Arabic Nicks #FF0000: #FFFFFF عذرا, قم بتحديد احد المستخدمين لتنفيذ الأمر !', 255, 255, 255, true ) return end
			local Serial = guiGridListGetItemData( UsersGrid_nicksManager, Sel, 1 )
		triggerServerEvent( 'onServerDeleteUser', Cplayer, Serial )
		guiSetEnabled( delSelected_nicksManager, false )
		setTimer( guiSetEnabled, 2000, 1, delSelected_nicksManager, true )
	elseif ( source == copySerSelected_nicksManager ) then
		local Sel = guiGridListGetSelectedItem( UsersGrid_nicksManager )
			if ( Sel == -1 ) then
				outputChatBox( '#FF0000* #FFFF00Arabic Nicks #FF0000: #FFFFFF عذرا, قم بتحديد احد المستخدمين لتنفيذ الأمر !', 255, 255, 255, true ) return end
			local Serial = guiGridListGetItemData( UsersGrid_nicksManager, Sel, 1 )
				setClipboard( Serial )
			guiSetEnabled( copySerSelected_nicksManager, false )
		setTimer( guiSetEnabled, 2000, 1, copySerSelected_nicksManager, true )
	elseif ( source == CopySer_nicksLog ) then
		local Sel = guiGridListGetSelectedItem( LogGrid_nicksLog )
			if ( Sel == -1 ) then
				outputChatBox( '#FF0000* #FFFF00Arabic Nicks #FF0000: #FFFFFF عذرا, قم بتحديد احد المستخدمين لتنفيذ الأمر !', 255, 255, 255, true ) return end
			local Serial = guiGridListGetItemData( LogGrid_nicksLog, Sel, 1 )
				setClipboard( Serial )
			guiSetEnabled( CopySer_nicksLog, false )
		setTimer( guiSetEnabled, 2000, 1, CopySer_nicksLog, true )
	elseif ( source == ClearLog_nicksLog ) then
		triggerServerEvent( 'onServerFormatLog', Cplayer )
			guiSetEnabled( ClearLog_nicksLog, false )
		setTimer( guiSetEnabled, 2000, 1, ClearLog_nicksLog, true )
	elseif ( source == S3D.button[3] ) then
		guiSetVisible(  S3D.window[1], false )
		guiSetVisible( ExWnd, true )
	elseif ( source == xClose_ExWnd ) then
		guiSetVisible(  S3D.window[1], true )
		guiSetVisible( ExWnd, false )
	elseif ( source == S3D.checkbox[1] and guiCheckBoxGetSelected( S3D.checkbox[1] ) == true ) then
		guiCheckBoxSetSelected( S3D.button[5], false )
			local status = 'Enabled'
		triggerServerEvent( 'onServerUpdateUserSysStatus', Cplayer, status )
		setTimer( guiSetEnabled, 50, 10, S3D.checkbox[1], false )
		setTimer( guiSetEnabled, 2000, 1, S3D.checkbox[1], true )
		setTimer( guiSetEnabled, 50, 10, S3D.button[5], false )
		setTimer( guiSetEnabled, 2000, 1, S3D.button[5], true )
	elseif ( source == S3D.button[5] and guiCheckBoxGetSelected( S3D.button[5] ) == true ) then
		guiCheckBoxSetSelected( S3D.checkbox[1], false )
			local status = nil
		triggerServerEvent( 'onServerUpdateUserSysStatus', Cplayer, status )
		setTimer( guiSetEnabled, 50, 10, S3D.button[5], false )
		setTimer( guiSetEnabled, 2000, 1, S3D.button[5], true )
		setTimer( guiSetEnabled, 50, 10, S3D.checkbox[1], false )
		setTimer( guiSetEnabled, 2000, 1, S3D.checkbox[1], true )
end
end
addEventHandler( 'onClientGUIClick', root, clickElements )

addEventHandler("onClientGUIClick",root,
function()
if (source == S3D.button[11]) then
exports.infobox:outputMessage('!يجب اشتراكك في النظام ل تفعيل النك العربي',math.random(0,255),math.random(0,255),math.random(0,155),source)	
end
end)

addEventHandler("onClientGUIClick",root,
function()
if (source == S3D.button[12]) then
exports.infobox:outputMessage('!يجب اشتراكك في النظام ل تفعيل النك العربي',math.random(0,255),math.random(0,255),math.random(0,155),source)			
end
end)

addEvent( 'onClientAllLogs', true )
addEventHandler( 'onClientAllLogs', root,
function( Table )
	guiGridListClear( PlayersGrid_nicksPlayers )
		for i, _ in ipairs( Table ) do
			local row = guiGridListAddRow( PlayersGrid_nicksPlayers )
				guiGridListSetItemText( PlayersGrid_nicksPlayers, row, 1, Table[i].realName, false, false )
				guiGridListSetItemText( PlayersGrid_nicksPlayers, row, 2, Table[i].arName, false, false )
				guiGridListSetItemText( PlayersGrid_nicksPlayers, row, 3, 'لون الإسم الحالي', false, false )
				guiGridListSetItemText( PlayersGrid_nicksPlayers, row, 4, Table[i].Date, false, false )
			guiGridListSetItemData( PlayersGrid_nicksPlayers, row, 1, Table[i].serial )
		guiGridListSetItemColor( PlayersGrid_nicksPlayers, row, 2, 0, 255, 234 )
	    local playerName = guiGridListGetItemText ( PlayersGrid_nicksPlayers, guiGridListGetSelectedItem ( PlayersGrid_nicksPlayers ), 1 )
if ( guiGridListGetSelectedItem ( PlayersGrid_nicksPlayers ) == -1 ) then
     guiSetText( labelPlayers_nicksPlayers2, Table[i].realName )
	end
end
end )

addEvent( 'onClientAddAll', true )
addEventHandler( 'onClientAddAll', root,
function( Table )
	guiGridListClear( UsersGrid_nicksManager )
		for i, _ in ipairs( Table ) do
			local row = guiGridListAddRow( UsersGrid_nicksManager )
				guiGridListSetItemText( UsersGrid_nicksManager, row, 1, Table[i].realName, false, false )
				guiGridListSetItemText( UsersGrid_nicksManager, row, 2, Table[i].arName, false, false )
				guiGridListSetItemText( UsersGrid_nicksManager, row, 4, Table[i].activateDate, false, false )
			guiGridListSetItemData( UsersGrid_nicksManager, row, 1, Table[i].serial )
				if ( Table[i].serviceStatus == 'Enabled' ) then
					guiGridListSetItemText( UsersGrid_nicksManager, row, 3, '[ فعالة / Enabled ]', false, false )
				else
			guiGridListSetItemText( UsersGrid_nicksManager, row, 3, '[ غير فعالة / Disabled ]', false, false )
	end
	end
end )

addEvent( 'onClientUpdateUserSystem', true )
addEventHandler( 'onClientUpdateUserSystem', root,
function( myArabicName, r, g, b, elementStatus, sysStatus )
	if ( elementStatus ~= nil and elementStatus == 'notUser' ) then
		triggerServerEvent( 'onServerSetUserName', Cplayer, false, false, false, false, 'notUser' ) return end
	guiSetText( S3D.label[3], '*تم تفعيل الخاصية من قبل صاحب السيرفر | ممنوع نك مخالف وشكرا.' )
guiLabelSetColor( S3D.label[3], 255, 239, 0 )
	guiSetText( S3D.edit[1], myArabicName )
	--guiLabelSetColor( S3D.label[90], r, g, b )
	guiSetEnabled( S3D.edit[1], true )
	guiSetEnabled( S3D.button[1], true )
	guiSetEnabled( S3D.checkbox[1], true )
guiSetVisible(S3D.button[2], true)
guiSetVisible(S3D.button[5], true)
guiSetVisible(S3D.button[11], false)
guiSetVisible(S3D.button[12], false)
	triggerServerEvent( 'onServerSetUserName', Cplayer, myArabicName, r, g, b, nil, sysStatus )
	if ( sysStatus ~= nil and sysStatus == 'Enabled' ) then
		guiCheckBoxSetSelected( S3D.checkbox[1], true )
		guiCheckBoxSetSelected( S3D.button[5], false )
		guiSetEnabled( S3D.edit[1], true )
		guiSetEnabled( S3D.button[1], true )
		guiSetEnabled( S3D.button[2], true )
	else if ( sysStatus ~= nil and sysStatus == 'Disabled' ) then
		guiCheckBoxSetSelected( S3D.button[5], true )
		guiCheckBoxSetSelected( S3D.checkbox[1], false )
		guiSetEnabled( S3D.edit[1], false )
		guiSetEnabled( S3D.button[1], false )
		guiSetEnabled( S3D.button[2], false )
	end
end
end )

addEvent( 'onClientResetNameField', true )
addEventHandler( 'onClientResetNameField', root,
function(  )
	local r, g, b = getPlayerNametagColor( Cplayer )
	guiSetText( S3D.edit[1], getPlayerNametagText( Cplayer ) )
	--guiLabelSetColor( S3D.label[90], r, g, b )
end )

addEvent( 'onClientResetUserSystem', true )
addEventHandler( 'onClientResetUserSystem', root,
function(  )
	guiSetEnabled( S3D.edit[1], false )
		guiSetEnabled( S3D.button[1], false )
			guiSetEnabled( S3D.button[1], false )
				guiSetEnabled( S3D.button[2], false )
			guiSetText( S3D.edit[1], '' )
		guiSetText( S3D.label[3], '*يجب عدم وضع نك مخالف وفي حال وضع ذلك سيتم سحب الخاصية.' )
	guiLabelSetColor( S3D.label[3], 247, 8, 40 )
	guiSetEnabled( S3D.checkbox[1], false )
	guiSetEnabled( S3D.button[5], false )
	guiCheckBoxSetSelected( S3D.checkbox[1], false )
	guiCheckBoxSetSelected( S3D.button[5], false )
end )

addEvent( 'onClientClearLogList', true ) addEventHandler( 'onClientClearLogList', root, function(  ) guiGridListClear( SeditPlayers_nicksPlayers ) end )

addEvent( 'onClientClearUsersList', true ) addEventHandler( 'onClientClearUsersList', root, function(  ) guiGridListClear( UsersGrid_nicksManager ) end )

addEventHandler( 'onClientResourceStart', resourceRoot,
function(  )
	triggerServerEvent( 'onServerRefreshSystem', Cplayer )
end )

function openManagerSystem(  )
	guiSetVisible( nicksManager, not guiGetVisible( nicksManager ) )
		guiSetInputEnabled( guiGetVisible( nicksManager ) )
	showCursor( guiGetVisible( nicksManager ) )
end
addEvent( 'onClientOpenManagement', true )
addEventHandler( 'onClientOpenManagement', root, openManagerSystem )

addCommandHandler( 'عربي',
function(  )
		guiSetVisible( S3D.window[1], not guiGetVisible( S3D.window[1] ) )
		guiSetInputEnabled( guiGetVisible( S3D.window[1] ) )
	showCursor( guiGetVisible( S3D.window[1] ) )
end )

addCommandHandler( 'NickArab',
function(  )
		guiSetVisible( nicksPlayers, not guiGetVisible( nicksPlayers ) )
		guiSetInputEnabled( guiGetVisible( nicksPlayers ) )
	showCursor( guiGetVisible( nicksPlayers ) )
end )
