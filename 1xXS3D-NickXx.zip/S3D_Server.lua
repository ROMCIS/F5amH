﻿setTimer( function(  )
-- exports.scoreboard:addScoreboardColumn( 'Ar-Name', root, 400, 0.18 )
end, 500, 1 )
local NicksDB = dbConnect( 'sqlite', 's3d.db' )
dbExec( NicksDB, ' CREATE TABLE IF NOT EXISTS `s3d_user` ( serial, realName, arName, r, g, b, activateDate, serviceStatus ) ' )
	
function refreshSystem( )
setTimer( function(  )
	local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` ' )
		local results = dbPoll( dbCheck, -1 )
			if ( type( results ) == 'table' and #results == 0 or not results ) then triggerClientEvent( root, 'onClientClearUsersList', root ) return end
				triggerClientEvent( root, 'onClientAddAll', root, results )
					for _, player in ipairs( getElementsByType( 'player' ) ) do
						local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', getPlayerSerial( player ) )
							local results = dbPoll( dbCheck, -1 )
								if ( type( results ) == 'table' and #results ~= 0 ) then
								local Name = results[1]['arName']
							local r, g, b = results[1]['r'], results[1]['g'], results[1]['b']
							local myStatus = results[1]['serviceStatus']
						triggerClientEvent( player, 'onClientUpdateUserSystem', player, Name, r, g, b, nil, myStatus )
						dbExec( NicksDB, ' UPDATE `s3d_user` SET realName = ? WHERE serial = ? ', getPlayerName( player ), getPlayerSerial( player ) )
					else triggerClientEvent( player, 'onClientResetUserSystem', player ) triggerClientEvent( player, 'onClientUpdateUserSystem', player, false, false, false, false, 'notUser' ) end
					end
addEvent( 'onServerRefreshSystem', true ) addEventHandler( 'onServerRefreshSystem', root, refreshSystem )

addEvent( 'onServerUpdateUserSysStatus', true )
addEventHandler( 'onServerUpdateUserSysStatus', root,
function( Status )
	local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', getPlayerSerial( source ) )
		local results = dbPoll( dbCheck, -1 )
			if ( type( results ) == 'table' and #results == 0 or not results ) then return end
		if ( Status == 'Enabled' ) then
			dbExec( NicksDB, ' UPDATE `s3d_user` SET serviceStatus = ? WHERE serial = ? ', 'Enabled', getPlayerSerial( source ) )
			else
				dbExec( NicksDB, ' UPDATE `s3d_user` SET serviceStatus = ? WHERE serial = ? ', 'Disabled', getPlayerSerial( source ) )
			end
	refreshSystem(  )
end )

addEvent( 'onServerSetUserName', true )
addEventHandler( 'onServerSetUserName', root,
function( Name, r, g, b, state, sysStatus )
	for _, player in ipairs( getElementsByType( 'player' ) ) do
		if ( state == 'notUser' ) then
		setPlayerNametagText( source, getPlayerName( source ) )
		setElementData( source, 'Ar-Name', nil )
		setPlayerNametagColor( source, math.random(25, 255), math.random(25, 255), math.random(25, 255) )
			else
		if ( sysStatus ~= nil and sysStatus == 'Enabled' ) then
			setPlayerNametagText( source, Name )
				setPlayerNametagColor( source, r, g, b )
				setElementData( source, 'Ar-Name', Name )
					else
				setPlayerNametagText( source, getPlayerName( source ) )
				setElementData( source, 'Ar-Name', nil )
			setPlayerNametagColor( source, math.random(25, 255), math.random(25, 255), math.random(25, 255) )
			triggerClientEvent( source, 'onClientResetNameField', source )
		end
	end
end
end )

function resetUserSystem(  )
setTimer( function(  )
	for _, player in ipairs( getElementsByType( 'player' ) ) do
		local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', getPlayerSerial( player ) )
			local results = dbPoll( dbCheck, -1 )
				if ( type( results ) == 'table' and #results ~= 0 ) then
					local Name = results[1]['arName']
						local r, g, b = results[1]['r'], results[1]['g'], results[1]['b']
					triggerClientEvent( player, 'onClientUpdateUserSystem', player, Name, r, g, b )
				dbExec( NicksDB, ' UPDATE `s3d_user` SET realName = ? WHERE serial = ? ', getPlayerName( player ), getPlayerSerial( player ) )
		refreshSystem(  )
	else triggerClientEvent( player, 'onClientResetUserSystem', player ) triggerClientEvent( player, 'onClientUpdateUserSystem', player, false, false, false, false, 'notUser' ) end
	end
end, 300, 1 )
end

addEventHandler( 'onPlayerChangeNick', getRootElement(  ),
function( new )
	dbExec( NicksDB, ' UPDATE `s3d_user` SET realName = ? WHERE serial = ? ', new, getPlayerSerial( source ) )
	refreshSystem( )
end )

addEvent( 'onServerUpdateNick', true )
addEventHandler( 'onServerUpdateNick', root,
function( Nick )
	local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', getPlayerSerial( source ) )
		local results = dbPoll( dbCheck, -1 )
		if ( type( results ) == 'table' and #results == 0 or not results ) then return end
		local r, g, b = results[1]['r'], results[1]['g'], results[1]['b']
		local Name = results[1]['arName']
	dbExec( NicksDB, ' UPDATE `s3d_user` SET arName = ? WHERE serial = ? ', Nick, getPlayerSerial( source ) )
	refreshSystem(  )
end )

addEvent( 'onServerUpdateColor', true )
addEventHandler( 'onServerUpdateColor', root,
function( r, g, b )
	local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', getPlayerSerial( source ) )
		local results = dbPoll( dbCheck, -1 )
		if ( type( results ) == 'table' and #results == 0 or not results ) then return end
	dbExec( NicksDB, ' UPDATE `s3d_user` SET r = ?, g = ?, b = ? WHERE serial = ? ', r, g, b, getPlayerSerial( source ) )
end )

addEvent( 'onServerDeleteUser', true )
addEventHandler( 'onServerDeleteUser', root,
function( Serial )
	local dbCheck = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', Serial )
		local results = dbPoll( dbCheck, -1 )
		if ( type( results ) == 'table' and #results == 0 or not results ) then return end
	dbExec( NicksDB, ' DELETE FROM `s3d_user` WHERE serial = ? ', Serial )
		refreshSystem(  )
		resetUserSystem(  )
	outputChatBox( '#00ff00* #FFFF00Arabic Nicks #00ff00: #FFFFFF تم حذف المستخدم بنجاح !', source, 255, 255, 255, true )
end )

addEvent( 'onServerAddUser', true )
addEventHandler( 'onServerAddUser', root,
function( serial )
	local check = dbQuery( NicksDB, ' SELECT * FROM `s3d_user` WHERE serial = ? ', serial )
		local results = dbPoll( check, -1 )
			if ( type( results ) == 'table' and #results ~= 0 ) then
				outputChatBox( '#FF0000* #FFFF00Arabic Nicks #FF0000: #FFFFFF عذرا, تم تفعيل هذا المستخدم مسبقا ... قم بأختيار مستخدم آخر !', source, 255, 255, 255, true ) return end
			dbExec( NicksDB, ' INSERT INTO `s3d_user` VALUES(?,?,?,?,?,?,?,?) ', serial, 'a Player', '', 255, 255, 255, 'Enabled' )
		resetUserSystem(  )
		refreshSystem(  )
	outputChatBox( '#00ff00* #FFFF00Arabic Nicks #00ff00: #FFFFFF تم إضافة المستخدم بنجاح !', source, 255, 255, 255, true )
end 
)