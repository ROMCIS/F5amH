﻿local Serial = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["DE75A78DFDBE9918A725E38238F5F094"] = true, -- كريزي
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
["1A5AE4945A35897595921B1F48DE5854"] = true, -- فاندام
};

addCommandHandler('ساعات',
function()
if ( Serial[getPlayerSerial( localPlayer )] ) then
triggerEvent('s3d',localPlayer)
else outputChatBox('!لا تملك تصريح لفتح هذه اللوحة',255,0,0) end end)

S3D = {
    checkbox = {},
	staticimage = {},
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}

    function cr()
local screenW, screenH = guiGetScreenSize()
S3D.window[1] = guiCreateWindow((screenW - 520) / 2, (screenH - 451) / 2, 520, 451, "=[ Time Panel | لوحة الساعات ]=", false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1.00)
guiSetVisible(S3D.window[1], false)

S3D.gridlist[1] = guiCreateGridList(14, 66, 250, 342, false, S3D.window[1])
guiGridListAddColumn(S3D.gridlist[1], "Players :", 0.5)
guiGridListAddColumn(S3D.gridlist[1], "Time :", 0.5)
S3D.edit[2] = guiCreateEdit(14, 31, 250, 25, "Search :", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(293, 27, 217, 14, "تحذير : اللوحة مراقبة من داخل الأستضافة", false, S3D.window[1])
guiSetFont(S3D.label[1], "default-bold-small")
guiLabelSetColor(S3D.label[1], 255, 0, 0)
S3D.edit[1] = guiCreateEdit(328, 85, 95, 28, "", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(288, 55, 15, 382, "┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃\n┃", false, S3D.window[1])
guiSetFont(S3D.label[2], "default-bold-small")
guiLabelSetColor(S3D.label[2], 37, 217, 59)
S3D.label[3] = guiCreateLabel(433, 91, 53, 16, "الساعات :", false, S3D.window[1])
guiSetFont(S3D.label[3], "default-bold-small")
S3D.button[1] = guiCreateButton(324, 150, 176, 27, "اعطاء", false, S3D.window[1])
guiSetFont(S3D.button[1], "default-bold-small")
guiSetProperty(S3D.button[1], "NormalTextColour", "FF00FF00")
S3D.button[2] = guiCreateButton(324, 187, 176, 27, "حذف", false, S3D.window[1])
guiSetFont(S3D.button[2], "default-bold-small")
guiSetProperty(S3D.button[2], "NormalTextColour", "FFFF0000")
S3D.edit[3] = guiCreateEdit(328, 235, 95, 28, "", false, S3D.window[1])
S3D.edit[4] = guiCreateEdit(328, 282, 95, 28, "", false, S3D.window[1])
S3D.edit[5] = guiCreateEdit(332, 331, 95, 28, "", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(433, 241, 53, 16, "الساعات :", false, S3D.window[1])
guiSetFont(S3D.label[4], "default-bold-small")
S3D.label[5] = guiCreateLabel(433, 288, 53, 16, "الكلمة :", false, S3D.window[1])
guiSetFont(S3D.label[5], "default-bold-small")
S3D.label[6] = guiCreateLabel(433, 337, 53, 16, "المدة :", false, S3D.window[1])
guiSetFont(S3D.label[6], "default-bold-small")
S3D.button[3] = guiCreateButton(324, 376, 176, 27, "أرسال المعلومات", false, S3D.window[1])
guiSetFont(S3D.button[3], "default-bold-small")
guiSetProperty(S3D.button[3], "NormalTextColour", "FF00FF00")
S3D.button[4] = guiCreateButton(324, 410, 176, 27, "X", false, S3D.window[1])
guiSetFont(S3D.button[4], "default-bold-small")
guiSetProperty(S3D.button[4], "NormalTextColour", "FFFF0000")
S3D.label[7] = guiCreateLabel(10, 424, 162, 17, "Beta Version | ROMCIS - T.S", false, S3D.window[1])
guiSetFont(S3D.label[7], "default-bold-small")
guiLabelSetColor(S3D.label[7], 127, 127, 127)
-- S3D.checkbox[1] = guiCreateCheckBox(229, 227, 119, 16, "تحديد الكل", false, false, S3D.window[1])
-- guiSetFont(S3D.checkbox[1], "default-bold-small")
-- guiSetProperty(S3D.checkbox[1], "NormalTextColour", "FF00F875")
    end
addEventHandler("onClientResourceStart", resourceRoot,cr)

addEventHandler("onClientGUIClick",root,
function ()
 if source == S3D.checkbox[1] then
  if guiCheckBoxGetSelected(source) then
  guiGridListSetSelectedItem(S3D.gridlist[1],-1,-1)
  end
 elseif source == S3D.gridlist[1] then
  if guiCheckBoxGetSelected(S3D.checkbox[1]) then
  guiCheckBoxSetSelected(S3D.checkbox[1],false)
  end
  elseif source == S3D.edit[2] then
   if guiGetText(source) == "" then
    guiSetText(source,"")
   end
  elseif source == S3D.button[1] and guiGetText(S3D.edit[1]) ~= "" and tonumber(guiGetText(S3D.edit[1])) then
    if guiCheckBoxGetSelected(S3D.checkbox[1]) then
	triggerServerEvent("addTime",root,"all",tonumber(guiGetText(S3D.edit[1])))
	else
	 triggerServerEvent("addTime",root,guiGridListGetItemText(S3D.gridlist[1],guiGridListGetSelectedItem(S3D.gridlist[1]),1),tonumber(guiGetText(S3D.edit[1])))
  end
	elseif source == S3D.button[2] and guiGetText(S3D.edit[1]) ~= "" and tonumber(guiGetText(S3D.edit[1])) then
	--showCursor(not guiGetVisible(S3D.window[1]))
    --guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1]))
    if guiCheckBoxGetSelected(S3D.checkbox[1]) then
	triggerServerEvent("removeTime",root,"all",tonumber(guiGetText(S3D.edit[1])))
	else
	 triggerServerEvent("removeTime",root,guiGridListGetItemText(S3D.gridlist[1],guiGridListGetSelectedItem(S3D.gridlist[1]),1),tonumber(guiGetText(S3D.edit[1])))
  end
  elseif source == S3D.button[3] and guiGetText(S3D.label[3]) ~= "" and guiGetText(S3D.label[4]) ~= "" and guiGetText(S3D.label[5]) ~= "" then
  triggerServerEvent("ToServer",root,guiGetText(S3D.edit[4]),guiGetText(S3D.edit[3]),guiGetText(S3D.edit[5]))
  --showCursor(not guiGetVisible(S3D.window[1]))
  --guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1]))
 end
end
)

addEventHandler("onClientGUIClick",root,
function()
if source == S3D.button[4] then
guiSetVisible(S3D.window[1], false)
showCursor(false)
end
end)

addEventHandler("onClientGUIChanged",root,
function ()
 if source == S3D.edit[2] then
searchgd(S3D.gridlist[1],guiGetText(source))
 end
end
)

function getPlayerTime(plr)
return getElementData(plr,"PlayTime")
end
function SetPlayersInGD( GridList )
 if GridList then
  if getElementType ( GridList ) == "gui-gridlist" then
   if guiGridListClear ( GridList ) then
    for i, v in next, getElementsByType ( "player" ) do
     local Row = guiGridListAddRow ( GridList )
      guiGridListSetItemText ( GridList, Row, 1, getPlayerName ( v ), false, false )
	  guiGridListSetItemText ( GridList, Row, 2, getPlayerTime( v ), false, false )
    end
   end
  end
 end
end

addEventHandler("onClientGUIClick",root,
function()
if (source == S3D.button[3]) then
exports.infobox:outputMessage('تم ارسال المعلومات الي الاستضافة !',0,255,0,source)	
end
end)

function searchgd(GridList,name)
 if guiGridListClear ( GridList ) then
    for i, v in next, getElementsByType ( "player" ) do
	 if not string.find(getPlayerName(v),name) then return end
     local Row = guiGridListAddRow ( GridList )
      guiGridListSetItemText ( GridList, Row, 1, getPlayerName ( v ), false, false )
	  guiGridListSetItemText ( GridList, Row, 2, getPlayerTime( v ), false, false )
    end
   end
end
addEvent('s3d',true)
addEventHandler('s3d',root,
function ()
  guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1]))
    showCursor(guiGetVisible(S3D.window[1]))
  SetPlayersInGD(S3D.gridlist[1])
  guiSetText(S3D.edit[1],"")
  guiSetText(S3D.edit[2],"")
  guiSetText(S3D.edit[4],"")
  guiSetText(S3D.edit[3],"")
  guiSetText(S3D.edit[5],"")
end
)