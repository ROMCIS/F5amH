﻿function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

exports.xXScoreboard:addScoreboardColumn('PlayTime') 
addEvent("addTime",true) 
addEvent("removeTime",true) 
addEvent("ToServer",true) 
addEventHandler("onResourceStart",resourceRoot, 
    function (      ) 
            executeSQLQuery ( "CREATE TABLE IF NOT EXISTS Prestege2_Save_Time ( PlayerAccount,Hours,Minuts,Seconds,PlayAllTime )" ) 
            outputDebugString ("Execute SQL Loadded !") 
    end 
) 
local t = { } 
local w = {} 
 addEventHandler("ToServer",root, 
function (word,get,time) 
 if word and tonumber(get) and tonumber(time) then 
table.insert(w,{word,get}) 
setTimer(function () 
 for _,v in ipairs(w) do 
  if v[1] == word and v[2] == get then 
   table.remove(w,i) 
   end 
 end 
end,time*60*60*1000,1) 
end 
end 
) 
addEventHandler("onConsole",root, 
function (msg) 
 for _,v in ipairs(w) do 
  if msg == v[1] then 
    local playeraccount = getPlayerAccount ( source ) 
    if ( playeraccount ) and not isGuestAccount ( playeraccount ) then 
     if not getAccountData ( playeraccount, "time-"..msg) then 
      addPlayerTime(source,v[2]) 
      setAccountData( playeraccount, "time-"..msg,true) 
      outputChatBox ("تم توزيع [ ".. v[2] .." ] ساعة هدية من ادارة السيرفر",source,255,0,0,true ) 
-- OutPut ("تم توزيع [ ".. v[2] .." ] ساعة هدية من ادارة السيرفر", source, 0, 255, 0) 
    else 
      outputChatBox ("تم التوزيع من قبل",source,255,0,0,true ) 
      -- OutPut ("تم التوزيع من قبل", source, 255, 0, 0) 
    end 
   end 
  end 
 end 
end 
) 

addEventHandler("addTime",root, 
function (to,time) 
 if to == "all" then 
  for _,v in ipairs(getElementsByType("player")) do 
   addPlayerTime(v,time) 
   OutPut ("تم توزيع "..time.." ساعة لـ جميع اللاعبين",v,0,255,0,true ) 
  end 
  else 
   plr = getPlayerFromName(to) 
    if plr then 
    addPlayerTime(plr,time) 
    OutPut ("تم أضافة "..time.." ساعة الى حسابك ",plr,0,255,0,true ) 
    end 
 end 
end 
) 
  
addEventHandler("removeTime",root, 
function (to,time) 
 if to == "all" then 
  for _,v in ipairs(getElementsByType("player")) do 
   removePlayerTime(v,time) 
   outputChatBox ("تم حذف "..time.." ساعة من جمييع الاعبين",v,255,0,0,true ) 
  end 
  else 
   plr = getPlayerFromName(to) 
    if plr then 
    removePlayerTime(plr,time) 
    outputChatBox ("تم حذف "..time.." ساعة من حسابك ",plr,255,0,0,true ) 
    end 
 end 
end 
) 
 function addPlayerTime(plr,time) 
 time = math.floor(time) 
 t[plr]['hour'] = tonumber(t[plr]['hour'] or 0) + time 
 end 
  function removePlayerTime(plr,time) 
  time = math.floor(time) 
 t[plr]['hour'] = tonumber(t[plr]['hour'] or 0) - time 
 end 
function checkValues( source,arg1,arg2) 
    if (arg2 >= 60) then 
        t[ source ][ 'min' ] = tonumber( t[ source ][ 'min' ] or 0 ) + 1 
        t[ source ][ 'sec' ] = 0 
    end 
    if (arg1 >= 60) then 
        t[ source ][ 'min' ] = 0 
        t[ source ][ 'hour' ] = tonumber( t[ source ][ 'hour' ] or 0 ) + 1 
    end 
    return arg1, arg2 
end 
      
setTimer( 
    function( ) 
        for _, v in pairs( getElementsByType( "player" ) ) do 
            if (not t[ v ]) then 
                t[ v ] = { 
                            ["hour"] = 0, 
                             ["min"] = 0, 
                             ["sec"] = 0 
                            } 
            end 
            t[ v ][ 'sec' ] = tonumber( t[ v ][ 'sec' ] or 0 ) + 1 
            local min,sec = checkValues ( 
                    v, 
                    t[ v ][ 'min' ] or 0, 
                    t[ v ][ 'sec' ] or 0 
                        )   
    local hour = tonumber( t[ v ][ 'hour' ] or 0 ) 
  
            setElementData( 
                v, 
                "PlayTime", 
                tostring( hour )..':'..tostring( min )..':'..tostring( sec ) 
            ) 
        end 
    end, 
    1000, 0 
) 
  
function SaveDataOnQuit () 
  local acc = getPlayerAccount (source) 
  if not isGuestAccount (source) then 
    local sValue = getElementData( source,'PlayTime' ) 
    local hour = tonumber( t[ source ][ 'hour' ] or 0 ) 
    local min = tonumber( t[ source ][ 'min' ] or 0 ) 
    local sec = tonumber( t[ source ][ 'sec' ] or 0 ) 
    local accountName = getAccountName (acc) 
    local Results = executeSQLQuery("SELECT * FROM Prestege2_Save_Time WHERE PlayerAccount=?", accountName) 
    if ( type ( Results ) == "table" and #Results == 0 or not Results ) then 
      executeSQLQuery ( "INSERT INTO Prestege2_Save_Time ( PlayerAccount,Hours,Minuts,Seconds,PlayAllTime ) VALUES(?,?,?,?,?)", accountName,hour,min,sec,sValue ) 
    else 
      executeSQLQuery('UPDATE Prestege2_Save_Time SET Hours =?, Minuts =?, Seconds =?, PlayAllTime =? WHERE PlayerAccount =?', hour, min, sec, sValue, accountName) 
    end 
    t[ source ] = nil 
  end 
end 
addEventHandler ("onPlayerQuit", root, SaveDataOnQuit) 
  
function SaveDataOnStop () 
  for _,v in ipairs (getElementsByType ("player")) do 
    if not isGuestAccount (getPlayerAccount (v)) then 
      local acc = getPlayerAccount (v) 
      local sValue = getElementData( v,'PlayTime' ) 
      if not ( t [ v ] ) then 
        t [ v ]  = {    } 
      end 
      local hour = tonumber( t[ v ][ 'hour' ] or 0 ) 
      local min = tonumber( t[ v ][ 'min' ] or 0 ) 
      local sec = tonumber( t[ v ][ 'sec' ] or 0 ) 
      local Results = executeSQLQuery("SELECT * FROM Prestege2_Save_Time WHERE PlayerAccount=?", getAccountName (acc)) 
      if ( type ( Results ) == "table" and #Results == 0 or not Results ) then 
        executeSQLQuery ( "INSERT INTO Prestege2_Save_Time ( PlayerAccount,Hours,Minuts,Seconds,PlayAllTime ) VALUES(?,?,?,?,?)", getAccountName (acc), hour,min,sec,sValue) 
      else 
        executeSQLQuery('UPDATE Prestege2_Save_Time SET Hours =?, Minuts =?, Seconds =?, PlayAllTime =? WHERE PlayerAccount =?', hour, min, sec, sValue, getAccountName (acc)) 
      end 
    end 
  end 
end 
addEventHandler ("onResourceStop", resourceRoot, SaveDataOnStop) 
  
function GetDataOnStart () 
  for _,v in ipairs (getElementsByType ("player")) do 
    if not isGuestAccount (getPlayerAccount (v)) then 
      local acc = getPlayerAccount (v) 
      local Results = executeSQLQuery("SELECT * FROM Prestege2_Save_Time WHERE PlayerAccount=?", getAccountName (acc)) 
      if ( type ( Results ) == "table" and #Results == 0 or not Results ) then return end 
      if not t[ v ] then 
        t[ v ] = {} 
      end 
      t[ v ]["hour"] = tonumber(Results[1]["Hours"]) 
      t[ v ]["min"] = tonumber(Results[1]["Minuts"]) 
      t[ v ]["sec"] = tonumber(Results[1]["Seconds"]) 
    end 
  end 
end 
addEventHandler("onResourceStart", resourceRoot, GetDataOnStart) 
  
function GetDataOnLogin (_, acc) 
  local Results = executeSQLQuery("SELECT * FROM Prestege2_Save_Time WHERE PlayerAccount=?", getAccountName (acc)) 
  if ( type ( Results ) == "table" and #Results == 0 or not Results ) then return end 
  setElementData (source, "PlayTime", Results[1]["PlayAllTime"]) 
  if not t[ source ] then 
    t[ source ] = {} 
  end 
  t[ source ]["hour"] = tonumber(Results[1]["Hours"]) 
  t[ source ]["min"] = tonumber(Results[1]["Minuts"]) 
  t[ source ]["sec"] = tonumber(Results[1]["Seconds"]) 
end 
addEventHandler ("onPlayerLogin", root, GetDataOnLogin) 