﻿--[[
EMOTICONS BY 3NAD
--]]
local root = getRootElement()
local rroot = getResourceRootElement()

--addEvent("Mensaje",true)
local sx,sy = guiGetScreenSize()
local chatbox = getChatboxLayout()
local y = chatbox["chat_scale"][2]
local lineas = chatbox["chat_lines"]
local font = "default"
if chatbox["chat_font"] == 1 then
	font = "clear"
elseif chatbox["chat_font"] == 2 then
	font = "default-bold"
elseif chatbox["chat_font"] == 3 then
	font = "arial"
end

addEventHandler("onClientChatMessage",root,function(txt)
	for k,v in ipairs(getElementsByType("gui-staticimage",rroot)) do
		local gx,gy = guiGetPosition(v,true)
		if string.len(txt) > 48 then
			guiSetPosition(v, gx,gy-0.025,true)
		else
			guiSetPosition(v, gx,gy-0.025,true)
		end
		if gy <= 0.01 then
			destroyElement(v)
		end
	end
	txt = string.gsub(txt,"#[%x][%x][%x][%x][%x][%x]","")
	local len = 0
	if string.len(txt) > 48 then
		return
	end
	if string.find(txt,"ض1") then
		local text = string.gsub(txt,"ض1","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q1.png",true)
		setTimer(outputChatBox,50,1,"")
	elseif string.find(txt,"ض2") then
		local text = string.gsub(txt,"ض2","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q2.png",true)
		setTimer(outputChatBox,50,1,"")
	elseif string.find(txt,"ض3") then
		local text = string.gsub(txt,"ض3","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q3.png",true)
	elseif string.find(txt,"ض4") then
		local text = string.gsub(txt,"ض4","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q4.png",true)
	elseif string.find(txt,"ض5") then
		local text = string.gsub(txt,"ض5","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q5.png",true)
	elseif string.find(txt,"ض6") then
		local text = string.gsub(txt,"ض6","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q6.png",true)
	elseif string.find(txt,"ض7") then
		local text = string.gsub(txt,"ض7","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q7.png",true)
	elseif string.find(txt,"ض8") then
		local text = string.gsub(txt,"ض8","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q8.png",true)
elseif string.find(txt,"ض9") then
		local text = string.gsub(txt,"ض9","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q9.png",true)
elseif string.find(txt,"ض0") then
		local text = string.gsub(txt,"ض0","")
		local len = dxGetTextWidth(text,chatbox["chat_scale"][1],font)
		local lfin = convertirRelativo(len)
		--
		local img = guiCreateStaticImage(0.01875+lfin,0.02+(0.025*(lineas-1)),0.02,0.025,"imagenes/q0.png",true)

	end
end)

function convertirRelativo(x)
	local rx = x/sx
	
	return rx
end
--[[
MAX LEN = 469
--]]