function skin()
txd = engineLoadTXD ( "1.txd" )
engineImportTXD ( txd, 266 )
dff = engineLoadDFF ( "1.dff", 0 )
engineReplaceModel ( dff, 266 )
txd_ = engineLoadTXD ( "2.txd" )
engineImportTXD ( txd_, 27 )
dff_ = engineLoadDFF ( "2.dff", 0 )
engineReplaceModel ( dff_, 27 )
end
setTimer(skin,3000,1)


