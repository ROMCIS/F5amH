local screenWidth, screenHeight = guiGetScreenSize()
ROMCIS = {
    label = {},
    staticimage = {},
    window = {},
}

ROMCIS.window[1] = guiCreateWindow(screenWidth-445, screenHeight/2-313/2, 445, 313, "=[شخصيتك المفضلة للسباحة]=", false)
guiWindowSetSizable(ROMCIS.window[1], false)
guiSetAlpha(ROMCIS.window[1], 1.00)
guiSetProperty(ROMCIS.window[1], "CaptionColour", "FF15E924")
guiSetVisible(ROMCIS.window[1],false)
ROMCIS.staticimage[1] = guiCreateStaticImage(48, 32, 141, 238, "18.jpg", false, ROMCIS.window[1])
ROMCIS.staticimage[2] = guiCreateStaticImage(262, 32, 141, 238, "45.jpg", false, ROMCIS.window[1])
ROMCIS.label[1] = guiCreateLabel(106, 273, 238, 30, "    F5aMh-Server    ", false, ROMCIS.window[1])
guiSetFont(ROMCIS.label[1], "sa-header")
guiLabelSetColor(ROMCIS.label[1], 246, 125, 6)
guiLabelSetHorizontalAlign(ROMCIS.label[1], "center", false)
guiLabelSetVerticalAlign(ROMCIS.label[1], "center")
guiSetAlpha(ROMCIS.staticimage[1],0.5)
guiSetAlpha(ROMCIS.staticimage[2],0.5)

addEventHandler("onClientMouseEnter",root,
	function()
		if ( source == ROMCIS.staticimage[1] or source == ROMCIS.staticimage[2] ) then
			playSoundFrontEnd ( 40 )
			guiSetAlpha(source,1)
		end
	end
)

addEventHandler("onClientMouseLeave",root,
	function()
		if ( source == ROMCIS.staticimage[1] or source == ROMCIS.staticimage[2] ) then
			guiSetAlpha(source,0.5)
		end
	end 
)

function onGuiClick (button, state, absoluteX, absoluteY)
	if (source == ROMCIS.staticimage[1]) then 
		triggerServerEvent ("setSkin_1", getLocalPlayer()) 
		guiSetVisible(ROMCIS.window[1], false)
		showCursor(false)
	elseif (source == ROMCIS.staticimage[2]) then
		triggerServerEvent ("setSkin_2", getLocalPlayer()) 
		guiSetVisible(ROMCIS.window[1], false)
		showCursor(false)	
	end
end
addEventHandler ("onClientGUIClick", getRootElement(), onGuiClick)


Mark = {
{2967.3305664063,112.80503082275,19.529928207397},
}

for k,v in ipairs (Mark) do
z = v[3] -1
Marker = createMarker ( v[1], v[2], z, "cylinder", 2.5,  0, 255, 255, 255 )
addEventHandler('onClientMarkerHit', Marker,
    function ( hitPlayer )
        if ( hitPlayer == localPlayer ) then
            guiSetVisible (ROMCIS.window[1], true )
            showCursor( true )
        end
    end
)
end