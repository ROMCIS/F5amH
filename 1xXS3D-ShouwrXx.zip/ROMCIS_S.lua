addEvent( "setSkin_1", true )
function setSkin_1 ()
	setPedSkin ( source, 18 ) 
	OutPut('! تم وضع الشخصية بنجاح', source, 240,255,0, false)
end
addEventHandler ( "setSkin_1", getRootElement(), setSkin_1 ) 
----

addEvent( "setSkin_2", true ) 
function setSkin_2 ()
	setPedSkin ( source, 45 ) 
	OutPut('! تم وضع الشخصية بنجاح', source, 240,255,0, false)
end
addEventHandler ( "setSkin_2", getRootElement(), setSkin_2 ) 

function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end