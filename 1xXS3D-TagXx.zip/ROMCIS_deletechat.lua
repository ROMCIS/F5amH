﻿addCommandHandler("77",
function (player)
if hasObjectPermissionTo(player,"command.mute",true) then
if isTimer(Dev) then return outputChatBox("يمنع تكرار",player,255, 255, 0) ; end
for i=1,30 do
outputChatBox(" ")
end
outputChatBox("#cccccc[ T.S Chat ] #00ffffThe Player ( " .. string.gsub(getPlayerName(player), "#%x%x%x%x%x%x", "") .. " ) #ccccccCleared Chat !",root,255,0,0,true)
Dev = setTimer(function () end,10000,1) 
end
end )