﻿local db = dbConnect('sqlite',':1xXS3D-EditagXx/TOUNSI_Account.db')

local lastmsgs={}

Devfast = {
["س1"] = "السلام عليكم ورحمة الله ",
["س2"] = "وعليكم السلآم ورحمة آلله وبركآتة",
["س3"] = "سبحآن الله العظيم",
["س4"] = "سبحآن الله وبحمدهـ ",
["brb"] = "BrB ~ برب شوي ورآجع",
["ه1"] = "°•.¸.•°.ههههههههههههههههههههههههههههههههههههه.°•.¸.•° "
}

DevWord = 
{ "كلب", "حيوان","كس","طيز","زب","سيرفر","وزارة","الوزارة","شيعي","سني","سعد","نيقا","قوست","تيربو","سكس","انيكك","نيك","ازغبك","روت","هستره","مسترام","مسترآم","قحبه","قحبة",
}

function convertMilliseconds( i ) 
if ( i ) then 
sec = math.fmod( math.floor( i / 1000 ), 60 ) 
return string.format( '%2d', sec ) 
end 
end 
  
for i,v in ipairs(getElementsByType("player")) do 
setElementData(v, "Dev_TOUNSI", false)
end

addEvent('Dev_setmessagecolor',true)
addEventHandler('Dev_setmessagecolor',root,function(color)
local acc=getPlayerAccount(source)
local name = getPlayerName(source)
if not isGuestAccount(acc) then
setAccountData(acc,'colortag',color)	
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',getAccountName(acc)),-1)
if #sel~=0 then
dbExec(db,'UPDATE YeahNice SET color=? WHERE acc=?',color,getAccountName(acc))
end
outputChatBox("" .. name .. ' : '..color.."اللون الخاص بك",source,255,255,255,true)
end
end)

addEvent('addTag',true)
addEventHandler('addTag',root,function(tag)
local acc=getPlayerAccount(source)
if not isGuestAccount(acc) then	
setAccountData(acc,'tagname',tag)	
outputChatBox("تم زخرفة الأسم بنجاح! تهانينا !",source,0,255,0,true)
end 
end)
  
addEvent('removeTag',true)
addEventHandler('removeTag',root,function()
local acc=getPlayerAccount(source)
if not isGuestAccount(acc) then
setAccountData(acc,'tagname',false)
outputChatBox("تمت ازالة الزخرفة بنجاح!",source,150,0,255,true)
end
end)

function chatbox(text, msgtype)
if lastmsgs[source] and lastmsgs[source]==text then cancelEvent() outputChatBox('!يرجى عدم تكرار الرسالة',source,255,0,0,true) return end
lastmsgs[source]=text
local acc=getPlayerAccount(source)
local account = getAccountName(acc)
local name = getPlayerName(source)
cancelEvent()
local ColorTOUNSI = getAccountData ( acc, "colortag" ) or "#FFFFFF"
local player = source
if Devfast[(text)]  then text=Devfast[(text)] end
local thetext=text
local account = getAccountName(getPlayerAccount(source))
local name = getPlayerName(source)
cancelEvent()
local ColorTOUNSI = getAccountData ( getPlayerAccount(source), "colortag" ) or "#FFFFFF"
local player = source
if ( getElementData(source, "Dev_TOUNSI") == false ) then
setElementData(source, "Dev_TOUNSI", true)
Timer = setTimer(function(player)
if isElement(player) then
setElementData(player, "Dev_TOUNSI", false )
end
end, 5000,1, source)
local new = ""
local iter = 0
for word in text:gmatch("%S+") do
iter = iter + 1
for i,swr in ipairs(DevWord) do
local src = word:lower():gsub("%s","")
local src = src:gsub("#%x%x%x%x%x%x","")
local src = src:gsub("%c","")
local src = src:gsub("%p","")
local pat = swr:lower():gsub("%s","")
if src:find(pat) then
local replaceString = ""
for x=1,word:gsub("#%x%x%x%x%x%x",""):len() do
replaceString = replaceString.."#FF0000*"
end
word = word:gsub(word,replaceString)
end
end
if iter == 1 and word:len() > 2 then
word = word:gsub("%a",string.upper,1)
end
new = new..word.." "
end
if new ~= "" then text = new end
outputConsole("" .. getPlayerName(source) .. ": " .. new)
local data=getAccountData(acc,'tagname')
if not isGuestAccount(acc) and data then
name=data
end 
if not isGuestAccount(acc) then
local sel=dbPoll(dbQuery(db,'SELECT * FROM YeahNice WHERE acc=?',getAccountName(acc)),-1)
if #sel~=0 and sel[1].isactive~='false' and sel[1].isactive2~='false' then
outputChatBox(sel[1].tag.. sel[1].isactive .. ' : '..sel[1].color.. text, root, 255, 255, 255, true )
return
end
end
if isObjectInACLGroup("user." .. account, aclGetGroup("Admin-F")) then outputChatBox("#ffffffx[#000000 ادمن مخالف #ffffff]x :" .. name .. ': '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("MiniSteR-Excellency")) then outputChatBox("#FF0000✼ #91BCE7⌠ » #0099FFMinister #FFFFFFExcell#FF0000ency#91BCE7 « ⌡ #FF0000✼ :#ffffff " .. name .. ' : #0099FF'..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("G-Lourdes")) then outputChatBox("#DC143C✲#2C2B2A⌠›#ffffff Lourdes-#64FFEDF5amh #2C2B2A‹⌡#DC143C✲ :#418981 " .. name .. ' #ffffff: '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Royal-FaMily")) then outputChatBox("#DF0054✦⌠#FF8B6A - #470031RoYal #F1C6B1FaMiLy #FF8B6A-#DF0054 ⌡✦ : #FF8B6A" .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Eskry-Mmlka")) then outputChatBox("#fcf8f3✯⌠ ⋩ #ffd3b6الســــيــرفر #698474 عســــكري #fcf8f3 ⋨ ⌡✯: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("POLICE-MmLKa")) then outputChatBox("#ff0000元 #ffffff› #273746De#fffffffend#273746eƦ #ffffff‹ #ff0000ϟ #273746: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("D-aGents")) then outputChatBox("#7EA5A4✻#fafafa⌠ - #E5C4A3AGn#FAFAFATS Of Mm#7EA5A4Lka #fafafd- ⌡#7EA5A4✻#FAFAFA: #E5C4A3 " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("MiniSter-Exellency")) then outputChatBox("#FF0000✼ #91BCE7⌠ » #0099FFMinister #FFFFFFExcell#FF0000ency#91BCE7 « ⌡ #FF0000✼: #ffffff " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("G-Lourdes")) then outputChatBox("#DC143C✲#2C2B2A⌠›#ffffff Lourdes-#64FFEDMmlKa #2C2B2A‹⌡#DC143C✲ :#418981 " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Luxurious")) then outputChatBox("#313030三#F4F4F4⌠» #8a8a8aLux#F4F4F4uri#EE7A47ous#F4F4F4 «⌡#313030 三:#C9C9C9 " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Group-Swaga")) then outputChatBox("#EFE3DF✱ #FCCF96Group -#EFE3DFِِASo#8B2538ED#EFE3DF ✱ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Console")) then outputChatBox("" .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Group-FaMiLy")) then outputChatBox("#F7417C✸#CDE5D5 ╔#FAFAFA╣ - #F7417CGroup #FAFAFAOF #CDE5D5FaMiLy #FAFAFA- ╠#CDE5D5╗ #F7417C✸:#CDE5D5 " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Manager")) then outputChatBox("#66FFFF✱⌠» #663300Man#FFFFFFager  #66FFFF«⌡✱ #FFFFFF" .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("ManagerAcl")) then outputChatBox("#000000✱⌠» #66FFFFManager #FFFFFF- #CC6633ACL  #000000«⌡✱ #CC6633" .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AmbassadorF5amh")) then outputChatBox("#838383✼#d4b5b0 ⌠ #d9adad»#838383 Amba#d9adadssador #d4b5b0Of #838383F5amh #d9adad«#d4b5b0 ⌡#838383 ✼ :#838383 " .. name .. ' : #d4b5b0'..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminPlus")) then outputChatBox("#131817✳⌠#071933Admin#04E762 Plus#131817⌡✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("BestAdmin")) then outputChatBox("#131817✳⌠#316414Best #FF4800Admin#131817⌡✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Bigadmin")) then outputChatBox("#131817✳⌠#3ED7FFBig#F2159A Admin#131817⌡✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminMonitor")) then outputChatBox("#131817✳⌠#FFC21CAdmin#C81D25 Monitor#131817⌡✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminOfficial")) then outputChatBox("#131817✳⌠#BFDE7EAdmin #EA7446Offcial #131817⌡✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("ADMINPOWER")) then outputChatBox("#99ccff✳#00304e⌠#FFFFFF - #51f0e8ADMIN#e0de6dPOWER #FFFFFF- #00304e⌡#99ccff✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("ADMINM7TRF")) then outputChatBox("#043227✳#f4a32e⌠ #ffcc88- #097168ADMIN#fa482eM7TRF #ffcc88- #f4a32e⌡#043227✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("SPECIALPRINCE")) then outputChatBox("#fb8072✳#112244⌠#bebada - #8dd3c7SPECIAL#ffffb3PRINCE #bebada-#112244 ⌡#fb8072✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("ADMINSENIOR")) then outputChatBox("#ffdd44✳#000027⌠#FFFFFF - #66ffffSENIOR#ff0033ADMIN #FFFFFF- #000027⌡#ffdd44✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminGeneral")) then outputChatBox("#454545✳#d1ffff⌠ #d4ef00- #f5f5f5ADMINN #d4ef00GENERAL #f5f5f5- #d1ffff⌡#454545✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("PRINCEADMIN")) then outputChatBox("#601600✳#fff7b6⌠ #94583c- #7a7d58PRINCE#dd9954ADMIN #94583c- #fff7b6⌡#601600✳ #FFFFFF: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("KINGADMIN")) then outputChatBox("#51D1E6✳#FAFAFA⌠ - #FFD194KINGADMIN#FAFAFA - ⌡#51D1E6✳ " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Professional")) then outputChatBox("#FFFF99✳⌠ #FF9900ProFes#FFFFFFsional #FFFF99⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Vip-Admin")) then outputChatBox("#CCFFFF✳⌠ #CC99FFVip#FFFFFF - #FFCCCCAdmin #CCFFFF⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Leader")) then outputChatBox("#FFFF99✳⌠ #FF9900Lea#FFFFFFder #FFFF99⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminTop")) then outputChatBox("#FFFF66✳⌠ #99FFFFAdmin #FFFFFF- #FF9900Top#FFFF66 ⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("VoteModerator")) then outputChatBox("#CCFFFF✳⌠ #FF9900VoteMo#FFFFFFderator #CCFFFF⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("VotePolice")) then outputChatBox("#444111✳#ffffff⌠ #ff0000Vote#fce09fPolice #ffffff⌡#444111✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Moderator2")) then outputChatBox("#2EFEF7✽#434343⌠-#B40404 Mod#fffffferator2 #434343-⌡#2EFEF7✽ : " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("SuperModerator2")) then outputChatBox("#E72E96亗#434343⌠ #FFFFFFSuper#E72E96Moderator2 #434343⌡#E72E96亗 #ffffff: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("AdminBoss")) then outputChatBox("#131817✳⌠#D2D891Admin #FFFFFF- #44B58DBoss#131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("EmperorOfServer")) then outputChatBox("#131817✳⌠#FF4800Emperor#FFFFFF -#004391  Server#131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("KingOfServer")) then outputChatBox("#131817✳⌠ #04E762King#FFFFFF Of#9EE3FF Server #131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Prince")) then outputChatBox("#131817✳⌠ #07177FPrince #FFFFFFof #9EE3FFServer#131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("DE")) then outputChatBox("#131817✳⌠#FF4E00Speical#00A8E8 Admin#131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Professional.Admin")) then outputChatBox("#ff0033彡 #990033Professional Admin #ff0033彡:#ff6666 " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Head.Admin")) then outputChatBox("#131817✳⌠#0DBED6Head#000000 -#FFFFFF Admin#131817⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("ADMIN")) then outputChatBox("#ff0000✳⌠ #fafafaAdmin #ff0000⌡✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("SuperModerator")) then outputChatBox("#fce09f亗#434343⌠ #FFFFFFSuper#fce09fModerator #434343⌡#fce09f亗 #ffffff: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Moderator")) then outputChatBox("#18B193✳#FAFAFA⌠ Mod#F7F7F7erator #FAFAFA⌡#18B193✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("police")) then outputChatBox("#434343✳#ffffff⌠ #2EFEF7Police #ffffff⌡#434343✳ #ffffff: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("V.I.P")) then outputChatBox("#ffffff✽#434343⌠- #ffc00fV.I.P #434343-⌡#FFFFFF✽ : #ffc00f " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Time")) then outputChatBox("#fff000✳#fafafa⌠#000000 - #fafafaKing OF Time #000000- #fafafa⌡#fff000✳: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Everyone")) then outputChatBox("#ffffff✱⌠#ffff00 مواطن #ffffff⌡✱: " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("اسم الرتبة")) then outputChatBox("تاج الرتبة " .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true )
elseif isObjectInACLGroup("user." .. account, aclGetGroup("Everyone")) then outputChatBox("" .. name .. ' : '..ColorTOUNSI..''.. text, root, 255, 255, 255, true ) end
else
local Get3 = convertMilliseconds( getTimerDetails( Timer ) )
-- outputChatBox("wait a little bit | انتظر قليلا .",source,255,0,0,true)
outputChatBox("("..Get3.." ) : فضلا أنتظر 5 ثواني .. عدد الثواني المتبقية !",source,255,0,0,true)
end
function tounsi()
end
addEventHandler("onPlayerJoin", getRootElement(), tounsi)
end
addEventHandler("onPlayerChat", root, chatbox)