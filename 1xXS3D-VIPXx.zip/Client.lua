CardTypesTable = { 
	{'باي بال '},
	{'سوا | STC'},
};

Cplayer = getLocalPlayer(  )

local screenW, screenH = guiGetScreenSize()

GUIEditor = {
    checkbox = {},
    label = {},
    edit = {},
    button = {},
    window = {},
    gridlist = {},
    combobox = {}
}

GUIEditor.window[1] = guiCreateWindow(519, 179, 409, 553, "لوحةة عضــويةة [ VIP  ] الخاصه", false)
guiWindowSetSizable(GUIEditor.window[1], false)
guiSetAlpha(GUIEditor.window[1], 1.00)
guiSetVisible(GUIEditor.window[1], false)
GUIEditor.label[1] = guiCreateLabel(110, 32, 181, 53, "V . I . P", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[1], "sa-header")
guiLabelSetColor(GUIEditor.label[1], 255, 124, 27)
guiLabelSetHorizontalAlign(GUIEditor.label[7], "center", false) 
-- GUIEditor.label[16] = guiCreateLabel(110, 32, 181, 90, "*", false, GUIEditor.window[1]) 
-- guiSetFont(GUIEditor.label[16], "sa-gothic")   
GUIEditor.label[2] = guiCreateLabel(88, 96, 220, 17, "اهلا وسهلا بكم في لوحة العضوية الخاصه", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[2], "default-bold-small")
guiLabelSetColor(GUIEditor.label[2], 1, 234, 209)
GUIEditor.label[3] = guiCreateLabel(88, 123, 221, 17, "تستطيع من خلال هذه الخاصيه ( العضويه )", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[3], "default-bold-small")
guiLabelSetColor(GUIEditor.label[3], 1, 234, 209)
GUIEditor.label[4] = guiCreateLabel(143, 144, 104, 20, "ان يتاح لك ما يلي", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[4], "default-bold-small")
guiLabelSetColor(GUIEditor.label[4], 204, 176, 176)
GUIEditor.label[5] = guiCreateLabel(98, 164, 205, 15, "ستكون لك شخصيتين مميزتين ( Skin )", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[5], "default-bold-small")
guiLabelSetColor(GUIEditor.label[5], 219, 0, 206)
GUIEditor.label[6] = guiCreateLabel(81, 189, 232, 17, "سيتم وضع تاج فوق رأسك يراه الجميع مثل :-", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[6], "default-bold-small")
guiLabelSetColor(GUIEditor.label[6], 219, 0, 206)
GUIEditor.label[7] = guiCreateLabel(53, 210, 293, 16, "( ملك الساحةة - ملك الديربي - ملف الليفل - الميلياردير )", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[7], "default-bold-small")
guiLabelSetColor(GUIEditor.label[7], 219, 216, 0)
GUIEditor.label[8] = guiCreateLabel(71, 232, 255, 16, "ستتوفر لك ادوات معينة ليست موجوده مع الجميع", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[8], "default-bold-small")
guiLabelSetColor(GUIEditor.label[8], 219, 0, 206)
guiLabelSetHorizontalAlign(GUIEditor.label[8], "center", false)
GUIEditor.label[9] = guiCreateLabel(0, 248, 405, 15, "꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊‑꞊", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[9], "default-bold-small")
guiLabelSetColor(GUIEditor.label[9], 14, 204, 90)
GUIEditor.label[10] = guiCreateLabel(141, 263, 103, 15, "- طريقــة الشــراء -", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[10], "default-bold-small")
guiLabelSetColor(GUIEditor.label[10], 35, 218, 0)
GUIEditor.label[11] = guiCreateLabel(223, 268, 15, 67, "\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟\n⎟", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[11], "default-bold-small")
guiLabelSetColor(GUIEditor.label[11], 219, 0, 206)
GUIEditor.label[12] = guiCreateLabel(-2, 325, 237, 15, "―――――――――――――――――――――――", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[12], "default-bold-small")
guiLabelSetColor(GUIEditor.label[12], 219, 0, 206)
GUIEditor.checkbox[2] = guiCreateCheckBox(10, 279, 198, 15, "لمدة شهر | 40 ريال ( بطاقة سوا )", false, false, GUIEditor.window[1])
guiSetFont(GUIEditor.checkbox[2], "default-bold-small")
guiLabelSetHorizontalAlign(GUIEditor.label[12], "center", false)
guiLabelSetVerticalAlign(GUIEditor.label[12], "center")
GUIEditor.checkbox[3] = guiCreateCheckBox(10, 304, 126, 17, "لمدة شهر | 10 بيبال", false, false, GUIEditor.window[1])
guiSetFont(GUIEditor.checkbox[3], "default-bold-small")
GUIEditor.button[1] = guiCreateButton(268, 276, 116, 59, "صورة للخاصية", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[1], "default-bold-small")
guiSetProperty(GUIEditor.button[1], "NormalTextColour", "FFF9F000")
GUIEditor.label[13] = guiCreateLabel(47, 345, 310, 15, "- كل خانه بطاقه واحده اذا كان معك اكثر من بطاقتين وفوق -", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[13], "default-bold-small")
guiLabelSetColor(GUIEditor.label[13], 85, 224, 24)
GUIEditor.gridlist[1] = guiCreateGridList(25, 366, 354, 86, false, GUIEditor.window[1])

GUIEditor.edit[1] = guiCreateEdit(6, 5, 115, 33, "", false, GUIEditor.gridlist[1])
GUIEditor.edit[2] = guiCreateEdit(6, 48, 115, 33, "", false, GUIEditor.gridlist[1])
GUIEditor.edit[3] = guiCreateEdit(125, 5, 115, 33, "", false, GUIEditor.gridlist[1])
GUIEditor.edit[4] = guiCreateEdit(125, 48, 115, 33, "", false, GUIEditor.gridlist[1])
GUIEditor.edit[5] = guiCreateEdit(246, 28, 102, 30, "", false, GUIEditor.gridlist[1]) 
GUIEditor.button[2] = guiCreateButton(210, 459, 100, 25, "إرســـــال", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[2], "default-bold-small")
guiSetProperty(GUIEditor.button[2], "NormalTextColour", "FF34F700")
GUIEditor.label[14] = guiCreateLabel(185, 459, 15, 15, " ✖ ", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[14], "default-bold-small")
guiLabelSetColor(GUIEditor.label[14], 204, 176, 176)
GUIEditor.button[4] = guiCreateButton(80, 459, 100, 25, "إفراغ الخانات", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[4], "default-bold-small")
guiSetProperty(GUIEditor.button[4], "NormalTextColour", "FFE10000")
GUIEditor.button[3] = guiCreateButton(156, 490, 89, 31, "إغلاق | Close", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[3], "default-bold-small")
guiSetProperty(GUIEditor.button[3], "NormalTextColour", "FF6916E6") 
GUIEditor.label[15] = guiCreateLabel(35, 531, 331, 16, "في حال الدفع يرجى الانتضار 24 ساعه | | حرف ج لفتح القائمه", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[15], "default-bold-small")
guiLabelSetColor(GUIEditor.label[15], 243, 245, 0)  
----------
RentManager = guiCreateWindow(466, 182, 571, 524, ".:[ System - Welcome ]:.", false)
guiWindowSetSizable(RentManager, false)
guiSetAlpha(RentManager, 1.00)
guiSetVisible(RentManager, false)
BoughtGridList_RentManager = guiCreateGridList(11, 29, 550, 275, false, RentManager)
guiGridListAddColumn(BoughtGridList_RentManager, "اللاعب", 0.3)
guiGridListAddColumn(BoughtGridList_RentManager, "نوع الإشتراك", 0.8)
guiGridListAddColumn(BoughtGridList_RentManager, "تاريخ الشراء", 0.4)
ShowCart = guiCreateLabel(470, 438, 81, 15, "عرض البطائق", false, RentManager)
guiSetFont(ShowCart, "default-bold-small")
ShowNum_RentManager = guiCreateButton(431, 474, 126, 36, "عرض بطائق الشحن", false, RentManager)
guiSetFont(ShowNum_RentManager, "default-bold-small")
guiSetProperty(ShowNum_RentManager, "NormalTextColour", "FF18FF00")
CobySir = guiCreateLabel(431, 319, 119, 15, "نسخ سريال المشتري", false, RentManager)
guiSetFont(CobySir, "default-bold-small")
CopySer_RentManager = guiCreateButton(431, 351, 126, 36, "نسخ السيريال", false, RentManager)
guiSetFont(CopySer_RentManager, "default-bold-small")
guiSetProperty(CopySer_RentManager, "NormalTextColour", "FF18FF00")
DelPla = guiCreateLabel(18, 319, 123, 15, "حذف اللاعب من القائمة", false, RentManager)
guiSetFont(DelPla, "default-bold-small")
DelSel_RentManager = guiCreateButton(11, 351, 126, 36, "حذف اللاعب المحدد", false, RentManager)
guiSetFont(DelSel_RentManager, "default-bold-small")
guiSetProperty(DelSel_RentManager, "NormalTextColour", "FFFF0000")  
lClose = guiCreateLabel(21, 442, 81, 15, "أغلاق اللوحه", false, RentManager)
guiSetFont(lClose, "default-bold-small")  
CloseButton_RentManager = guiCreateButton(11, 474, 126, 36, "اغلاق", false, RentManager)
guiSetFont(CloseButton_RentManager, "default-bold-small")
guiSetProperty(CloseButton_RentManager, "NormalTextColour", "FFFF0000")
Owner = guiCreateLabel(237, 495, 84, 15, "By : Mr.RoMcIS", false, RentManager)
guiSetFont(Owner, "default-bold-small")
guiLabelSetColor(Owner, 254, 0, 0)  
----------

CardsView = guiCreateWindow((screenW - 450) / 2, (screenH - 313) / 2, 450, 313, ".:[ System - Cards ]:.", false)
guiWindowSetSizable(CardsView, false)
guiSetAlpha(CardsView, 1.00)
guiSetVisible(CardsView, false)
Note_CardsView = guiCreateLabel(261, 32, 179, 22, "# بطاقات الدفع الخاصة باللاعب :-", false, CardsView)
guiSetFont(Note_CardsView, "default-bold-small")
guiLabelSetColor(Note_CardsView, 250, 230, 0)
guiLabelSetHorizontalAlign(Note_CardsView, "right", false)
guiLabelSetVerticalAlign(Note_CardsView, "center")
pName_CardsView = guiCreateLabel(10, 32, 251, 22, "None", false, CardsView)
guiSetFont(pName_CardsView, "default-bold-small")
guiLabelSetHorizontalAlign(pName_CardsView, "right", false)
guiLabelSetVerticalAlign(pName_CardsView, "center")
List_CardsView = guiCreateGridList(10, 96, 430, 176, false, CardsView)
guiGridListAddColumn(List_CardsView, "البطاقات", 0.9)
X_CardsView = guiCreateButton(20, 282, 410, 21, "X", false, CardsView)
guiSetFont(X_CardsView, "default-bold-small")
guiSetProperty(X_CardsView, "NormalTextColour", "FFED0000")
----------



setTimer(function()
guiSetVisible(Owner,not guiGetVisible(Owner))
end,500,0)

setTimer(function()
guiSetVisible(lClose,not guiGetVisible(lClose))
end,500,0)

setTimer(function()
guiSetVisible(DelPla,not guiGetVisible(DelPla))
end,500,0)

setTimer(function()
guiSetVisible(CobySir,not guiGetVisible(CobySir))
end,500,0)

setTimer(function()
guiSetVisible(ShowCart,not guiGetVisible(ShowCart))
end,500,0)

function s3dEdit(  )
	if ( source == GUIEditor.button[4] ) then
guiSetText( GUIEditor.edit[1], '' )
guiSetText( GUIEditor.edit[2], '' )
guiSetText( GUIEditor.edit[3], '' )
guiSetText( GUIEditor.edit[4], '' )
guiSetText( GUIEditor.edit[5], '' )
end
end
addEventHandler( 'onClientGUIClick', root, s3dEdit )

function clickElements(  )
	if ( source == GUIEditor.button[3] ) then
		guiSetVisible( GUIEditor.window[1], false )
		showCursor( false )
		guiSetInputEnabled( false )
	elseif ( source == GUIEditor.checkbox[1] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[4], false )
	elseif ( source == GUIEditor.checkbox[2] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[4], false )
	elseif ( source == GUIEditor.checkbox[3] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[4], false )
	elseif ( source == GUIEditor.checkbox[4] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
	elseif ( source == GUIEditor.button[2] ) then
		local CB1 = guiCheckBoxGetSelected( GUIEditor.checkbox[1] )
		local CB2 = guiCheckBoxGetSelected( GUIEditor.checkbox[2] )
		local CB3 = guiCheckBoxGetSelected( GUIEditor.checkbox[3] )
		local CB4 = guiCheckBoxGetSelected( GUIEditor.checkbox[4] )
			if ( CB1 == false and CB2 == false and CB3 == false and CB4 == false ) then
			exports["infobox"]:outputMessage ("يجب عليك اختيار مدة الاشتراك",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local Sel = guiComboBoxGetSelected( GUIEditor.combobox[1] )
			if ( Sel == -1 ) then
			exports["infobox"]:outputMessage ("يجب عليك ادخال رقم البطاقة",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local CN1 = guiGetText( GUIEditor.edit[1] )
		local CN2 = guiGetText( GUIEditor.edit[2] )
		local CN3 = guiGetText( GUIEditor.edit[3] )
		local CN4 = guiGetText( GUIEditor.edit[4] )
		local CN5 = guiGetText( GUIEditor.edit[5] )
		local CN6 = guiGetText( GUIEditor.edit[6] )
			if ( not tonumber( CN1 ) and not tonumber( CN2 ) and not tonumber( CN3 ) and not tonumber( CN4 ) and not tonumber( CN5 ) and not tonumber( CN6 ) ) then
			exports["infobox"]:outputMessage ("يجب أن يتكون رقم بطاقة الشحن من أرقام فقط!",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		if ( CB1 == true ) then Subscription = guiGetText( SpecialSellEdit_RentManager ) else if ( CB2 == true ) then Subscription = guiGetText( GUIEditor.checkbox[2] ) else if ( CB3 == true ) then Subscription = guiGetText( GUIEditor.checkbox[3] ) else if ( CB4 == true ) then Subscription = guiGetText( GUIEditor.checkbox[4] ) end end end end
		triggerServerEvent( 'RentSystem;buySubscription', Cplayer, Subscription, guiComboBoxGetItemText( GUIEditor.combobox[1], guiComboBoxGetSelected( GUIEditor.combobox[1] ) ), CN1, CN2, CN3, CN4, CN5, CN6 )
	elseif ( source == CloseButton_RentManager ) then
		guiSetVisible( GUIEditor.window[1], true )
		guiSetVisible( RentManager, false )
	elseif ( source == ShowNum_RentManager ) then
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		triggerServerEvent( 'RentSystem;getCards', Cplayer, guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 ), guiGridListGetItemData( BoughtGridList_RentManager, Sel, 2 ) )
	elseif ( source == X_CardsView ) then
		guiSetVisible( RentManager, true )
		guiSetVisible( CardsView, false )
	elseif ( source == SellStateButton_RentManager ) then
		if ( guiGetText( SellStateButton_RentManager ) == 'تغيير الحالة : مقفول الآن !' ) then
		state_Sell = 'close'
			else if ( guiGetText( SellStateButton_RentManager ) == 'تغيير الحالة : مفتوح الآن !' ) then
		state_Sell = 'open'
			end
		end
		triggerServerEvent( 'RentSystem;changeSellState', Cplayer, state_Sell )
	elseif ( source == SpecialStateButton_RentManager ) then
		if ( guiGetText( SpecialStateButton_RentManager ) == 'تغيير حالة العرض : مفتوح' ) then
		specialValue = guiGetText( SpecialSellEdit_RentManager )
			if ( specialValue == '' or specialValue == '( لا توجد عروضات خاصة في الوقت الحالي ) .' ) then
			outputChatBox( '#FF0000* #FFFF00Rent System - Subscription #FF0000: #FFFFFF عذرا قم بكتابة العرض بشكل صحيح !', 255, 255, 255, true ) return end
		specialState = 'open'
			else if ( guiGetText( SpecialStateButton_RentManager ) == 'تغيير حالة العرض : مقفل' ) then
		specialState = 'close' 
			end
		end
		triggerServerEvent( 'RentSystem;changeSpecialState', Cplayer, specialState, specialValue )
	elseif ( source == DelSel_RentManager ) then 
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		triggerServerEvent( 'RentSystem;removeSel', Cplayer, guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 ), guiGridListGetItemData( BoughtGridList_RentManager, Sel, 2 ) )
	elseif ( source == CopySer_RentManager ) then 
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local Serial = guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 )
		setClipboard( Serial )
		exports["infobox"]:outputMessage ("تم نسخ السريال بنجاح",math.random(0,255),math.random(0,255),math.random(0,155))
		guiSetEnabled( CopySer_RentManager, false )
		setTimer( guiSetEnabled, 3000, 1, CopySer_RentManager, true )
	elseif ( source == X_ViewSystem ) then
		guiSetVisible( GUIEditor.window[1], true )
		guiSetVisible( ViewSystem, false )
		guiSetAlpha( Photo_ViewSystem, 0.50 )
end
end
addEventHandler( 'onClientGUIClick', root, clickElements )

addEventHandler( 'onClientMouseEnter', root,
function( )
	if ( source == Photo_ViewSystem ) then
		guiSetAlpha( Photo_ViewSystem, 1 )
	end
end )

addEventHandler( 'onClientMouseLeave', root,
function( )
	if ( source == Photo_ViewSystem ) then
		guiSetAlpha( Photo_ViewSystem, 0.50 )
	end
end )

addEvent( 'RentSystem;C;refreshList', true )
addEventHandler( 'RentSystem;C;refreshList', root,
function( Table )
	guiGridListClear( BoughtGridList_RentManager )
		for i, _ in ipairs( Table ) do 
		local item = guiGridListAddRow( BoughtGridList_RentManager )
			local Name = guiGridListSetItemText( BoughtGridList_RentManager, item, 1, Table[i].pName:gsub( '#%x%x%x%x%x%x', '' ), false, false )
				local subType = guiGridListSetItemText( BoughtGridList_RentManager, item, 2, Table[i].pSub, false, false )
					local buyDate = guiGridListSetItemText( BoughtGridList_RentManager, item, 3, Table[i].sysDate, false, false )
				local pSerial = guiGridListSetItemData( BoughtGridList_RentManager, item, 3, Table[i].pSerial )
			local value = guiGridListSetItemData( BoughtGridList_RentManager, item, 2, Table[i].sysValue )
		if ( Table[i].showValue == 'false' ) then
			guiGridListSetItemColor( BoughtGridList_RentManager, item, 1, 255, 0, 0 )
			else
		guiGridListSetItemColor( BoughtGridList_RentManager, item, 1, 0, 255, 0 )
	end
	guiGridListSetItemColor( BoughtGridList_RentManager, item, 2, 0, 222, 255 )
	guiGridListSetItemColor( BoughtGridList_RentManager, item, 3, 222, 222, 222 )
end
end )

addEvent( 'RentSystem;C;showCards', true )
addEventHandler( 'RentSystem;C;showCards', root,
function( Name, cType, CN1, CN2, CN3, CN4, CN5, CN6 )
guiGridListClear( List_CardsView )
	local Card1 = guiGridListAddRow( List_CardsView )
	local Card2 = guiGridListAddRow( List_CardsView )
	local Card3 = guiGridListAddRow( List_CardsView )
	local Card4 = guiGridListAddRow( List_CardsView )
	local Card5 = guiGridListAddRow( List_CardsView )
	local Card6 = guiGridListAddRow( List_CardsView )
	local cName1 = guiGridListSetItemText( List_CardsView, Card1, 1, CN1, false, false )
	local cName2 = guiGridListSetItemText( List_CardsView, Card2, 1, CN2, false, false )
	local cName3 = guiGridListSetItemText( List_CardsView, Card3, 1, CN3, false, false )
	local cName4 = guiGridListSetItemText( List_CardsView, Card4, 1, CN4, false, false )
	local cName5 = guiGridListSetItemText( List_CardsView, Card5, 1, CN5, false, false )
	local cName6 = guiGridListSetItemText( List_CardsView, Card6, 1, CN6, false, false )
	guiGridListSetItemColor( List_CardsView, Card1, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card2, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card3, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card4, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card5, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card6, 1, 0, 255, 47 )
	guiSetText( pName_CardsView, Name )
	guiSetText( CardsType_CardsView, cType )
	guiSetVisible( RentManager, false )
	guiSetVisible( CardsView, true )
end )

addEvent( 'RentSystem;C;refreshSpecials', true )
addEventHandler( 'RentSystem;C;refreshSpecials', root,
function( state, value )
	if ( state == 'open' ) then guiSetEnabled( GUIEditor.checkbox[1], true ) guiSetText( GUIEditor.label[7], value ) guiSetText( SpecialStateButton_RentManager, 'تغيير حالة العرض : مقفل' )
		guiSetText( SpecialSellEdit_RentManager, value )
		else
	guiSetEnabled( GUIEditor.checkbox[1], false ) guiCheckBoxSetSelected( GUIEditor.checkbox[1], false ) guiSetText( GUIEditor.label[7], '( لا توجد عروضات خاصة في الوقت الحالي ) .' ) guiSetText( SpecialStateButton_RentManager, 'تغيير حالة العرض : مفتوح' )
end
end )

addEvent( 'RentSystem;C;enableManager', true ) addEventHandler( 'RentSystem;C;enableManager', root, function(  ) guiSetEnabled( GUIEditor.button[4], true ) end )

addEvent( 'RentSystem;C;emptyGridlist', true ) addEventHandler( 'RentSystem;C;emptyGridlist', root, function(  ) guiGridListClear( BoughtGridList_RentManager ) end )

function checkPlayer(  )
	triggerServerEvent( 'RentSystem;S;checkPlayer', Cplayer )
end

addEventHandler( 'onClientResourceStart', resourceRoot,
function(  )
	triggerServerEvent( 'RentSystem;S;refreshList', Cplayer )
	triggerServerEvent( 'RentSystem;S;refreshWindow', Cplayer )
	checkPlayer(  )
end )

addEvent( 'RentSystem;guiButtonToggleEnabled', true )
addEventHandler( 'RentSystem;guiButtonToggleEnabled', root,
function( Ele_Button )
	if ( Ele_Button == 'SpecialStateButton_RentManager' ) then
	guiSetEnabled( SpecialStateButton_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, SpecialStateButton_RentManager, true )
elseif ( Ele_Button == 'SellStateButton_RentManager' ) then
	guiSetEnabled( SellStateButton_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, SellStateButton_RentManager, true )
elseif ( Ele_Button == 'DelSel_RentManager' ) then
	guiSetEnabled( DelSel_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, DelSel_RentManager, true )
elseif ( Ele_Button == 'ShowNum_RentManager' ) then
	guiSetEnabled( ShowNum_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, ShowNum_RentManager, true )
end
end )

for _, card in ipairs( CardTypesTable ) do
	local Card_ = guiComboBoxAddItem( GUIEditor.combobox[1], card[1] )
end

addCommandHandler('عضوية',
function()
if (guiGetVisible(GUIEditor.window[1]) == true) then
guiSetVisible(GUIEditor.window[1],false)
showCursor(false)
else
guiSetVisible(GUIEditor.window[1],true)
showCursor(true)
end
end
)

function apagarScript()
	if fileExists("Client.lua") then
		fileDelete("Client.lua")
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), apagarScript)
addEventHandler("onClientPlayerQuit", getRootElement(), apagarScript)
addEventHandler("onClientPlayerJoin", getRootElement(), apagarScript)