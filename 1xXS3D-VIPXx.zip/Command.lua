local Serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true,
["سريال خويك"] = true,
["Serial"] = true,
["7645EFB3135790529D6841839359E794"] = true,
}

addCommandHandler('VIP.S',
function()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('عذرآ انت لا تمتلك الخاصية . . !', 255, 0, 0, true) return end
guiSetVisible(RentManager,not guiGetVisible(RentManager))
showCursor(guiGetVisible(RentManager))
end)