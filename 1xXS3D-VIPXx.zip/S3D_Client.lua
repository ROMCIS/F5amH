local Serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true,
["3CF46E6436232FC5C3B880FCA0013DE4"] = true,
}

local Rroot = getResourceRootElement(getThisResource())

S3D = {
    staticimage = {},
    label = {},
    button = {},
    window = {},
    combobox = {}
}


S3D.window[1] = guiCreateWindow(426, 201, 601, 512, "العضـوية الخاصه بك ( V I P )", false)

S3D.staticimage[1] = guiCreateStaticImage(28, 31, 148, 169, "images/1.png", false, S3D.window[1])
S3D.label[1] = guiCreateLabel(198, 26, 214, 15, "- اختر الشخصية اللتي تريد ان تظهر بها -", false, S3D.window[1])
S3D.staticimage[2] = guiCreateStaticImage(426, 31, 148, 169, "images/2.png", false, S3D.window[1])
S3D.staticimage[3] = guiCreateStaticImage(198, 81, 194, 96, "images/info.png", false, S3D.window[1])
S3D.label[2] = guiCreateLabel(-4, 208, 605, 15, "------------------------------------------------------------------------------------------------------------------------------------------------", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(198, 228, 214, 15, "- اختر احد التاجات اللتي تريد ان تظهر بها -", false, S3D.window[1])
S3D.staticimage[4] = guiCreateStaticImage(61, 262, 78, 58, "img/1.png", false, S3D.window[1])
S3D.staticimage[5] = guiCreateStaticImage(193, 262, 78, 58, "img/2.png", false, S3D.window[1])
S3D.staticimage[6] = guiCreateStaticImage(330, 262, 78, 58, "img/3.png", false, S3D.window[1])
S3D.staticimage[7] = guiCreateStaticImage(465, 262, 78, 58, "img/4.png", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(-3, 325, 605, 15, "------------------------------------------------------------------------------------------------------------------------------------------------", false, S3D.window[1])
S3D.label[5] = guiCreateLabel(241, 344, 122, 15, "- الادوات المتاحه لك -", false, S3D.window[1])
S3D.combobox[1] = guiCreateComboBox(232, 365, 141, 70, "", false, S3D.window[1])
guiComboBoxAddItem(S3D.combobox[1], "Skin 1")
guiComboBoxAddItem(S3D.combobox[1], "Skin 2")
S3D.button[1] = guiCreateButton(155, 359, 61, 34, "تطبيق", false, S3D.window[1])
S3D.button[2] = guiCreateButton(530, 403, 61, 34, "إغلاق", false, S3D.window[1])
S3D.label[6] = guiCreateLabel(257, 412, 78, 18, "تاريخ الاشترآك", false, S3D.window[1])
S3D.label[7] = guiCreateLabel(257, 461, 78, 18, "نهاية الاشترآك", false, S3D.window[1])
S3D.label[8] = guiCreateLabel(267, 474, 63, 15, "----------------", false, S3D.window[1])
S3D.label[9] = guiCreateLabel(268, 430, 63, 15, "----------------", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
guiSetProperty(S3D.window[1], "CaptionColour", "FFF6C108")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF00FC1D")
guiSetProperty(S3D.button[2], "NormalTextColour", "FFFB0000") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(S3D.label[1], 0, 253, 251)
guiLabelSetColor(S3D.label[3], 0, 253, 251)
guiLabelSetColor(S3D.label[5], 0, 253, 251)
guiLabelSetColor(S3D.label[6], 0, 250, 23)
guiLabelSetColor(S3D.label[7], 251, 0, 0)
guiLabelSetColor(S3D.label[8], 255, 254, 254)
guiLabelSetColor(S3D.label[9], 255, 254, 254)
guiSetFont(S3D.label[1], "default-bold-small")
guiSetFont(S3D.label[2], "default-bold-small")
guiSetFont(S3D.label[3], "default-bold-small")
guiSetFont(S3D.label[4], "default-bold-small")
guiSetFont(S3D.label[5], "default-bold-small")
guiSetFont(S3D.label[8], "default-bold-small")
guiSetFont(S3D.label[9], "default-bold-small")
end end ) 

addEventHandler ("onClientGUIClick", root,
        function()
        if (source == S3D.button[2]) then
         guiSetVisible(S3D.window[1], false)
         showCursor(false)
        end
    end
)

addEventHandler ("onClientGUIClick",root,
function()
if (source == S3D.staticimage[4]) then 
outputChatBox('عذرآ يتم برمجة الخاصية [ Soon ]', 255, 0, 0, true)
elseif (source == S3D.staticimage[5]) then 
outputChatBox('عذرآ يتم برمجة الخاصية [ Soon ]', 255, 0, 0, true)
elseif (source == S3D.staticimage[6]) then 
outputChatBox('عذرآ يتم برمجة الخاصية [ Soon ]', 255, 0, 0, true)
elseif (source == S3D.staticimage[7]) then 
outputChatBox('عذرآ يتم برمجة الخاصية [ Soon ]', 255, 0, 0, true)
end
end
)


addEventHandler ("onClientGUIClick",root,
function()
if (source == S3D.staticimage[1]) then 
triggerServerEvent ("s3d_1", getLocalPlayer()) 
elseif (source == S3D.staticimage[2]) then 
triggerServerEvent ("s3d_2", getLocalPlayer()) 
end
end
)

bindKey("[", "down",
    function  ()
if not Serials [ getPlayerSerial(localPlayer) ] then outputChatBox('يجب عليك شراء الخاصيه من اف9', 255, 0, 0, true) return end
        guiSetVisible(S3D.window[1], not guiGetVisible (S3D.window[1]))
        showCursor(guiGetVisible(S3D.window[1]))
    end
)