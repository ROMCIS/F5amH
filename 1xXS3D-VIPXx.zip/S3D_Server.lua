addEvent( "s3d_1", true )
function s3d_set1 ()
	setPedSkin ( source, 27 ) 
	OutPut('! تم وضع الشخصية بنجاح', source, 240,255,0, false)
end
addEventHandler ( "s3d_1", getRootElement(), s3d_set1 ) 
----

addEvent( "s3d_2", true ) 
function s3d_set2 ()
	setPedSkin ( source, 266 ) 
	OutPut('! تم وضع الشخصية بنجاح', source, 240,255,0, false)
end
addEventHandler ( "s3d_2", getRootElement(), s3d_set2 ) 

function OutPut(message, player, r, g, b)
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end