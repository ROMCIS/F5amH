CardTypesTable = { 
	{'كاش يو | cashU'},
	{'سوا | STC'},
	{'موبايلي | Mobily'},
};


Cplayer = getLocalPlayer(  )

local screenW, screenH = guiGetScreenSize()

GUIEditor = {
    checkbox = {},
    label = {},
    edit = {},
    button = {},
    window = {},
    gridlist = {},
    combobox = {}
}

GUIEditor.window[1] = guiCreateWindow(510, 226, 429, 453, "~ | دخول كبار الشخصيات | ~", false)
guiWindowSetSizable(GUIEditor.window[1], false)
guiSetAlpha(GUIEditor.window[1], 1.00)
guiSetVisible(GUIEditor.window[1], false)
GUIEditor.label[1] = guiCreateLabel(15, 40, 402, 18, "شرح الخاصية : حينما تقوم بتسجيل دخولك، يظهر نص متحرك من الجهه اليمنى", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[1], "default-bold-small")
guiLabelSetColor(GUIEditor.label[1], 235, 161, 19)
guiLabelSetHorizontalAlign(GUIEditor.label[1], "center", false)
GUIEditor.label[2] = guiCreateLabel(110, 64, 211, 18, "ينبه اللاعبين بأنك قمت بتسجيل دخولك !", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[2], "default-bold-small")
guiLabelSetColor(GUIEditor.label[2], 235, 161, 19)
GUIEditor.label[3] = guiCreateLabel(15, 92, 405, 31, "* * * * * * * * * * * * * * *", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[3], "sa-header")
guiLabelSetColor(GUIEditor.label[3], 0, 221, 253)
guiSetProperty(GUIEditor.checkbox[1], "NormalTextColour", "FF00BCD3")
GUIEditor.label[5] = guiCreateLabel(220, 147, 180, 23, "20 سوا = إشتراك شهر كامل ..", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[5], "default-bold-small")
GUIEditor.label[6] = guiCreateLabel(34, 147, 180, 23, "10 باي بال = إشتراك 3 شهور", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[6], "default-bold-small")
GUIEditor.label[4] = guiCreateLabel(150, 185, 108, 27, "││ رقم البطاقة ││", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[4], "default-bold-small")
GUIEditor.checkbox[2] = guiCreateCheckBox(25, 305, 137, 21, "سوا - STC", false, false, GUIEditor.window[1])
guiSetFont(GUIEditor.checkbox[2], "default-bold-small")
guiSetProperty(GUIEditor.checkbox[2], "NormalTextColour", "FF00BCD3")
GUIEditor.label[12] = guiCreateLabel(199, 123, 15, 47, "\n|\n|", false, GUIEditor.window[1])
guiSetFont(GUIEditor.label[12], "default-bold-small")
guiLabelSetColor(GUIEditor.label[12], 255, 232, 39)
guiLabelSetHorizontalAlign(GUIEditor.label[12], "center", false)
guiLabelSetVerticalAlign(GUIEditor.label[12], "center")
GUIEditor.checkbox[3] = guiCreateCheckBox(25, 336, 141, 21, "باي بال - PayPal", false, false, GUIEditor.window[1])
guiSetFont(GUIEditor.checkbox[3], "default-bold-small")
guiSetProperty(GUIEditor.checkbox[3], "NormalTextColour", "FF00BCD3")
GUIEditor.edit[1] = guiCreateEdit(99, 212, 213, 29, "", false, GUIEditor.window[1]) 
GUIEditor.edit[2] = guiCreateEdit(99, 258, 213, 29, "", false, GUIEditor.window[1]) 
GUIEditor.button[2] = guiCreateButton(280, 399, 111, 34, "│ أرسال │", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[2], "default-bold-small")
guiSetProperty(GUIEditor.button[2], "NormalTextColour", "FFE10000")
GUIEditor.button[3] = guiCreateButton(187, 399, 55, 34, "X", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[3], "default-bold-small")
guiSetProperty(GUIEditor.button[3], "NormalTextColour", "FFE10000")
GUIEditor.button[11] = guiCreateButton(35, 399, 111, 34, "│ مثال للخاصية │", false, GUIEditor.window[1])
guiSetFont(GUIEditor.button[11], "default-bold-small") 
guiSetProperty(GUIEditor.button[11], "NormalTextColour", "FFE10000")
----------
RentManager = guiCreateWindow(500, 199, 400, 507, ".:[ System - Welcome ]:.", false)
guiWindowSetSizable(RentManager, false)
guiSetAlpha(RentManager, 1.00)
guiSetVisible(RentManager, false)
BoughtGridList_RentManager = guiCreateGridList(11, 29, 379, 282, false, RentManager)
guiGridListAddColumn(BoughtGridList_RentManager, "اللاعب", 0.3)
guiGridListAddColumn(BoughtGridList_RentManager, "نوع الإشتراك", 0.8)
guiGridListAddColumn(BoughtGridList_RentManager, "تاريخ الشراء", 0.4)
ShowNum_RentManager = guiCreateButton(20, 321, 126, 36, "عرض بطائق الشحن", false, RentManager)
guiSetFont(ShowNum_RentManager, "default-bold-small")
guiSetProperty(ShowNum_RentManager, "NormalTextColour", "FF18FF00")
CopySer_RentManager = guiCreateButton(254, 321, 126, 36, "نسخ السيريال", false, RentManager)
guiSetFont(CopySer_RentManager, "default-bold-small")
guiSetProperty(CopySer_RentManager, "NormalTextColour", "FF18FF00")
DelSel_RentManager = guiCreateButton(254, 451, 126, 36, "حذف اللاعب المحدد", false, RentManager)
guiSetFont(DelSel_RentManager, "default-bold-small")
guiSetProperty(DelSel_RentManager, "NormalTextColour", "FFFF0000")    
CloseButton_RentManager = guiCreateButton(22, 451, 126, 36, "اغلاق", false, RentManager)
guiSetFont(CloseButton_RentManager, "default-bold-small")
guiSetProperty(CloseButton_RentManager, "NormalTextColour", "FFFF0000")
----------
CardsView = guiCreateWindow((screenW - 450) / 2, (screenH - 313) / 2, 450, 313, ".:[ System - Cards ]:.", false)
guiWindowSetSizable(CardsView, false)
guiSetAlpha(CardsView, 1.00)
guiSetVisible(CardsView, false)
Note_CardsView = guiCreateLabel(261, 32, 179, 22, "# بطاقات الدفع الخاصة باللاعب :-", false, CardsView)
guiSetFont(Note_CardsView, "default-bold-small")
guiLabelSetColor(Note_CardsView, 250, 230, 0)
guiLabelSetHorizontalAlign(Note_CardsView, "right", false)
guiLabelSetVerticalAlign(Note_CardsView, "center")
pName_CardsView = guiCreateLabel(10, 32, 251, 22, "None", false, CardsView)
guiSetFont(pName_CardsView, "default-bold-small")
guiLabelSetHorizontalAlign(pName_CardsView, "right", false)
guiLabelSetVerticalAlign(pName_CardsView, "center")
List_CardsView = guiCreateGridList(10, 96, 430, 176, false, CardsView)
guiGridListAddColumn(List_CardsView, "البطاقات", 0.9)
X_CardsView = guiCreateButton(20, 282, 410, 21, "X", false, CardsView)
guiSetFont(X_CardsView, "default-bold-small")
guiSetProperty(X_CardsView, "NormalTextColour", "FFED0000")
----------
ViewSystem = guiCreateWindow((screenW - 555) / 2, (screenH - 548) / 2, 555, 548, ".:[ System - Cards ]:.", false)
guiWindowSetSizable(ViewSystem, false)
guiSetAlpha(ViewSystem, 1.00)
guiSetProperty(ViewSystem, "CaptionColour", "FF00FDFB")
guiSetVisible(ViewSystem, false)
Photo_ViewSystem = guiCreateStaticImage(10, 1, 535, 497, "Control-View.png", false, ViewSystem)
X_ViewSystem = guiCreateButton(20, 508, 515, 21, "X", false, ViewSystem)
guiSetFont(X_ViewSystem, "default-bold-small")
guiSetProperty(X_ViewSystem, "NormalTextColour", "FFFE0000")





function clickElements(  )
	if ( source == GUIEditor.button[3] ) then
		guiSetVisible( GUIEditor.window[1], false )
		showCursor( false )
		guiSetInputEnabled( false )
	elseif ( source == GUIEditor.checkbox[1] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
	elseif ( source == GUIEditor.checkbox[2] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
	elseif ( source == GUIEditor.checkbox[3] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
	elseif ( source == GUIEditor.checkbox[4] ) then
		guiCheckBoxSetSelected( GUIEditor.checkbox[2], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[3], false )
		guiCheckBoxSetSelected( GUIEditor.checkbox[1], false )
	elseif ( source == GUIEditor.button[2] ) then
		local CB1 = guiCheckBoxGetSelected( GUIEditor.checkbox[1] )
		local CB2 = guiCheckBoxGetSelected( GUIEditor.checkbox[2] )
		local CB3 = guiCheckBoxGetSelected( GUIEditor.checkbox[3] )
		local CB4 = guiCheckBoxGetSelected( GUIEditor.checkbox[4] )
			if ( CB1 == false and CB2 == false and CB3 == false and CB4 == false ) then
			exports["infobox"]:outputMessage ("يجب عليك اختيار نوع الاشتراك",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local Sel = guiComboBoxGetSelected( GUIEditor.combobox[1] )
			if ( Sel == -1 ) then
			exports["infobox"]:outputMessage ("يجب عليك ادخال رقم البطاقة",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local CN1 = guiGetText( GUIEditor.edit[1] )
		local CN2 = guiGetText( GUIEditor.edit[2] )
			if ( not tonumber( CN1 ) and not tonumber( CN2 ) and not tonumber( CN3 ) and not tonumber( CN4 ) and not tonumber( CN5 ) and not tonumber( CN6 ) ) then
			exports["infobox"]:outputMessage ("يجب أن يتكون رقم بطاقة الشحن من أرقام فقط!",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		if ( CB1 == true ) then Subscription = guiGetText( SpecialSellEdit_RentManager ) else if ( CB2 == true ) then Subscription = guiGetText( GUIEditor.checkbox[2] ) else if ( CB3 == true ) then Subscription = guiGetText( GUIEditor.checkbox[3] ) else if ( CB4 == true ) then Subscription = guiGetText( GUIEditor.checkbox[4] ) end end end end
		triggerServerEvent( 'RentSystem;buySubscription', Cplayer, Subscription, guiComboBoxGetItemText( GUIEditor.combobox[1], guiComboBoxGetSelected( GUIEditor.combobox[1] ) ), CN1, CN2, CN3, CN4, CN5, CN6 )
	elseif ( source == GUIEditor.button[4] ) then
		guiSetVisible( GUIEditor.window[1], false )
		guiSetVisible( RentManager, true )
	elseif ( source == CloseButton_RentManager ) then
		guiSetVisible( GUIEditor.window[1], true )
		guiSetVisible( RentManager, false )
	elseif ( source == ShowNum_RentManager ) then
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		triggerServerEvent( 'RentSystem;getCards', Cplayer, guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 ), guiGridListGetItemData( BoughtGridList_RentManager, Sel, 2 ) )
	elseif ( source == X_CardsView ) then
		guiSetVisible( RentManager, true )
		guiSetVisible( CardsView, false )
	elseif ( source == SellStateButton_RentManager ) then
		if ( guiGetText( SellStateButton_RentManager ) == 'تغيير الحالة : مقفول الآن !' ) then
		state_Sell = 'close'
			else if ( guiGetText( SellStateButton_RentManager ) == 'تغيير الحالة : مفتوح الآن !' ) then
		state_Sell = 'open'
			end
		end
		triggerServerEvent( 'RentSystem;changeSellState', Cplayer, state_Sell )
	elseif ( source == SpecialStateButton_RentManager ) then
		if ( guiGetText( SpecialStateButton_RentManager ) == 'تغيير حالة العرض : مفتوح' ) then
		specialValue = guiGetText( SpecialSellEdit_RentManager )
			if ( specialValue == '' or specialValue == '( لا توجد عروضات خاصة في الوقت الحالي ) .' ) then
			outputChatBox( '#FF0000* #FFFF00Rent System - Subscription #FF0000: #FFFFFF عذرا قم بكتابة العرض بشكل صحيح !', 255, 255, 255, true ) return end
		specialState = 'open'
			else if ( guiGetText( SpecialStateButton_RentManager ) == 'تغيير حالة العرض : مقفل' ) then
		specialState = 'close' 
			end
		end
		triggerServerEvent( 'RentSystem;changeSpecialState', Cplayer, specialState, specialValue )
	elseif ( source == DelSel_RentManager ) then 
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		triggerServerEvent( 'RentSystem;removeSel', Cplayer, guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 ), guiGridListGetItemData( BoughtGridList_RentManager, Sel, 2 ) )
	elseif ( source == CopySer_RentManager ) then 
		local Sel = guiGridListGetSelectedItem( BoughtGridList_RentManager )
			if ( Sel == -1 ) then 
			exports["infobox"]:outputMessage ("الرجاء تحديد اللاعب",math.random(0,255),math.random(0,255),math.random(0,155)) return end
		local Serial = guiGridListGetItemData( BoughtGridList_RentManager, Sel, 3 )
		setClipboard( Serial )
		exports["infobox"]:outputMessage ("تم نسخ السريال بنجاح",math.random(0,255),math.random(0,255),math.random(0,155))
		guiSetEnabled( CopySer_RentManager, false )
		setTimer( guiSetEnabled, 3000, 1, CopySer_RentManager, true )
	elseif ( source == GUIEditor.button[1] ) then 
		guiSetVisible( GUIEditor.window[1], false )
		guiSetVisible( ViewSystem, true )
	elseif ( source == X_ViewSystem ) then
		guiSetVisible( GUIEditor.window[1], true )
		guiSetVisible( ViewSystem, false )
		guiSetAlpha( Photo_ViewSystem, 0.50 )
end
end
addEventHandler( 'onClientGUIClick', root, clickElements )

addEventHandler( 'onClientMouseEnter', root,
function( )
	if ( source == Photo_ViewSystem ) then
		guiSetAlpha( Photo_ViewSystem, 1 )
	end
end )

addEventHandler( 'onClientMouseLeave', root,
function( )
	if ( source == Photo_ViewSystem ) then
		guiSetAlpha( Photo_ViewSystem, 0.50 )
	end
end )

addEventHandler('onClientGUIClick',root,
function () 
if source == GUIEditor.button[11] then 
if isTimer(timer2) then 
exports.infobox:outputMessage("يرجى الانتظار !",255,0,0,true)
return
end	
timer2 = setTimer(function() end,1 * 5 * 1000,1)
local name = getPlayerName(localPlayer)
exports["infobox"]:outputMessage ("#VIP Login : Welcome To [ Test ] !",math.random(0,255),math.random(0,255),math.random(0,155))
end
end
)

addEvent( 'RentSystem;C;refreshList', true )
addEventHandler( 'RentSystem;C;refreshList', root,
function( Table )
	guiGridListClear( BoughtGridList_RentManager )
		for i, _ in ipairs( Table ) do 
		local item = guiGridListAddRow( BoughtGridList_RentManager )
			local Name = guiGridListSetItemText( BoughtGridList_RentManager, item, 1, Table[i].pName:gsub( '#%x%x%x%x%x%x', '' ), false, false )
				local subType = guiGridListSetItemText( BoughtGridList_RentManager, item, 2, Table[i].pSub, false, false )
					local buyDate = guiGridListSetItemText( BoughtGridList_RentManager, item, 3, Table[i].sysDate, false, false )
				local pSerial = guiGridListSetItemData( BoughtGridList_RentManager, item, 3, Table[i].pSerial )
			local value = guiGridListSetItemData( BoughtGridList_RentManager, item, 2, Table[i].sysValue )
		if ( Table[i].showValue == 'false' ) then
			guiGridListSetItemColor( BoughtGridList_RentManager, item, 1, 255, 0, 0 )
			else
		guiGridListSetItemColor( BoughtGridList_RentManager, item, 1, 0, 255, 0 )
	end
	guiGridListSetItemColor( BoughtGridList_RentManager, item, 2, 0, 222, 255 )
	guiGridListSetItemColor( BoughtGridList_RentManager, item, 3, 222, 222, 222 )
end
end )

addEvent( 'RentSystem;C;showCards', true )
addEventHandler( 'RentSystem;C;showCards', root,
function( Name, cType, CN1, CN2, CN3, CN4, CN5, CN6 )
guiGridListClear( List_CardsView )
	local Card1 = guiGridListAddRow( List_CardsView )
	local Card2 = guiGridListAddRow( List_CardsView )
	local Card3 = guiGridListAddRow( List_CardsView )
	local Card4 = guiGridListAddRow( List_CardsView )
	local Card5 = guiGridListAddRow( List_CardsView )
	local Card6 = guiGridListAddRow( List_CardsView )
	local cName1 = guiGridListSetItemText( List_CardsView, Card1, 1, CN1, false, false )
	local cName2 = guiGridListSetItemText( List_CardsView, Card2, 1, CN2, false, false )
	local cName3 = guiGridListSetItemText( List_CardsView, Card3, 1, CN3, false, false )
	local cName4 = guiGridListSetItemText( List_CardsView, Card4, 1, CN4, false, false )
	local cName5 = guiGridListSetItemText( List_CardsView, Card5, 1, CN5, false, false )
	local cName6 = guiGridListSetItemText( List_CardsView, Card6, 1, CN6, false, false )
	guiGridListSetItemColor( List_CardsView, Card1, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card2, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card3, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card4, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card5, 1, 0, 255, 47 )
	guiGridListSetItemColor( List_CardsView, Card6, 1, 0, 255, 47 )
	guiSetText( pName_CardsView, Name )
	guiSetText( CardsType_CardsView, cType )
	guiSetVisible( RentManager, false )
	guiSetVisible( CardsView, true )
end )

addEvent( 'RentSystem;C;refreshSpecials', true )
addEventHandler( 'RentSystem;C;refreshSpecials', root,
function( state, value )
	if ( state == 'open' ) then guiSetEnabled( GUIEditor.checkbox[1], true ) guiSetText( GUIEditor.label[7], value ) guiSetText( SpecialStateButton_RentManager, 'تغيير حالة العرض : مقفل' )
		guiSetText( SpecialSellEdit_RentManager, value )
		else
	guiSetEnabled( GUIEditor.checkbox[1], false ) guiCheckBoxSetSelected( GUIEditor.checkbox[1], false ) guiSetText( GUIEditor.label[7], '( لا توجد عروضات خاصة في الوقت الحالي ) .' ) guiSetText( SpecialStateButton_RentManager, 'تغيير حالة العرض : مفتوح' )
end
end )

addEvent( 'RentSystem;C;enableManager', true ) addEventHandler( 'RentSystem;C;enableManager', root, function(  ) guiSetEnabled( GUIEditor.button[4], true ) end )

addEvent( 'RentSystem;C;emptyGridlist', true ) addEventHandler( 'RentSystem;C;emptyGridlist', root, function(  ) guiGridListClear( BoughtGridList_RentManager ) end )

function checkPlayer(  )
	triggerServerEvent( 'RentSystem;S;checkPlayer', Cplayer )
end

addEventHandler( 'onClientResourceStart', resourceRoot,
function(  )
	triggerServerEvent( 'RentSystem;S;refreshList', Cplayer )
	triggerServerEvent( 'RentSystem;S;refreshWindow', Cplayer )
	checkPlayer(  )
end )

addEvent( 'RentSystem;guiButtonToggleEnabled', true )
addEventHandler( 'RentSystem;guiButtonToggleEnabled', root,
function( Ele_Button )
	if ( Ele_Button == 'SpecialStateButton_RentManager' ) then
	guiSetEnabled( SpecialStateButton_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, SpecialStateButton_RentManager, true )
elseif ( Ele_Button == 'SellStateButton_RentManager' ) then
	guiSetEnabled( SellStateButton_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, SellStateButton_RentManager, true )
elseif ( Ele_Button == 'DelSel_RentManager' ) then
	guiSetEnabled( DelSel_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, DelSel_RentManager, true )
elseif ( Ele_Button == 'ShowNum_RentManager' ) then
	guiSetEnabled( ShowNum_RentManager, false )
	setTimer( guiSetEnabled, 3000, 1, ShowNum_RentManager, true )
end
end )

for _, card in ipairs( CardTypesTable ) do
	local Card_ = guiComboBoxAddItem( GUIEditor.combobox[1], card[1] )
end

addCommandHandler('ترحيب',
function()
if (guiGetVisible(GUIEditor.window[1]) == true) then
guiSetVisible(GUIEditor.window[1],false)
showCursor(false)
else
guiSetVisible(GUIEditor.window[1],true)
showCursor(true)
end
end
)