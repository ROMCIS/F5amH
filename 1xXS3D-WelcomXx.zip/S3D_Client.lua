﻿local Rroot = getResourceRootElement(getThisResource())
local screenW, screenH = guiGetScreenSize()

local Serials = {
["8820C68264F0C16A6ECDD05B521DB2F4"] = true, -- رومسيس
["1A5AE4945A35897595921B1F48DE5854"] = true, -- فان دام
["A7A4F26C22E7C78BBB36C60B43142542"] = true, -- فهد
};

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

S3D = {
    staticimage = {},
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}

local screenW, screenH = guiGetScreenSize()
S3D.window[1] = guiCreateWindow((screenW - 513) / 2, (screenH - 483) / 2, 513, 483, "-| Serials Add : Wzrah Buy VIP-Login |-", false)

S3D.label[1] = guiCreateLabel(150, 31, 214, 15, "-| Wzrah تفعيل دخول كبار الشخصيات |-", false, S3D.window[1])
S3D.edit[1] = guiCreateEdit(51, 68, 447, 22, "Search :", false, S3D.window[1])
S3D.staticimage[1] = guiCreateStaticImage(16, 68, 20, 22, ":admin/client/images/search.png", false, S3D.window[1])
S3D.gridlist[1] = guiCreateGridList(12, 110, 491, 178, false, S3D.window[1])
guiGridListAddColumn(S3D.gridlist[1], "Name", 0.2)
guiGridListAddColumn(S3D.gridlist[1], "Serial", 0.55)
guiGridListAddColumn(S3D.gridlist[1], "Days", 0.3)
guiSetFont(S3D.gridlist[1], "default-bold-small")
S3D.label[2] = guiCreateLabel(16, 308, 40, 15, "Serial :", false, S3D.window[1])
S3D.edit[2] = guiCreateEdit(63, 304, 257, 23, "", false, S3D.window[1])
S3D.label[3] = guiCreateLabel(16, 337, 40, 15, ": المدة", false, S3D.window[1])
S3D.edit[3] = guiCreateEdit(63, 333, 118, 23, "", false, S3D.window[1])
S3D.button[1] = guiCreateButton(10, 374, 151, 27, "تفعيل السريال", false, S3D.window[1])
S3D.button[2] = guiCreateButton(181, 374, 151, 27, "ازاله السريال", false, S3D.window[1])
S3D.button[3] = guiCreateButton(352, 374, 151, 27, "ازاله الكل", false, S3D.window[1])
S3D.button[4] = guiCreateButton(95, 411, 151, 27, "Log / لوقـ", false, S3D.window[1])
S3D.button[5] = guiCreateButton(268, 411, 151, 27, "Close / أغلاقـ", false, S3D.window[1])
S3D.label[4] = guiCreateLabel(164, 453, 188, 15, "*هام : اللوحة مراقبة من قبل الإدارة", false, S3D.window[1])

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1.00)
guiSetProperty(S3D.window[1], "CaptionColour", "FF7C9039")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(S3D.button[1], "NormalTextColour", "FF56FF40")
guiSetProperty(S3D.button[2], "NormalTextColour", "FF56FF40")
guiSetProperty(S3D.button[3], "NormalTextColour", "FF56FF40")
guiSetProperty(S3D.button[4], "NormalTextColour", "FFFEFC00") 
guiSetProperty(S3D.button[5], "NormalTextColour", "FFFEFC00") 
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(S3D.label[1], 253, 66, 66)
guiLabelSetColor(S3D.label[2], 253, 66, 66)
guiLabelSetColor(S3D.label[3], 253, 66, 66)
guiLabelSetColor(S3D.label[4], 253, 0, 0)   
end
for _, v in ipairs(getElementsByType('gui-edit',Rroot)) do
guiSetFont(v, "default-bold-small")
end end ) 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

addCommandHandler('s3d.welcome',
function()
if ( Serials[getPlayerSerial( localPlayer )] ) then
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1]))
showCursor(guiGetVisible(S3D.window[1]))
triggerServerEvent('S3D:LoadData',localPlayer)
else exports.infobox:outputMessage('لا تملك تصريح لفتح اللوحة !',0,255,0,source)	 end end)

addEventHandler('onClientGUIClick',root,
function()
if source == S3D.button[5] then
guiSetVisible(S3D.window[1],false)
showCursor(false)
elseif source == S3D.button[1] then
local serialCheck = guiGetText( S3D.edit[2] )
local days = tonumber(guiGetText( S3D.edit[3] ))
if ( serialCheck == '' or guiEditGetCaretIndex( S3D.edit[2] ) < 32 or guiEditGetCaretIndex( S3D.edit[2] ) > 32 )  then return exports.infobox:outputMessage('السريال الذي ادخلته غير صحيح !',0,255,0,source) else end
if not (days) or ( days == '' ) then return exports.infobox:outputMessage('يرجى ادخال عدد ايام التفعيل !',0,255,0,source) end
if (days) > 60 then return exports.infobox:outputMessage('عذرا الحد الأقصى ( شهرين | 60 يوم ) !',0,255,0,source) end
triggerServerEvent( 'S3D:AddPlayerToSystem', localPlayer, serialCheck, days )
elseif source == S3D.button[2] then
local sel = guiGridListGetSelectedItem(S3D.gridlist[1])
if sel == -1 then return exports.infobox:outputMessage('يرجى أختيار الاعب من القائمة',0,255,0,source) end
local name = guiGridListGetItemText(S3D.gridlist[1],sel,1)
local serial = guiGridListGetItemText(S3D.gridlist[1],sel,2)
triggerServerEvent('S3D:DeleteUserFromSystem',localPlayer,name,serial)
elseif source == S3D.button[3] then
triggerServerEvent('S3D:DeleteAll',localPlayer)
elseif source == CloseLog then
guiSetVisible(LogPanel,false)
showCursor(false)
end
end)

addEvent('S3D:ClearSystemGrid',true)
addEventHandler('S3D:ClearSystemGrid',root,
function()
guiGridListClear(S3D.gridlist[1])
end)

addEvent('S3D:AddTheDataToSystemGrid',true)
addEventHandler('S3D:AddTheDataToSystemGrid',root,
function(Data)
guiGridListClear(S3D.gridlist[1])
DataSerach = Data
for i, v in ipairs(Data) do 
local row = guiGridListAddRow( S3D.gridlist[1] )
local name = guiGridListSetItemText( S3D.gridlist[1], row, 1, string.gsub( Data[i].name, '#%x%x%x%x%x%x', '' ), false, false )
local serial = guiGridListSetItemText( S3D.gridlist[1], row, 2, Data[i].serial, false, false )
local days = guiGridListSetItemText( S3D.gridlist[1], row, 3, Data[i].days, false, false )
end
end)

addEventHandler("onClientGUIChanged", S3D.edit[1], 
function() 
local text = guiGetText(source) 
if text == "" then
triggerServerEvent('S3D:LoadData',localPlayer)
else
if not(DataSerach) then return end
guiGridListClear(S3D.gridlist[1]) 
for i,v in ipairs(DataSerach) do
if string.find ( string.upper (DataSerach[i].name, '#%x%x%x%x%x%x', '' ), string.upper ( text ), 1, true ) then 
local row = guiGridListAddRow(S3D.gridlist[1]) 
guiGridListSetItemText (S3D.gridlist[1],row,1,string.gsub( DataSerach[i].name, '#%x%x%x%x%x%x', '' ),false,false)
guiGridListSetItemText (S3D.gridlist[1],row,2,DataSerach[i].serial,false,false)
guiGridListSetItemText (S3D.gridlist[1],row,3,DataSerach[i].days,false,false)
guiGridListSetItemColor (S3D.gridlist[1],row,1,255,255,0)
guiGridListSetItemColor (S3D.gridlist[1],row,2,255,255,0)
guiGridListSetItemColor (S3D.gridlist[1],row,3,255,255,0)
end 
end 
end 
end )