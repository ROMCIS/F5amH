Timer = {}

local S3D = dbConnect( 'sqlite', 'S3D_Amlak.db' )
dbExec( S3D, ' CREATE TABLE IF NOT EXISTS `AmlakSystem` ( serial, name, days ) ' )

function getPlayerFromSerial ( serial )
    assert ( type ( serial ) == "string" and #serial == 32, "getPlayerFromSerial - invalid serial" )
    for index, player in ipairs ( getElementsByType ( "player" ) ) do
        if ( getPlayerSerial ( player ) == serial ) then
            return player
        end
    end
    return false
end

function refreshSystem()
local loadMyDB = dbQuery( S3D, ' SELECT * FROM `AmlakSystem` ' )
local mPoll = dbPoll( loadMyDB, -1 )
if ( type ( mPoll ) == 'table' and #mPoll == 0 or not mPoll ) then triggerClientEvent( 'S3D:ClearSystemGrid', root ) return end
triggerClientEvent( 'S3D:AddTheDataToSystemGrid', root, mPoll )
end
addEvent( 'S3D:LoadData', true )
addEventHandler( 'S3D:LoadData', root, refreshSystem )

addEvent('S3D:AddPlayerToSystem',true)
addEventHandler('S3D:AddPlayerToSystem',root,
function(serial, days)
local playerToAdd = getPlayerFromSerial(serial)
if not ( playerToAdd ) then return OutPut("يجب على المستخدم الدخول !", source, 0, 255, 0)  end
local serialCheck = dbQuery( S3D, ' SELECT * FROM `AmlakSystem` WHERE serial = ? ', serial )
local poll = dbPoll( serialCheck, -1 )
if ( type( poll ) == 'table' and #poll ~= 0 ) then return OutPut("! تم تفعيل السريال مسبقا يرجى الإنتباه", source, 0, 255, 0)  end
dbExec( S3D, ' INSERT INTO `AmlakSystem` VALUES(?, ?, ?) ', serial, getPlayerName( playerToAdd ), days )
OutPut('(VIP-Login) : ('..string.gsub( getPlayerName( playerToAdd ), '#%x%x%x%x%x%x', '')..') : تم تفعيل اللاعب', source, 0, 255, 0) 
refreshSystem()
end)

addEvent('S3D:DeleteUserFromSystem',true)
addEventHandler('S3D:DeleteUserFromSystem',root,
function(name, serial)
local serialCheck = dbQuery( S3D, ' SELECT * FROM `AmlakSystem` WHERE serial = ? ', serial )
local poll = dbPoll( serialCheck, -1 )
if not ( type( poll ) == 'table' and #poll ~= 0 ) then return OutPut('خطأ في السكربت', source, 0, 255, 0)  end
dbExec( S3D, ' DELETE FROM `AmlakSystem` WHERE serial = ? ', serial )
OutPut('(VIP-Login) : ('..name..') : تم ازالة اللاعب', source, 0, 255, 0) 
refreshSystem()
end)

addEvent('S3D:DeleteAll',true)
addEventHandler('S3D:DeleteAll',root,
function()
local all = dbQuery( S3D, ' SELECT * FROM `AmlakSystem`' )
local poll = dbPoll( all, -1 )
if ( type( poll ) == 'table' and #poll == 0 ) then return OutPut('(VIP-Login) : خطأ', source, 0, 255, 0)  end
dbExec( S3D, ' DROP TABLE `AmlakSystem` ' )
dbExec( S3D, ' CREATE TABLE IF NOT EXISTS `AmlakSystem` ( serial, name, days ) ' )
OutPut('(VIP-Login) : تم ازالة كل اللاعبين', source, 0, 255, 0) 
refreshSystem()
end)

addEvent('S3D:CheckHim',true)
addEventHandler('S3D:CheckHim',root,
function()
local serial = dbQuery( S3D, ' SELECT * FROM `AmlakSystem` WHERE serial = ? ',getPlayerSerial(source) )
local poll = dbPoll( serial, -1 )
if ( type( poll ) == 'table' and #poll == 0 ) then return end
triggerEvent(source,'S3D:2',source)
end)

  function ksa()
local serial = dbQuery( S3D, ' SELECT * FROM `AmlakSystem` WHERE serial = ? ',getPlayerSerial(source) )
local poll = dbPoll( serial, -1 )
if ( type( poll ) == 'table' and #poll == 0 ) then return end
    OutPut("#VIP Login : Welcome To [ " ..getPlayerName(source):gsub("#%x%x%x%x%x%x", "") .. " ] !",root, math.random(0,255),math.random(0,255),math.random(0,155))
  end
addEventHandler("onPlayerLogin", root,ksa)

addEvent('2',true)
addEventHandler('2',root,
function()
ksa()
end)

function OutPut(message, player, r, g, b)
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEvent("server:outputMessage", true)
addEventHandler("server:outputMessage", root,
	function(message, r, g, b)
		OutPut(message, source, r, g, b)
	end
)
