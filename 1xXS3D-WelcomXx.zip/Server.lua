--[[
* Buy Subscription For Rent System - created by "MR.GRAND" all rights reserved !
# MR.GRAND INFO :
* Join us on facebook : https://fb.com/groups/luaprofessional
* My Skype : kamel1234128
* My E-mail : us.luapro@gmail.com
* My youtube channel : https://www.youtube.com/kamelaliraqi4arab
----------
I hope you liked this script :) .
]]

--[[ جدول السيريالات المصرح لها بفتح زر الإدارة لأدارة بطاقات الشحن واللاعبين الذين قاموآ بالدفع ]]
serials = {
	['Serial'] = true,
	['Serial'] = true,
	['Serial'] = true,
	['Serial'] = true,
	['Serial'] = true,
	['Serial'] = true,
};

--dbExec( RSDB, ' DROP TABLE `Rent_System-SysStats` ' ) --[[ لفرمتت قاعدة بيانات حالة الشراء والعروض الخاصة ]]
--dbExec( RSDB, ' DROP TABLE `Rent_System-Buy` ' ) --[[ لفرمتت قاعدة بيانات اللاعبين والبطائق المدفوعة ]]

--[[ ملاحظة : تعديل الأكواد تحت هذا السطر قد يؤدي إلى أعطال في السكربت, إن لم تكن تعرف للبرمجة ]]

local RSDB = dbConnect( 'sqlite', 'Rent System - BoughtPlayers' )
dbExec( RSDB, ' CREATE TABLE IF NOT EXISTS `Rent_System-Buy` ( pSerial, pName, pSub, pcType, pcN1, pcN2, pcN3, pcN4, pcN5, pcN6, sysDate, sysValue, showValue ) ' )
dbExec( RSDB, ' CREATE TABLE IF NOT EXISTS `Rent_System-SysStats` ( sellState, specialState, specialValue ) ' )

function refreshList(  )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-Buy` ')
		local mainTable = dbPoll( check, -1 )
		if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then triggerClientEvent( root, 'RentSystem;C;emptyGridlist', root ) return end
	triggerClientEvent( root, 'RentSystem;C;refreshList', root, mainTable )
end
addEvent( 'RentSystem;S;refreshList', true ) addEventHandler( 'RentSystem;S;refreshList', root, refreshList )

addEvent( 'RentSystem;S;checkPlayer', true )
addEventHandler( 'RentSystem;S;checkPlayer', root,
function(  )
	if ( serials[getPlayerSerial( source )] ) then
		triggerClientEvent( source, 'RentSystem;C;enableManager', source )
	end
end )

function refreshWindow(  )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then return end
		local state = mainTable[1]['sellState']
	triggerClientEvent( root, 'RentSystem;C;refreshWindow', root, state )
		local specialState = mainTable[1]['specialState']
		local specialValue = mainTable[1]['specialValue']
	triggerClientEvent( root, 'RentSystem;C;refreshSpecials', root, specialState, specialValue )
end
addEvent( 'RentSystem;S;refreshWindow', true )
addEventHandler( 'RentSystem;S;refreshWindow', root, refreshWindow )

addEvent( 'RentSystem;changeSpecialState', true )
addEventHandler( 'RentSystem;changeSpecialState', root,
function( specialState, specialValue )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then
		dbExec( RSDB, ' INSERT INTO `Rent_System-SysStats` VALUES(?,?,?) ', nil, specialState, specialValue )
			else
		dbExec( RSDB, ' UPDATE `Rent_System-SysStats` SET specialState = ?, specialValue = ? ', specialState, specialValue )
	end
		outputChatBox( '#3CFF00* #FFFF00Rent System - Subscription #3CFF00: #FFFFFF تم تغيير العروض الخاصة بنجاح !', source, 255, 255, 255, true )
	refreshList(  )
refreshWindow(  )
triggerClientEvent( source, 'RentSystem;guiButtonToggleEnabled', source, 'SpecialStateButton_RentManager' )
end )

addEvent( 'RentSystem;changeSellState', true )
addEventHandler( 'RentSystem;changeSellState', root,
function( state )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-SysStats` ' )
		local mainTable = dbPoll( check, -1 )
			if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then
				dbExec( RSDB, ' INSERT INTO `Rent_System-SysStats` VALUES(?,?,?) ', state, nil, nil )
			else
		dbExec( RSDB, ' UPDATE `Rent_System-SysStats` SET sellState = ? ', state )
	end
	outputChatBox( '#3CFF00* #FFFF00Rent System - Subscription #3CFF00: #FFFFFF تم تغيير حالة البيع بنجاح !', source, 255, 255, 255, true )
refreshList(  )
refreshWindow(  )
triggerClientEvent( source, 'RentSystem;guiButtonToggleEnabled', source, 'SellStateButton_RentManager' )
end )

addEvent( 'RentSystem;removeSel', true )
addEventHandler( 'RentSystem;removeSel', root,
function( serial, value )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-Buy` WHERE pSerial = ? AND sysValue = ? ', serial, value )
		local mainTable = dbPoll( check, -1 )
		if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then return end
	dbExec( RSDB, ' DELETE FROM `Rent_System-Buy` WHERE pSerial = ? AND sysValue = ? ', serial, value )
refreshList(  )
refreshWindow(  )
triggerClientEvent( source, 'RentSystem;guiButtonToggleEnabled', source, 'DelSel_RentManager' )
end )

addEventHandler( 'onPlayerChangeNick', root,
function( oldNick, newNick )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-Buy` WHERE pSerial = ? ', getPlayerSerial( source ) )
		local mainTable = dbPoll( check, -1 )
		if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then return end
	dbExec( RSDB, ' UPDATE `Rent_System-Buy` SET pName = ? WHERE pSerial = ? ', newNick, getPlayerSerial( source ) )
refreshList(  )
refreshWindow(  )
end )

addEvent( 'RentSystem;getCards', true )
addEventHandler( 'RentSystem;getCards', root,
function( serial, value )
	local check = dbQuery( RSDB, ' SELECT * FROM `Rent_System-Buy` WHERE pSerial = ? AND sysValue = ? ', serial, value )
		local mainTable = dbPoll( check, -1 )
		if ( type ( mainTable ) == 'table' and #mainTable == 0 or not mainTable ) then return end
	local Name = mainTable[1]['pName']
	local cType = mainTable[1]['pcType']
	local CN1 = mainTable[1]['pcN1']
	local CN2 = mainTable[1]['pcN2']
	local CN3 = mainTable[1]['pcN3']
	local CN4 = mainTable[1]['pcN4']
	local CN5 = mainTable[1]['pcN5']
	local CN6 = mainTable[1]['pcN6']
	triggerClientEvent( source, 'RentSystem;C;showCards', source, Name, cType, CN1, CN2, CN3, CN4, CN5, CN6 )
	dbExec( RSDB, ' UPDATE `Rent_System-Buy` SET showValue = ? WHERE pSerial = ? AND sysValue = ? ', 'true', serial, value )
	refreshList(  )
triggerClientEvent( source, 'RentSystem;guiButtonToggleEnabled', source, 'ShowNum_RentManager' )
end )

addEvent( 'RentSystem;buySubscription', true )
addEventHandler( 'RentSystem;buySubscription', root,
function( Subscription, cardType, CN1, CN2, CN3, CN4, CN5, CN6 )
	local time = getRealTime(  )
	local hour = time.hour % 12 and time.hour % 12
	local Date = ('[' .. hour .. ':' ..time.minute.. ':'.. time.second.. '] - ['.. time.monthday.. '/'.. time.month.. '/20'.. string.sub( time.year, 2 ) .. ']')
		dbExec( RSDB, ' INSERT INTO `Rent_System-Buy` VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ', getPlayerSerial( source ), getPlayerName( source ), Subscription, cardType, CN1, CN2, CN3, CN4, CN5, CN6, Date, Date, 'false'  )
			OutPut( "تم أرسال المعلومات الى صاحب السيرفر سيتم مراجعتها خلال 24 ساعة",source, math.random(0,255),math.random(0,255),math.random(0,155))
	refreshList(  )
refreshWindow(  )
triggerClientEvent( source, 'RentSystem;guiButtonToggleEnabled', source, 'GUIEditor.button[2]' )
end )




function OutPut(message, player, r, g, b)
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEvent("server:outputMessage", true)
addEventHandler("server:outputMessage", root,
	function(message, r, g, b)
		OutPut(message, source, r, g, b)
	end
)
