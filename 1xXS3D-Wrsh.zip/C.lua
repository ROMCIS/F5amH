Wrsh = {
{"$ Cash","500000",0000},
{"Killer","300000",0010},
{"Arrow","100000",0001},
{"Smoking","100000",0002},
{"Paintjob 1","200000",0003},
{"Paintjob 2","200000",0004},
{"Paintjob 3","200000",0005},
{"Nitro x10","10000",1010},
{"Nitro x5","5000",1008},
{"Nitro x2","2000",1009},
{"Hydraulics","10000",1087},
{"Wheel 1","2000",1025},
{"Wheel 2","2000",1078},
{"Wheel 3","2000",1084},
{"Wheel 4","2000",1073},
{"Wheel 5","2000",1079},
{"Wheel 6","2000",1085},
{"Wheel 7","2000",1074},
{"Wheel 8","2000",1080},
{"Wheel 9","2000",1096},
{"Wheel 10","2000",1075},
{"Wheel 11","2000",1081},
{"Wheel 12","2000",1097},
{"Wheel 13","2000",1076},
{"Wheel 14","2000",1082},
{"Wheel 15","2000",1098},
{"Wheel 16","2000",1077},
{"Wheel 17","2000",1083},
} 

GUIEditor = {
    gridlist = {},
    window = {},
    button = {}
}
addEventHandler("onClientResourceStart", resourceRoot,
    function()
local screenW, screenH = guiGetScreenSize()
        GUIEditor.window[1] = guiCreateWindow(10, (screenH - 336) / 2, 172, 341, "الورشة", false)
		guiSetVisible ( GUIEditor.window[1], false )
        GUIEditor.gridlist[1] = guiCreateGridList(10, 24, 223, 218, false, GUIEditor.window[1])
		guiGridListAddColumn(GUIEditor.gridlist[1], "السلعة", 0.47)
		guiGridListAddColumn(GUIEditor.gridlist[1], "السعر", 0.34)
for k,v in ipairs ( Wrsh ) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,v[1],false,false)
	guiGridListSetItemText(GUIEditor.gridlist[1],row,2,"$"..convertNumber(v[2]),false,false)
	guiGridListSetItemData(GUIEditor.gridlist[1],row,1,v[3])
	guiGridListSetItemData(GUIEditor.gridlist[1],row,2,v[2])
	guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255, 255, 255)
	guiGridListSetItemColor(GUIEditor.gridlist[1],row,2,255,255,0)
end


        PriceS = guiCreateLabel(10, 250, 223, 20, "Price : ", false, GUIEditor.window[1])
        GUIEditor.button[1] = guiCreateButton(10, 277, 223, 20, "شراء", false, GUIEditor.window[1])
        GUIEditor.button[2] = guiCreateButton(10, 307, 223, 19, "إغلاق", false, GUIEditor.window[1])
end
)

addEventHandler("onClientGUIClick",root,
	function ()
		AddUp = guiGridListGetItemData ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 1 )
		Name = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 1 )
		Price = guiGridListGetItemData ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 )
		sel = guiGridListGetSelectedItem ( GUIEditor.gridlist[1] )
		if source == GUIEditor.button[1] then
		if (sel == -1) then 
		outputChatBox("#ffffff* [ #ff0000Garage #ffffff] : #ffff00* قم بأختيار القطعة المراد شرائها",255,255,0,true)
		else
		triggerServerEvent( "BuyAddUP", localPlayer,Name,AddUp,Price )
		guiSetText(GUIEditor.button[1],"شراء")
		guiSetText(PriceS,"Price : ")
		guiGridListSetSelectedItem ( GUIEditor.gridlist[1], 0, 0) -- resets selection to zero
		end
		elseif source == GUIEditor.button[2] then
		guiSetVisible ( GUIEditor.window[1], false )
		showCursor(false)
		guiSetInputEnabled(false)
		setTimer ( setCameraTarget, 1000, 1, localPlayer , nil )
--		setTimer( setElementDimension, 1000, 1, localPlayer, 0 )
		fadeCamera(false)
		setTimer ( fadeCamera, 1000, 1, true)
		setElementFrozen(getPedOccupiedVehicle(localPlayer), false )
		setVehicleLocked ( getPedOccupiedVehicle(localPlayer), false )
		removeEventHandler ( "onClientPreRender", root, turn )
		
		if isElement ( ShowCar ) then destroyElement ( ShowCar ) end
		if ( isElement(ObjShow2) ) then destroyElement(ObjShow2) end
		if ( isElement(ObjShow1) ) then destroyElement(ObjShow1) end
		if ( isElement(ObjShow0) ) then destroyElement(ObjShow0) end
		if ( isElement(ObjShow) ) then destroyElement(ObjShow) end

		elseif source == GUIEditor.gridlist[1] then
		if (sel == -1) then 
		outputChatBox("#ffffff* [ #ff0000Garage #ffffff] : #ffff00* قم بأختيار القطعة المراد عرضها",255,255,0,true)
		guiSetText(PriceS,"Price : ")
		else
		guiSetText(PriceS,"Price : [ $"..convertNumber(Price).." ]")
		
		if ( isElement(ObjShow2) ) then destroyElement(ObjShow2) end
		if ( isElement(ObjShow1) ) then destroyElement(ObjShow1) end
		if ( isElement(ObjShow0) ) then destroyElement(ObjShow0) end
		if ( isElement(ObjShow) ) then destroyElement(ObjShow) end
		
		if AddUp == 0000 then
		local xPosition, yPosition, zPosition = getElementPosition( ShowCar )
		ObjShow0 = createObject(1274,xPosition, yPosition + 10 , zPosition )
		setObjectScale ( ObjShow0, 2)
		attachElements ( ObjShow0 , ShowCar, 0, 0,1.8)
		
		elseif AddUp == 0010 then
		local xPosition, yPosition, zPosition = getElementPosition( ShowCar )
		ObjShow2 = createObject(1254,xPosition, yPosition + 10 , zPosition )
		setObjectScale ( ObjShow2, 2)
		attachElements ( ObjShow2 , ShowCar, 0, 0,1.8)
		
		elseif AddUp == 0001 then
		local xPosition, yPosition, zPosition = getElementPosition( ShowCar )
		ObjShow = createObject(1318,xPosition, yPosition + 10 , zPosition )
		attachElements ( ObjShow , ShowCar, 0, 0,1.8)
		
		elseif AddUp == 0002 then
		local xPosition, yPosition, zPosition = getElementPosition( ShowCar )
		ObjShow1 = createObject(2780 , xPosition, yPosition, zPosition)
		attachElements(ObjShow1, ShowCar, 0,-1.4,-0.8,0,0,0)
		setElementAlpha(ObjShow1,0)
		
		elseif AddUp == 0003 then
		setVehiclePaintjob ( ShowCar, 0 )
		
		elseif AddUp == 0004 then
		setVehiclePaintjob ( ShowCar, 1 )
		
		elseif AddUp == 0005 then
		setVehiclePaintjob ( ShowCar, 2 )
		
		else
		
		if ( isElement(ObjShow) ) then destroyElement(ObjShow) end
		if ( isElement(ObjShow0) ) then destroyElement(ObjShow0) end
		if ( isElement(ObjShow1) ) then destroyElement(ObjShow1) end
		addVehicleUpgrade(ShowCar, AddUp)
		end
		end
	end
end 
)

function Show()
setElementFrozen(getPedOccupiedVehicle(localPlayer), true )
setVehicleLocked ( getPedOccupiedVehicle(localPlayer), true )
fadeCamera(false)
setTimer ( fadeCamera, 1000, 1, true)
ID = getElementModel ( getPedOccupiedVehicle(localPlayer) )
setTimer ( setCameraMatrix, 1000, 1, 1051.1801757813 , 1795.7447509766 , 17.008399963379 , 1052.0380859375 , 1795.3161621094 , 16.724836349487)
--setTimer( setElementDimension, 1000, 1, localPlayer, 0 )
ShowCar = createVehicle ( ID, 1056.42871, 1790.14746, 14.46689 , 0 , 0 , 301.83474731445 )
setElementFrozen(ShowCar, true )
local r1 , g1 , b1 , r2 , g2 , b2 , r3 , g3 , b3 , r4 , g4 , b4 = getVehicleColor ( getPedOccupiedVehicle(localPlayer) )
setVehicleColor( ShowCar, r1 , g1 , b1 , r2 , g2 , b2 , r3 , g3 , b3 , r4 , g4 , b4 )
--setTimer( setElementDimension, 1000, 1, ShowCar, 0 )
addEventHandler( "onClientPreRender", root, turn )
end

function turn()
	local rotX, rotY, rotZ = getElementRotation(ShowCar) -- get the local players's rotation
	setElementRotation(ShowCar,rotX,rotY,rotZ+0.35)
end

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end

Markers = { 
	{ 1032.87451, 1767.33728, 13.15637, 0, 0 },
	{ 1032.21130, 1756.16711, 13.15537, 0, 0 },
	{ 1032.41443, 1741.57874, 13.15537, 0, 0 },
	{ 1031.79333, 1728.11108, 13.15537, 0, 0 },
} 

for _ , v in ipairs ( Markers ) do 
	local aMarker = createMarker ( v [ 1 ] , v [ 2 ] , v [ 3 ] - 1 , 'cylinder' , 3 , 0 , 100 , 255 , 100 )
	setElementInterior( aMarker, v[4] )
	setElementDimension( aMarker, v[5] )
------------------
	addEventHandler ( 'onClientMarkerHit' , root ,
	function ( aPlayer )
		if ( aPlayer == localPlayer and source == aMarker and isPedInVehicle(localPlayer) ) then 
		local vehicle = getPedOccupiedVehicle( localPlayer )
		local driver = getVehicleController( vehicle )
		if driver == localPlayer then
            guiSetVisible(GUIEditor.window[1], true)
			guiSetEnabled(GUIEditor.button[2],false ) -- enable button if disabled. Disable if enabled
			setTimer( guiSetEnabled, 2000, 1, GUIEditor.button[2],true ) -- enable button if disabled. Disable if enabled
            showCursor(true)
			Show()
		end
		end
	end )
end 


Fix1 = createMarker(1079.31348, 1746.57593, 9.82031,"cylinder",2,255,0,0,100)
Fix2 = createMarker(1079.00562, 1741.13672, 9.82031,"cylinder",2,255,0,0,100)
Fix3 = createMarker(1078.10107, 1735.49963, 9.82031,"cylinder",2,255,0,0,100)
Ped1 = createPed(50,1079.37195, 1748.90625, 11.05781,160)
Ped2 = createPed(50,1079.12573, 1743.31384, 11.05781,160)
Ped3 = createPed(50,1078.95703, 1737.67749, 11.05781,160)
setElementFrozen(Ped1, true )
setElementFrozen(Ped2, true )
setElementFrozen(Ped3, true )
addEventHandler("onClientPedDamage",root,
function ()
if source == Ped1 then
	cancelEvent() 
elseif source == Ped2 then
	cancelEvent() 
elseif source == Ped3 then
	cancelEvent() 
end
end)

addEventHandler ( 'onClientMarkerHit' , root ,
function ( aPlayer )
	if ( aPlayer == localPlayer and isPedInVehicle(localPlayer) ) then 
		local driver = getVehicleController( getPedOccupiedVehicle( localPlayer ) )
		if driver == localPlayer then
			if source == Fix1 then
				FixMoney()
				setPedAnimation(Ped1,"cop_ambient","copbrowse_loop")
				setTimer(setPedAnimation,5000,1,Ped1)
			elseif source == Fix2 then
				FixMoney()
				setPedAnimation(Ped2,"cop_ambient","copbrowse_loop")
				setTimer(setPedAnimation,5000,1,Ped2)
			elseif source == Fix3 then
				FixMoney()
				setPedAnimation(Ped3,"cop_ambient","copbrowse_loop")
				setTimer(setPedAnimation,5000,1,Ped3)
			end
		end
	end
end )
function FixMoney()
	if tonumber(getPlayerMoney(localPlayer)) >= tonumber(5000) then
		takePlayerMoney( tonumber(5000) )
		setTimer( fixVehicle, 5000, 1, getPedOccupiedVehicle(localPlayer))
		setTimer( setElementFrozen, 200, 1, getPedOccupiedVehicle(localPlayer), true )
		setTimer( setElementFrozen, 5000, 1, getPedOccupiedVehicle(localPlayer), false )
		setTimer( outputChatBox, 5000, 1, "#ffffff* [ #ff0000Garage #ffffff] : [ #ffff00$"..convertNumber ( 5000 ).." #ffffff] وخصم [ #ffff00Fix#ffffff ] تم بنجاح شراء", 255,0,0,true)
	else
		outputChatBox( "#ffffff* [ #ff0000Garage #ffffff] : #ffff00* انت لا تملك المال الكأفي", 255,0,0,true)
	end
end
