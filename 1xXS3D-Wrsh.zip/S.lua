Obj = {}
ObjS = {}
Obj1 = {}
Obj2 = {}

Blips = { 
	{ 1037.17529, 1774.83752, 10.82031,27 },
	{ 1080.49365, 1764.46655, 10.23404,63 },
} 

for _ , v in ipairs ( Blips ) do 
	setBlipVisibleDistance ( createBlip ( v [ 1 ] , v [ 2 ] , v [ 3 ] , v [ 4 ] ) , 65535 )
end

addEvent("BuyAddUP",true)
addEventHandler("BuyAddUP",root,
function (Name,AddUp,Price)
  if isPedInVehicle(source) then
	if tonumber(getPlayerMoney(source)) >= tonumber(Price) then
		takePlayerMoney( source, tonumber(Price))
		if AddUp == 0000 then
		if ( isElement(Obj1[source]) ) then destroyElement (Obj1[source]) end
		if ( isElement(Obj2[source]) ) then destroyElement (Obj2[source]) end
		if ( isElement(Obj[source]) ) then destroyElement (Obj[source]) end
		local xPosition, yPosition, zPosition = getElementPosition( source )
		Obj1[source] = createObject(1274,xPosition, yPosition + 10 , zPosition )
		setObjectScale ( Obj1[source], 2)
		attachElements ( Obj1[source] , getPedOccupiedVehicle(source), 0, 0,1.8)
		
		elseif AddUp == 0010 then
		if ( isElement(Obj1[source]) ) then destroyElement (Obj1[source]) end
		if ( isElement(Obj2[source]) ) then destroyElement (Obj2[source]) end
		if ( isElement(Obj[source]) ) then destroyElement (Obj[source]) end
		local xPosition, yPosition, zPosition = getElementPosition( source )
		Obj2[source] = createObject(1254,xPosition, yPosition + 10 , zPosition )
		setObjectScale ( Obj2[source], 2)
		attachElements ( Obj2[source] , getPedOccupiedVehicle(source), 0, 0,1.8)
		
		elseif AddUp == 0001 then
		if ( isElement(Obj1[source]) ) then destroyElement (Obj1[source]) end
		if ( isElement(Obj2[source]) ) then destroyElement (Obj2[source]) end
		if ( isElement(Obj[source]) ) then destroyElement (Obj[source]) end
		local xPosition, yPosition, zPosition = getElementPosition( source )
		Obj[source] = createObject(1318,xPosition, yPosition + 10 , zPosition )
		attachElements ( Obj[source] , getPedOccupiedVehicle(source), 0, 0,1.8)
		
		elseif AddUp == 0002 then
		if ( isElement(ObjS[source]) ) then destroyElement (ObjS[source]) end
		local xPosition, yPosition, zPosition = getElementPosition( source )
		ObjS[source] = createObject(2780 , xPosition, yPosition, zPosition)
		attachElements(ObjS[source], getPedOccupiedVehicle(source), 0,-1.4,-0.8,0,0,0)
		setElementAlpha(ObjS[source],0)
		
		elseif AddUp == 0003 then
		setVehiclePaintjob ( getPedOccupiedVehicle(source), 0 )
		
		elseif AddUp == 0004 then
		setVehiclePaintjob ( getPedOccupiedVehicle(source), 1 )
		
		elseif AddUp == 0005 then
		setVehiclePaintjob ( getPedOccupiedVehicle(source), 2 )
		
		else
		addVehicleUpgrade(getPedOccupiedVehicle(source), AddUp)
		end
		outputChatBox( "#ffffff* [ #ff0000Garage #ffffff] : [ #ffff00$"..convertNumber ( Price ).." #ffffff] وخصم [ #ffff00"..Name.."#ffffff ] تم بنجاح شراء", source, 255,0,0,true)
		else
		outputChatBox( "#ffffff* [ #ff0000Garage #ffffff] : #ffff00* انت لا تملك المال الكأفي", source, 255,0,0,true)
		end
	end
end
)

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end

addEventHandler("onPlayerQuit",root,function ()
		if ( isElement(ObjS[source]) ) then destroyElement (ObjS[source]) end
		if ( isElement(Obj1[source]) ) then destroyElement (Obj1[source]) end
		if ( isElement(Obj2[source]) ) then destroyElement (Obj2[source]) end
		if ( isElement(Obj[source]) ) then destroyElement (Obj[source]) end
end)