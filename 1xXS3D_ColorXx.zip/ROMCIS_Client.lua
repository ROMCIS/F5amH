﻿function dev(center_window)
  local screenW, screenH = guiGetScreenSize()
  local windowW, windowH = guiGetSize(center_window, false)
  local x, y = (screenW - windowW) / 2, (screenH - windowH) / 2
  guiSetPosition(center_window, x, y, false)
end

local Rroot = getResourceRootElement(getThisResource())


S3D = {
    checkbox = {},
    window = {},
    button = {},
    checkbox = {},
    tabpanel = {},
    label = {},
    tab = {}
}

        S3D.window[1] = guiCreateWindow(0, 0, 358, 545, "=[ اختيار لون كلامك في الشات ]=", false)

        S3D.tabpanel[1] = guiCreateTabPanel(10, 30, 338, 482, false, S3D.window[1])

        S3D.tab[1] = guiCreateTab("=[ الوان الشات 1 ]=", S3D.tabpanel[1])

        S3D.checkbox[1] = guiCreateCheckBox(28, 20, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[2] = guiCreateCheckBox(28, 63, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[3] = guiCreateCheckBox(28, 106, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[4] = guiCreateCheckBox(28, 148, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[5] = guiCreateCheckBox(28, 192, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[6] = guiCreateCheckBox(28, 237, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[7] = guiCreateCheckBox(28, 279, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[8] = guiCreateCheckBox(28, 323, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[9] = guiCreateCheckBox(28, 366, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[10] = guiCreateCheckBox(210, 20, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.label[1] = guiCreateLabel(14, 404, 318, 49, "mmm.f5amh.com", false, S3D.tab[1])

        S3D.tab[2] = guiCreateTab("=[ الوان الشات 2 ]=", S3D.tabpanel[1])
        S3D.checkbox[11] = guiCreateCheckBox(210, 63, 113, 23, "=[ اختيار اللون ]=", true, false, S3D.tab[1])
        S3D.checkbox[12] = guiCreateCheckBox(210, 111, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[13] = guiCreateCheckBox(210, 157, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[14] = guiCreateCheckBox(210, 198, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[15] = guiCreateCheckBox(210, 242, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[16] = guiCreateCheckBox(210, 279, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[17] = guiCreateCheckBox(209, 323, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])
        S3D.checkbox[18] = guiCreateCheckBox(209, 366, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[1])

        S3D.checkbox[19] = guiCreateCheckBox(28, 20, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[20] = guiCreateCheckBox(28, 63, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[21] = guiCreateCheckBox(28, 106, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[22] = guiCreateCheckBox(28, 148, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[23] = guiCreateCheckBox(28, 192, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[24] = guiCreateCheckBox(28, 237, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[25] = guiCreateCheckBox(28, 279, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[26] = guiCreateCheckBox(28, 323, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[27] = guiCreateCheckBox(28, 366, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[28] = guiCreateCheckBox(210, 20, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[29] = guiCreateCheckBox(210, 63, 113, 23, "=[ اختيار اللون ]=", true, false, S3D.tab[2])
        S3D.checkbox[30] = guiCreateCheckBox(210, 111, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[31] = guiCreateCheckBox(210, 157, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[32] = guiCreateCheckBox(210, 198, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[33] = guiCreateCheckBox(210, 242, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[34] = guiCreateCheckBox(210, 279, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[35] = guiCreateCheckBox(209, 323, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])
        S3D.checkbox[36] = guiCreateCheckBox(209, 366, 113, 23, "=[ اختيار اللون ]=", false, false, S3D.tab[2])

S3D.label[3] = guiCreateLabel(14, 404, 318, 49, "mmm.f5amh.com", false, S3D.tab[2])
        S3D.label[2] = guiCreateLabel(10, 518, 229, 18, "By: MR.A7SAS & MR.S3D & Mr.Pres[T]ege", false, S3D.window[1])
        S3D.button[1] = guiCreateButton(249, 518, 96, 16, "X", false, S3D.window[1])

local dev_chat ={
[S3D.checkbox[1]]= '#9ACD32',
[S3D.checkbox[2]]= '#FFFF00',
[S3D.checkbox[3]]= '#F5F5F5',
[S3D.checkbox[4]]= '#F5DEB3',
[S3D.checkbox[5]]= '#EE82EE',
[S3D.checkbox[6]]= '#40E0D0',
[S3D.checkbox[7]]= '#FF6347',
[S3D.checkbox[8]]= '#D8BFD8',
[S3D.checkbox[9]]= '#008080',
[S3D.checkbox[10]]= '#D2B48C',
[S3D.checkbox[11]]= '#4682B4',
[S3D.checkbox[12]]= '#00FF7F',
[S3D.checkbox[13]]= '#708090',
[S3D.checkbox[14]]= '#6A5ACD',
[S3D.checkbox[15]]= '#87CEEB',
[S3D.checkbox[16]]= '#A0522D',
[S3D.checkbox[17]]= '#2E8B57',
[S3D.checkbox[18]]= '#F4A460',
[S3D.checkbox[19]]= '#FA8072',
[S3D.checkbox[20]]= '#4169E1',
[S3D.checkbox[21]]= '#BC8F8F',
[S3D.checkbox[22]]= '#FF0000',
[S3D.checkbox[23]]= '#663399',
[S3D.checkbox[24]]= '#800080',
[S3D.checkbox[25]]= '#B0E0E6',
[S3D.checkbox[26]]= '#DDA0DD',
[S3D.checkbox[27]]= '#FFC0CB',
[S3D.checkbox[28]]= '#CD853F',
[S3D.checkbox[29]]= '#AFEEEE',
[S3D.checkbox[30]]= '#98FB98',
[S3D.checkbox[31]]= '#4682B4',
[S3D.checkbox[32]]= '#00FF7F',
[S3D.checkbox[33]]= '#708090',
[S3D.checkbox[34]]= '#6A5ACD',
[S3D.checkbox[35]]= '#87CEEB',
[S3D.checkbox[36]]= '#A0522D',
}

addEventHandler('onClientGUIClick',resourceRoot,function()
if getElementType(source)=='gui-checkbox' then
for k,v in ipairs(getElementsByType('gui-checkbox',resourceRoot))do
guiCheckBoxSetSelected(v,false)
end	
guiCheckBoxSetSelected(source,true)	
triggerServerEvent('Dev_setmessagecolor',localPlayer,dev_chat[source])
end end)

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 0.80)
guiSetProperty(S3D.window[1], "CaptionColour", "FFFEEF00")
guiSetAlpha(S3D.tab[1], 0.94)
dev(S3D.window[1])
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
        guiSetFont(S3D.button[1], "default-bold-small")
        guiSetProperty(S3D.button[1], "NormalTextColour", "FFFEFEFE")    
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
        guiSetFont(S3D.label[1], "sa-header")
        guiSetFont(S3D.label[3], "sa-header")
end
for _, v in ipairs(getElementsByType('gui-checkbox',Rroot)) do
guiSetFont(v, "default-bold-small")
guiSetProperty(S3D.checkbox[1], "NormalTextColour",'ff9ACD32')
guiSetProperty(S3D.checkbox[2], "NormalTextColour",'ffFFFF00')
guiSetProperty(S3D.checkbox[3], "NormalTextColour",'ffF5F5F5')
guiSetProperty(S3D.checkbox[4], "NormalTextColour",'ffF5DEB3')
guiSetProperty(S3D.checkbox[5], "NormalTextColour",'ffEE82EE')
guiSetProperty(S3D.checkbox[6], "NormalTextColour",'ff40E0D0')
guiSetProperty(S3D.checkbox[7], "NormalTextColour",'ffFF6347')
guiSetProperty(S3D.checkbox[8], "NormalTextColour",'ffD8BFD8')
guiSetProperty(S3D.checkbox[9], "NormalTextColour",'ff008080')
guiSetProperty(S3D.checkbox[10], "NormalTextColour",'ffD2B48C')
guiSetProperty(S3D.checkbox[11], "NormalTextColour",'ff4682B4')
guiSetProperty(S3D.checkbox[12], "NormalTextColour",'ff00FF7F')
guiSetProperty(S3D.checkbox[13], "NormalTextColour",'ff708090')
guiSetProperty(S3D.checkbox[14], "NormalTextColour",'ff6A5ACD')
guiSetProperty(S3D.checkbox[15], "NormalTextColour",'ff87CEEB')
guiSetProperty(S3D.checkbox[16], "NormalTextColour",'ffA0522D')
guiSetProperty(S3D.checkbox[17], "NormalTextColour",'ff2E8B57')
guiSetProperty(S3D.checkbox[18], "NormalTextColour",'ffF4A460')
guiSetProperty(S3D.checkbox[19], "NormalTextColour",'ffFA8072')
guiSetProperty(S3D.checkbox[20], "NormalTextColour",'ff4169E1')
guiSetProperty(S3D.checkbox[21], "NormalTextColour",'ffBC8F8F')
guiSetProperty(S3D.checkbox[22], "NormalTextColour",'ffFF0000')
guiSetProperty(S3D.checkbox[23], "NormalTextColour",'ff663399')
guiSetProperty(S3D.checkbox[24], "NormalTextColour",'ff800080')
guiSetProperty(S3D.checkbox[25], "NormalTextColour",'ffB0E0E6')
guiSetProperty(S3D.checkbox[26], "NormalTextColour",'ffDDA0DD')
guiSetProperty(S3D.checkbox[27], "NormalTextColour",'ffFFC0CB')
guiSetProperty(S3D.checkbox[28], "NormalTextColour",'ffCD853F')
guiSetProperty(S3D.checkbox[29], "NormalTextColour",'ffAFEEEE')
guiSetProperty(S3D.checkbox[30], "NormalTextColour",'ff98FB98')
guiSetProperty(S3D.checkbox[31], "NormalTextColour",'ff4682B4')
guiSetProperty(S3D.checkbox[32], "NormalTextColour",'ff00FF7F')
guiSetProperty(S3D.checkbox[33], "NormalTextColour",'ff708090')
guiSetProperty(S3D.checkbox[34], "NormalTextColour",'ff6A5ACD')
guiSetProperty(S3D.checkbox[35], "NormalTextColour",'ff87CEEB')
guiSetProperty(S3D.checkbox[36], "NormalTextColour",'ffA0522D')
end end )

addCommandHandler("لون", function()
guiSetVisible(S3D.window[1],not guiGetVisible(S3D.window[1])) 
showCursor(guiGetVisible(S3D.window[1])) 
end )

addEventHandler("onClientGUIClick",root, 
function() 
if source == S3D.button[1] then 
guiSetVisible(S3D.window[1],false) 
guiSetInputEnabled(false) 
showCursor(false)
end end )