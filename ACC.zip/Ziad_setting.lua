﻿Wnd = ":: F5amh Accounts ::"

Ziad = "bit.do/F5amh"

Ziad1 = "https://discord.gg/sG44g5p"

Ziad2 = "Add Soon"

Server = "@F5amh"

addCommandHandler('تواصل',

	function ( )

		guiSetVisible(Ziad_wnd, not guiGetVisible(Ziad_wnd))

		showCursor(guiGetVisible(Ziad_wnd))

	end 

)
