﻿local Rroot = getResourceRootElement(getThisResource())

S3D = {
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}

S3D.window[1] = guiCreateStaticImage(472, 305, 448, 294, ":F9/wnd.png", false)
S3D.label[1] = guiCreateLabel(10, 269, 176, 15, "@F5amh | | Beta Version", false, S3D.window[1]) 
S3D.gridlist[1] = guiCreateGridList(10, 15, 229, 227, false, S3D.window[1])
guiGridListAddColumn(S3D.gridlist[1], "Car", 0.4)
guiGridListAddColumn(S3D.gridlist[1], "$", 0.3)
guiGridListAddColumn(S3D.gridlist[1], "id", 0.3)
guiGridListAddRow(S3D.gridlist[1])
-- guiGridListSetItemText(S3D.gridlist[1], 0, 1, "Lexus GS-F", false, false)
-- guiGridListSetItemColor(S3D.gridlist[1], 0, 1, 0, 254, 251, 255)
-- guiGridListSetItemText(S3D.gridlist[1], 0, 2, "3500000", false, false)
-- guiGridListSetItemColor(S3D.gridlist[1], 0, 2, 0, 254, 0, 255)
-- guiGridListSetItemText(S3D.gridlist[1], 0, 3, "529", false, false)
-- guiGridListSetItemColor(S3D.gridlist[1], 0, 3, 245, 253, 0, 255)
guiSetFont(S3D.gridlist[1], "default-bold-small")
guiSetAlpha(S3D.gridlist[1], 0.88)
S3D.button[1] = guiCreateButton(264, 25, 153, 28, ":: انزال السيارة ::", false, S3D.window[1])
S3D.button[2] = guiCreateButton(264, 63, 153, 28, ":: سحب السيارة ::", false, S3D.window[1])
S3D.button[3] = guiCreateButton(264, 101, 153, 28, ":: بيع السيارة ::", false, S3D.window[1])
S3D.button[4] = guiCreateButton(264, 139, 153, 28, ":: انتقال للمعرض ::", false, S3D.window[1])
button5 = guiCreateButton(264, 177, 153, 64, "", false, S3D.window[1]) 
-- gridlist2 = guiCreateGridList(264, 177, 153, 64, false, S3D.window[1])
guiSetAlpha(gridlist2, 1)
checkbox1 = guiCreateCheckBox(10, 10, 90, 15, ":: فتح الموتر ::", false, false, button5)
guiSetProperty(checkbox1, "NormalTextColour", "FFFF0000")
guiSetFont(checkbox1, "default-bold-small")
checkbox2 = guiCreateCheckBox(10, 39, 90, 15, ":: حماية الموتر ::", false, false, button5) 
guiSetProperty(checkbox2, "NormalTextColour", "FFFF0000")
guiSetFont(checkbox2, "default-bold-small") 

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(S3D.window[1], false)
guiWindowSetSizable(S3D.window[1], false)
guiSetAlpha(S3D.window[1], 1)
guiSetProperty(S3D.window[1], "CaptionColour", "FF00FED7")
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, "NormalTextColour", "FF0088F1")
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(v, "default-bold-small")
guiLabelSetColor(v, 255, 255, 255)
end end ) 

addEventHandler("onClientGUIClick", resourceRoot,
function()
if source == checkbox1 then
if guiCheckBoxGetSelected (source) then 
outputChatBox('تم فتح السيارة',50,255,0,true)
    else 
outputChatBox('تم اغلاق السيارة',50,255,0,true)
  end
elseif source == checkbox2 then 
executeCommandHandler ( "" ) 
if guiCheckBoxGetSelected (source) then
outputChatBox('تم تشغيل حماية السيارة',50,255,0,true)
    else 
outputChatBox('تم ايقاف حماية السيارة',50,255,0,true)
  end
end
end
)

addEventHandler("onClientGUIClick", resourceRoot,
function()
if source == S3D.button[1] then 
outputChatBox('قم بتحديد السيارة من القائمة',255,0,0,true)
elseif source == S3D.button[2] then 
outputChatBox('قم بانزال السيارة اولا',50,255,0,true)
elseif source == S3D.button[3] then 
outputChatBox('ليس لديك سيارة',255,0,0,true)
triggerServerEvent("onLock",localPlayer)
end
end
)

addEventHandler("onClientGUIClick", resourceRoot,
function()
if source == S3D.button[4] then 
if isPedInVehicle(localPlayer) then return end
					fadeCamera( false )
		setTimer( fadeCamera, 1500, 1, true )
		setTimer( setElementPosition, 1500, 1, localPlayer,-1641.81140,1204.49146,7.25156)
end
end
)

addEvent( 'Open_S3D', true )
addEventHandler( 'Open_S3D', root,
function()
        guiSetVisible(S3D.window[1], not guiGetVisible (S3D.window[1]))
        showCursor(guiGetVisible(S3D.window[1]))
end
)
 
--- function Ziad( )
--- guiSetVisible( S3D.window[1], not guiGetVisible( S3D.window[1] ) )
--- --- showCursor( guiGetVisible( S3D.window[1] ) )
--- end
--- bindKey ( "F5", "down",Ziad)

function openWindowT()
player = getLocalPlayer()
triggerServerEvent("s3d:Time",localPlayer,player)
end
bindKey("f5", "down", openWindowT)