function getPlayerTime ( Player )
	local TimeData = getElementData(Player,'PlayTime') or '0:0';
	if ( TimeData ) then
		return tonumber(split(TimeData,':')[1]) , tonumber(split(TimeData,':')[2]);
	end 
end



addEvent('s3d:Time',true)
addEventHandler('s3d:Time',root,
function ()
		local hour , mintue = getPlayerTime ( source ) -- نجيب ساعاته
		if ( hour >= 50 ) then -- نتحقق ان الساعات 40 او اكثر
			triggerClientEvent(source, "Open_S3D", source)
		else -- في حال الساعات اقل من 40 لن تفتح اللوحة
			outputChatBox("Sorry, you can't speak because your time less than 5 hours",source)
			cancelEvent()
	end 
end)