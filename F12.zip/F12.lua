﻿buttons = {
    ['F12'] = true,
}
 
addEventHandler( 'onClientKey', root, function (button , prees)
    if prees then
        if buttons[button] then
			exports.infobox:outputMessage("[F5amh]: تم تصوير الشاشة ",255,255,0,true)
		end
	end
end)