function centerWindow(center_window)
    local screenW,screenH=guiGetScreenSize()
    local windowW,windowH=guiGetSize(center_window,false)
    local x,y = (screenW-windowW)/2,(screenH-windowH)/2
    guiSetPosition(center_window,x,y,false)
end


GUIEditor = {
    edit = {},
    button = {},
    window = {},
    label = {},
    gridlist = {}
}

Inventory = {
----Name Arabic , Data
		{"Cash" , "Cash" },
		{"Med Kit" , "Med Kit" },
		{"FirstAid Kit" , "FirstAid Kit" },
		{"Bandage" , "Bandage" },
		{"Adrenaline" , "Adrenaline" },
		{"PainKiller" , "PainKiller" },
		{"Energy Drink" , "Energy Drink" },
		{"Cigar" , "Cigar" },
		{"حشيش" , "bea3weed" },
}

Crafting = {
----Name Arabic , Data , Requested
		{"Cigar" , "Cigar" , "Weed" , 5 },
}

local screenW, screenH = guiGetScreenSize()
addEventHandler("onClientResourceStart", resourceRoot,
    function()
        GUIEditor.window[1] = guiCreateWindow(10, (screenH - 283) / 2, 427, 283, "المخزن 'و' الصناعة", false)
		guiSetVisible(GUIEditor.window[1],false)
        guiSetProperty(GUIEditor.window[1], "CaptionColour", "FFFEBB37")
		 guiSetAlpha( GUIEditor.window[1], 0 ) 
----tab's
        TabCrafting = guiCreateLabel(214, 21, 203, 15, "+ Crafting | الصناعة", false, GUIEditor.window[1])
        guiSetFont(TabCrafting, "default-bold")
        guiLabelSetColor(TabCrafting, 197, 86, 255)
        guiLabelSetHorizontalAlign(TabCrafting, "center", false)
        guiLabelSetVerticalAlign(TabCrafting, "center")
        TabInentroy = guiCreateLabel(10, 21, 203, 15, "+ Inventory | المخزن", false, GUIEditor.window[1])
        guiSetFont(TabInentroy, "default-bold")
        guiLabelSetColor(TabInentroy, 103, 254, 87)
        guiLabelSetHorizontalAlign(TabInentroy, "center", false)
        guiLabelSetVerticalAlign(TabInentroy, "center")
---------Craft
        WindowCrafting = guiCreateLabel(10, 36, 407, 237, "", false, GUIEditor.window[1])
		guiSetVisible(WindowCrafting,false)

        GridCraft = guiCreateGridList(2, 4, 194, 229, false, WindowCrafting)
        guiGridListAddColumn(GridCraft, "Crafting", 0.9)
	for i,v in ipairs( Crafting )do
		local cRow = guiGridListAddRow( GridCraft )
		guiGridListSetItemText( GridCraft, cRow, 1, v[1], false, false )
		guiGridListSetItemData( GridCraft, cRow, 1, {v[2],v[3],v[4]} )
		guiGridListSetItemColor(GridCraft, cRow ,1,255,155,100,255)
        guiSetFont(GridCraft, "default-bold")
	end
        Requset = guiCreateLabel(206, 4, 197, 18, "المتطلبات :", false, WindowCrafting)
        guiSetFont(Requset, "default-bold")
        guiLabelSetColor(Requset, 63, 255, 167)
        guiLabelSetHorizontalAlign(Requset, "right", false)
        InfoCraft = guiCreateLabel(206, 22, 197, 187, "", false, WindowCrafting)
		guiSetFont(InfoCraft, "default-bold")
        guiLabelSetHorizontalAlign(InfoCraft, "right", false)
        Craft = guiCreateButton(206, 214, 198, 19, "صناعة", false, WindowCrafting)
        guiSetFont(Craft, "default-bold")
        guiSetProperty(Craft, "NormalTextColour", "FFFFF11D")    
-------inve
        WindowInventory = guiCreateLabel(10, 36, 407, 237, "", false, GUIEditor.window[1])
		guiSetVisible(WindowInventory,false)

        GridInve = guiCreateGridList(9, 5, 248, 208, false, WindowInventory)
        guiGridListAddColumn(GridInve, "My Inventory", 0.52)
        guiGridListAddColumn(GridInve, "Amount", 0.38)
        Photo = guiCreateStaticImage(267, 22, 140, 140, "Img/BackpackLVL1.png", false, WindowInventory)
        Use = guiCreateButton(267, 155, 140, 20, "Use | استخدام", false, WindowInventory)
        guiSetFont(Use, "default-bold") 	
        guiSetProperty(Use, "NormalTextColour", "FFFEBB37")
        Drop = guiCreateButton(267, 213, 140, 20, "Drop | رمي", false, WindowInventory)  
        guiSetFont(Drop, "default-bold") 
        guiSetProperty(Drop, "NormalTextColour", "FFFE3636")		
        AmountDrop = guiCreateEdit(267, 185, 102, 18, "0", false, WindowInventory)
        guiEditSetMaxLength(AmountDrop, 8)
        LabelDrop = guiCreateLabel(369, 185, 38, 18, "الكمية :", false, WindowInventory)
        guiLabelSetColor(LabelDrop, 254, 54, 54)
        guiSetFont(LabelDrop, "default-bold") 	
        Backpack = guiCreateLabel(9, 218, 139, 15, "Your Backpack:", false, WindowInventory)
        guiSetFont(Backpack, "default-bold")
        guiLabelSetColor(Backpack, 254, 224, 83)
        showBackpack = guiCreateCheckBox(148, 218, 108, 15, "الحقيبة", false, false, WindowInventory)
        guiSetFont(showBackpack, "default-bold")    
    end
)
 

function Panel(  ) 
if ( getElementInterior(localPlayer) == 6 ) or ( getElementInterior(localPlayer) == 3 ) or ( getElementDimension(localPlayer) == 511 ) or ( getElementDimension(localPlayer) == 1945 ) or ( getElementDimension(localPlayer) ~= 0 ) or ( getElementData( localPlayer,"RobHouse" ) == true )then return end

if getElementData(localPlayer, "Sa7t7rb") == true then return end
guiSetVisible( GUIEditor.window[1], true ) 
unbindKey( 'F4', 'down', Panel)
centerWindow( GUIEditor.window[1] )
    if ( guiGetVisible( GUIEditor.window[1] ) == true and guiGetAlpha( GUIEditor.window[1] ) == 0 ) then 
        AlphaTimer = setTimer( function( ) 
            local currentAlpha = guiGetAlpha ( GUIEditor.window[1] ) 
                guiSetAlpha( GUIEditor.window[1], currentAlpha + 0.1 ) 
                    if ( currentAlpha == 1.00 ) then 
					if guiGetVisible(WindowCrafting) == true then guiSetVisible(WindowCrafting,false) end
                        killTimer( AlphaTimer ) 
						showCursor(true)
						playSoundFrontEnd ( 1 )
						bindKey( 'F4', 'down', Panel)
						Refresh()
						guiSetInputMode("no_binds") 
						guiSetVisible(WindowInventory,true)
                        end 
                        end, 10, 0 ) 
                    else if ( guiGetVisible( GUIEditor.window[1] ) == true and guiGetAlpha( GUIEditor.window[1] ) == 1.00 ) then 
					if isTimer(AlphaTimer) then killTimer(AlphaTimer) end
					guiSetInputMode("allow_binds")
                guiSetVisible( GUIEditor.window[1], false ) 
            guiSetAlpha( GUIEditor.window[1], 0 ) 
			showCursor(false)
			bindKey( 'F4', 'down', Panel)
        end 
    end 
end 
bindKey( 'F4', 'down', Panel)

function Refresh()
	if getElementData(localPlayer,"Backpack") then
	guiSetText(Backpack,"Your Backpack: "..tostring(getElementData(localPlayer,"Backpack")))
	guiStaticImageLoadImage(Photo,"Img/Backpack"..tostring(getElementData(localPlayer,"Backpack"))..".png")
	guiSetEnabled(showBackpack,true)
	end
	guiGridListClear(GridInve)
	local sRow = guiGridListAddRow(GridInve)
	guiGridListSetItemText(GridInve, sRow , 1, "ممتلكاتي", true, false)
	-- guiGridListSetItemColor(GridInve, sRow ,1,255,155,0,255)
	guiGridListSetItemColor(GridInve, sRow ,1,255,185,55,255)
	for i,v in ipairs( Inventory )do
		if not getElementData(localPlayer,v[2]) or getElementData(localPlayer,v[2]) == 0 then
			else
			local gRow = guiGridListAddRow( GridInve )
			guiGridListSetItemText( GridInve, gRow, 1, v[1], false, false )
			guiGridListSetItemData( GridInve, gRow, 1, v[2] )
			guiGridListSetItemText( GridInve, gRow, 2, convertNumber(getElementData(localPlayer,v[2])) , false, true )
			guiGridListSetItemData( GridInve, gRow, 2, getElementData(localPlayer,v[2]) )
			guiGridListSetItemColor(GridInve, gRow ,1,255,100,100,255)
		end
		if getPlayerMoney() > 0 then
			if v[2] == "Cash" then
			local gRow = guiGridListAddRow( GridInve )
			guiGridListSetItemText( GridInve, gRow, 1, v[1], false, false )
			guiGridListSetItemData( GridInve, gRow, 1, v[2] )
			guiGridListSetItemText( GridInve, gRow, 2, "$"..convertNumber(getPlayerMoney()), false, true )
			guiGridListSetItemData( GridInve, gRow, 2, getPlayerMoney() )
			guiGridListSetItemColor(GridInve, gRow ,1, 100,255,100,255)
			end
		end
	end
-----
	local wRow = guiGridListAddRow(GridInve)
	guiGridListSetItemText(GridInve, wRow, 1, "أسلحتي", true, false)
	guiGridListSetItemColor(GridInve, wRow ,1,255,185,55,255)


		for slot = 0, 12 do 
			local weapon = getPedWeapon ( localPlayer, slot ) 
			local ammo = getPedTotalAmmo ( localPlayer, slot )			
		if ( weapon > 0 ) and ( ammo > 0 ) then
			local gRow = guiGridListAddRow( GridInve )
			guiGridListSetItemText( GridInve, gRow, 1, getWeaponNameFromID(weapon), false, false )
			guiGridListSetItemData( GridInve, gRow, 1, weapon )
			guiGridListSetItemText( GridInve, gRow, 2, convertNumber(ammo) , false, true )
			guiGridListSetItemData( GridInve, gRow, 2, ammo )
			guiGridListSetItemColor(GridInve, gRow ,1,100,100,255,255)
		end
	end
-----
end
addEvent("InveRefresh",true)
addEventHandler("InveRefresh",root,Refresh)

addEventHandler("onClientGUIClick",root,function()
local row, col = guiGridListGetSelectedItem (GridInve)
local Edit = guiGetText(AmountDrop)
local NameWP = guiGridListGetItemText(GridInve,row,1)
local Name = guiGridListGetItemData(GridInve,row,1)
local Value = guiGridListGetItemData(GridInve,row,2)
if( row and col and row ~= -1 and col ~= -1 )then
if source == Use then
triggerServerEvent("InveUse",localPlayer,Name)
elseif source == Drop then
triggerServerEvent("InveDrop",localPlayer,Name,Edit)
Refresh()
guiSetText(AmountDrop, 0)
end
if source == GridInve then
if NameWP ~= Name then
triggerServerEvent("ChangeWeapon",localPlayer,NameWP)
end
if fileExists("Img/"..Name..".png") then
guiStaticImageLoadImage(Photo,"Img/"..Name..".png")
else
guiStaticImageLoadImage(Photo,"Img/Backpack"..tostring(getElementData(localPlayer,"Backpack"))..".png")
end
guiSetText(AmountDrop, 0)
end
else
guiStaticImageLoadImage(Photo,"Img/Backpack"..tostring(getElementData(localPlayer,"Backpack"))..".png")
end
if source == showBackpack then
if guiCheckBoxGetSelected(showBackpack) == true then
setElementData(localPlayer,"ShowBP",true)
guiSetProperty(showBackpack, "NormalTextColour", "FF00FF00")
else
guiSetProperty(showBackpack, "NormalTextColour", "FFFFFFFF")
setElementData(localPlayer,"ShowBP",false)
end
end
end
)

addEventHandler("onClientGUIClick",root,function()
local row, col = guiGridListGetSelectedItem (GridCraft)
if( row and col and row ~= -1 and col ~= -1 )then
local Name , Req, Amount = unpack(guiGridListGetItemData(GridCraft,row,1))
if source == Craft then
triggerServerEvent("Craft",localPlayer,Name)
end
if source == GridCraft then
guiSetText(InfoCraft,Req.." : "..Amount.." | You Have ("..tostring(getElementData(localPlayer,Req))..")")
end
else
guiSetText(InfoCraft,"")
end
if source == TabCrafting then
guiSetVisible(WindowCrafting,true)
if guiGetVisible(WindowInventory) == true then guiSetVisible(WindowInventory,false) end
elseif source == TabInentroy then
guiSetVisible(WindowInventory,true)
if guiGetVisible(WindowCrafting) == true then guiSetVisible(WindowCrafting,false) end
end
end
)

addEventHandler("onClientGUIChanged",resourceRoot,
function()
local row, col = guiGridListGetSelectedItem (GridInve)
local Edit = guiGetText(AmountDrop)
local Value = guiGridListGetItemData(GridInve,row,2)
if( row and col and row ~= -1 and col ~= -1 )then
if source == AmountDrop then
if tonumber(Edit) == nil or isHasSpace(Edit) or tonumber(Edit) < 0 or tonumber(Value) < 0 then
guiSetText(AmountDrop, 0)
elseif tonumber(Edit) > Value then
guiSetText(AmountDrop, tonumber(math.ceil(Value)))
else
guiSetText(AmountDrop, tonumber(math.ceil(Edit)))
end
end
else
guiSetText(AmountDrop, 0)
end
end
)

function isHasSpace(text)
    for i = 1, #text do
        local byte = text:byte(i)
        if(byte == 32)then
            return true
        end
    end
    return false
end

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end

addEventHandler("onClientRender", root,
function ()
if getElementData(localPlayer,"itemTextDx") then
	local NamePlayer ,itemName , itemValue = unpack(getElementData(localPlayer,"itemTextDx"))
	if itemName == "Cash" then
	dxDrawText("Press 'X' To Take: "..itemName.." ($".. convertNumber(itemValue)..")\nFrom: "..string.gsub(NamePlayer,"#%x%x%x%x%x%x","") or NamePlayer, 10 + 1, 291 + 1, 361 + 1, 309 + 1, tocolor(0, 0, 0, 255), 1.00, "default", "left", "top", false, false, false, true, false)
	dxDrawText("Press 'X' To Take: #FBDDBB"..itemName.." #00ff00($".. convertNumber(itemValue)..")\nFrom: #FBDDBB"..NamePlayer, 10, (screenH - 18) / 2, (10) + 351, ( (screenH - 18) / 2) + 18, tocolor(0, 255, 0, 255), 1.00, "default", "left", "top", false, false, true, true, false)
	else
	dxDrawText("Press 'X' To Take: "..itemName.." (".. convertNumber(itemValue)..")\nFrom: "..string.gsub(NamePlayer,"#%x%x%x%x%x%x","") or NamePlayer, 10 + 1, 291 + 1, 361 + 1, 309 + 1, tocolor(0, 0, 0, 255), 1.00, "default", "left", "top", false, false, false, true, false)
	dxDrawText("Press 'X' To Take: #FBDDBB"..itemName.." #00ff00(".. convertNumber(itemValue)..")\nFrom: #FBDDBB"..NamePlayer, 10, (screenH - 18) / 2, (10) + 351, ( (screenH - 18) / 2) + 18, tocolor(0, 255, 0, 255), 1.00, "default", "left", "top", false, false,true, true, false)
end
end
end
)

-----------Loading
        Lbl = guiCreateLabel(0.34, 0.74, 0.32, 0.04, "", true)
		guiSetVisible(Lbl,false)
        Loading = guiCreateProgressBar(-8, -4, 276, 30, false, Lbl)
        guiSetAlpha(Loading, 0.80)
        LblItem = guiCreateLabel(10, 6, 250, 18, "", false, Loading)
        guiSetFont(LblItem, "default-bold")
        guiLabelSetColor(LblItem, 0, 0, 0)
        guiLabelSetHorizontalAlign(LblItem, "center", false)
        guiLabelSetVerticalAlign(LblItem, "center")    

addEvent("LoadingUse",true)
addEventHandler("LoadingUse",root,
function(Item,Sec,Type)
guiSetVisible(Lbl,true)
guiSetEnabled(Use, false)
guiSetText(Use,"فضلاً أنتظر")
guiProgressBarSetProgress(Loading,0)
if Type == "Craft" then
guiSetText(LblItem,"Craft "..Item)
elseif Type == "Use" then
guiSetText(LblItem,"Use "..Item)
end
if Sec == 4 then
SetLoad = 400
elseif Sec == 5 then
SetLoad = 500
elseif Sec == 6 then
SetLoad = 600
elseif Sec == 8 then
SetLoad = 800
end
setTimer(guiProgressBarSetProgress,SetLoad,1,Loading,10)
setTimer(guiProgressBarSetProgress,SetLoad*2,1,Loading,20)
setTimer(guiProgressBarSetProgress,SetLoad*3,1,Loading,30)
setTimer(guiProgressBarSetProgress,SetLoad*4,1,Loading,40)
setTimer(guiProgressBarSetProgress,SetLoad*5,1,Loading,50)
setTimer(guiProgressBarSetProgress,SetLoad*6,1,Loading,60)
setTimer(guiProgressBarSetProgress,SetLoad*7,1,Loading,70)
setTimer(guiProgressBarSetProgress,SetLoad*8,1,Loading,80)
setTimer(guiProgressBarSetProgress,SetLoad*9,1,Loading,90)
setTimer(guiProgressBarSetProgress,SetLoad*10,1,Loading,100)
setTimer(guiSetEnabled, SetLoad*10,1, Use, true)
setTimer(guiSetText, SetLoad*10,1, Use,"Use | استخدام")
setTimer(guiSetVisible,SetLoad*10.5,1,Lbl,false)
end
)


local Models = { 
[1] = { "Models/BP1" , 371 } , 
[2] = { "Models/BP2" , 1248 } , 
[3] = { "Models/BP3" , 1252 } ,  
}

function OnStart ()
	for k,v in ipairs ( Models ) do 
		downloadFile(v[1]..".txd")
		downloadFile(v[1]..".dff")
			setTimer(function()
				txd = engineLoadTXD ( tostring ( v [ 1 ] )..".txd" )
				engineImportTXD ( txd, tonumber ( v [ 2 ] ) )
				dff = engineLoadDFF ( tostring ( v [1] )..".dff", tonumber ( v [ 2 ] ) )
				engineReplaceModel ( dff, tonumber ( v [ 2 ] ) )
			end,60*1000,1)
	end
end
addEventHandler ( "onClientResourceStart", resourceRoot, OnStart )