Store = {
	{"Backpack.3" , "Backpack3",90000,"الاسم: Backpack Lvl.3 \nالنوع: اضافة \nالوصف: زيادة مساحة\nالحقيبة 20 لكل قطعة"},
	{"Backpack.2" , "Backpack2",60000,"الاسم: Backpack Lvl.2 \nالنوع: اضافة \nالوصف: زيادة مساحة\nالحقيبة 15 لكل قطعة" },
	{"Backpack.1" , "Backpack1",30000,"الاسم: Backpack Lvl.1 \nالنوع: اضافة \nالوصف: زيادة مساحة\nالحقيبة 10 لكل قطعة" },
	{"Med Kit" , "Med Kit",20000,"الاسم: Med Kit \nالنوع: علاج \n\nالوصف: تعبئة 200% الصحة\nمدة الاستخدام: 8 ثواني" },
	{"FirstAid Kit" , "FirstAid Kit",12000,"الاسم: FirstAid Kit \nالنوع: علاج \n\nالوصف: تعبئة 100% الصحة\nمدة الاستخدام: 6 ثواني" },
	{"Bandage" , "Bandage",8000,"الاسم: Bandage \nالنوع: علاج \n\nالوصف: تعبئة 25% الصحة\nمدة الاستخدام: 4 ثواني" },
	{"Adrenaline" , "Adrenaline",5000,"الاسم: Adrenaline \nالنوع: تعزيز \n\nالوصف: معزز 100% الصحة\nوالدرع كل ثانيتين زيادة +2\nمدة الاستخدام: 6 ثواني" },
	{"PainKiller" , "PainKiller",3000,"الاسم: PainKiller \nالنوع: تعزيز \n\nالوصف: معزز 32% الصحة\nوالدرع كل ثانيتين زيادة +2\nمدة الاستخدام: 6 ثواني" },
	{"Energy Drink" , "Energy Drink",1000,"الاسم: Energy Drink \nالنوع: تعزيز \n\nالوصف: معزز 16% الصحة\nوالدرع كل ثانيتين زيادة +2\nمدة الاستخدام: 6 ثواني" },
}

addEventHandler("onClientResourceStart", resourceRoot,
    function()
local screenW, screenH = guiGetScreenSize()
        WndStore = guiCreateWindow((screenW - 339) / 2, (screenH - 284) / 2, 339, 284, ".: المتجر :.", false)
		guiSetVisible(WndStore, false)

        GridStore = guiCreateGridList(12, 28, 153, 190, false, WndStore)
		guiGridListAddColumn(GridStore, "Item", 0.59)
        guiGridListAddColumn(GridStore, "Price", 0.3)
        PhotoStore = guiCreateStaticImage(201, 28, 100, 100, "Img/Store.png", false, WndStore)
        InfoStore = guiCreateLabel(175, 136, 153, 108, "الاسم: \nالنوع: \nمدة الاستخدام : \nالوصف:", false, WndStore)
        guiSetFont(InfoStore, "default-bold-small")
        guiLabelSetColor(InfoStore, 254, 224, 83)
        guiLabelSetHorizontalAlign(InfoStore, "right", false)
        AmountStore = guiCreateEdit(12, 224, 108, 20, "0", false, WndStore)
		guiEditSetMaxLength(AmountStore, 2)
        LabelStore = guiCreateLabel(120, 224, 45, 20, "الكمية :", false, WndStore)
        guiSetFont(LabelStore, "default-bold-small")
        guiLabelSetColor(LabelStore, 254, 82, 82)
        guiLabelSetHorizontalAlign(LabelStore, "right", false)
        guiLabelSetVerticalAlign(LabelStore, "center")
        BuyStore = guiCreateButton(12, 254, 153, 20, "شراء", false, WndStore)
        guiSetFont(BuyStore, "default-bold-small")
        guiSetProperty(BuyStore, "NormalTextColour", "FFFEE053")
        CloseStore = guiCreateButton(175, 254, 153, 20, "إغلاق", false, WndStore)
        guiSetFont(CloseStore, "default-bold-small")
        guiSetProperty(CloseStore, "NormalTextColour", "FFFE5252")  
		for i,v in ipairs( Store ) do
		local Row = guiGridListAddRow( GridStore )
			guiGridListSetItemText( GridStore, Row, 1, v[1], false, false )
			guiGridListSetItemData( GridStore, Row, 1, {v[2],v[4]} )
			guiGridListSetItemText( GridStore, Row, 2, convertNumber(v[3]) , false, true )
			guiGridListSetItemData( GridStore, Row, 2, v[3] )
			guiGridListSetItemColor(GridStore, Row ,1,255,100,100,255)
		end
end
)


Markers = { 
 {-2439.64258, -195.63231, 35.31250,0,0},
 {-1694.48523, 951.82404, 24.89063,0,0},
 {-1617.62402, 1131.01697, 7.18750,0,0},
 {-832.38849, 1482.82617, 18.37060,0,0},
 {-206.01895, 1032.85913, 19.94536,0,0},
 {680.78937, -1792.67688, 12.46875,0,0},
 {2865.45630, -1458.18579, 10.95647,0,0},
} 

 
for _ , v in ipairs ( Markers ) do 
	local aMarker = createMarker ( v [ 1 ] , v [ 2 ] , v [ 3 ] - 1 , 'cylinder' , 2 , 255 , 255 , 0 , 20 )
	setElementInterior( aMarker, v[4] )
	setElementDimension( aMarker, v[5] )
	setBlipVisibleDistance ( createBlip ( v [ 1 ] , v [ 2 ] , v [ 3 ] , 12 ) , 300 )


addEventHandler ( 'onClientMarkerHit' , root ,
	function ( aPlayer )
		if ( aPlayer == localPlayer and source == aMarker ) then 
            guiSetVisible(WndStore, true)
            showCursor(true)
		end
	end )
addEventHandler ( 'onClientMarkerLeave' , root ,
	function ( aPlayer )
		if ( aPlayer == localPlayer and source == aMarker ) then 
            guiSetVisible(WndStore, false)
            showCursor(false)
		end
	end )
end

addEventHandler("onClientGUIClick",root,function()
local row, col = guiGridListGetSelectedItem (GridStore)
local Edit = guiGetText(AmountStore)
if( row and col and row ~= -1 and col ~= -1 )then
if source == BuyStore then
if Edit ~= "0" then
local Price = guiGridListGetItemData(GridStore,row,2)*Edit
local Name,Info = unpack(guiGridListGetItemData(GridStore,row,1))
triggerServerEvent("BuyStore",localPlayer,Name,Price,Edit)
guiSetText(AmountStore, 0)
end
end
if source == GridStore then
local Name,Info = unpack(guiGridListGetItemData(GridStore,row,1))
guiSetText(InfoStore, Info or "الاسم: \nالنوع: \nمدة الاستخدام : \nالوصف:")
if Name == "Backpack1" then
guiStaticImageLoadImage(PhotoStore,"Img/BackpackLVL1.png")
elseif Name == "Backpack2" then
guiStaticImageLoadImage(PhotoStore,"Img/BackpackLVL2.png")
elseif Name == "Backpack3" then
guiStaticImageLoadImage(PhotoStore,"Img/BackpackLVL3.png")
else
guiStaticImageLoadImage(PhotoStore,"Img/"..Name..".png")
end
guiSetText(AmountStore, 0)
end
else
guiSetText(InfoStore, "الاسم: \nالنوع: \nمدة الاستخدام : \nالوصف:")
guiStaticImageLoadImage(PhotoStore,"Img/Store.png")
end
if source == CloseStore then
guiSetVisible(WndStore,false)
showCursor(false)
end
end
)


addEventHandler("onClientGUIChanged",resourceRoot,
function()
local row, col = guiGridListGetSelectedItem (GridStore)
local Edit = guiGetText(AmountStore)
local Money = getPlayerMoney()
if( row and col and row ~= -1 and col ~= -1 )then
local Name,Info = unpack(guiGridListGetItemData(GridStore,row,1))
if Name == "PainKiller" or Name == "Energy Drink" or Name == "Bandage" or Name == "FirstAid Kit" or Name == "Med Kit" or Name == "Adrenaline" then
if getElementData(localPlayer,"Backpack") == "LVL3" then
Check = 20 - getElementData(localPlayer,Name)
elseif getElementData(localPlayer,"Backpack") == "LVL2" then
Check = 15 - getElementData(localPlayer,Name)
elseif getElementData(localPlayer,"Backpack") == "LVL1" then
Check = 10 - getElementData(localPlayer,Name)
elseif getElementData(localPlayer,"Backpack") == "LVL0" then
Check = 5 - getElementData(localPlayer,Name)
end
else
Check = 1
end
if source == AmountStore then
if tonumber(Edit) == nil or isHasSpace(Edit) or tonumber(Edit) < 0 or tonumber(Money) < 0 then
guiSetText(AmountStore, 0)
elseif tonumber(Edit) > Check then
guiSetText(AmountStore, tonumber(math.ceil(Check)))
else
guiSetText(AmountStore, tonumber(math.ceil(Edit)))
end
end
else
guiSetText(AmountStore, 0)
end
end
)


function isHasSpace(text)
    for i = 1, #text do
        local byte = text:byte(i)
        if(byte == 32)then
            return true
        end
    end
    return false
end

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end