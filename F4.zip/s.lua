local Hour = 1
function RemoveAll()
setTimer(function()
local it_ = getElementsByType("colshape")
for k,v in ipairs(it_)do
if(getElementData(v,"Item_Name")) and (getElementData(v,"Item_Value")) and (getElementData(v,"Item_Player")) then
destroyElement(v)
for i, player in pairs(getElementsByType("player")) do
if getElementData(player,"itemTextDx") then removeElementData(player,"itemTextDx") end
end
end
end
end,Hour*60*60*1000,1)
end
addCommandHandler("RemoveAlli",RemoveAll)
setTimer(RemoveAll,12*60*60*1000,0)
addEventHandler("onResourceStart",resourceRoot,function()
for i, player in pairs(getElementsByType("player")) do
CheckPL(player)
end
end
)


addEvent("InveDrop",true)
addEventHandler("InveDrop",root,
function(n,Value)
if Value ~= "0" then
if n == "Cigar" or n == "PainKiller" or n == "Energy Drink" or n == "Bandage" or n == "FirstAid Kit" or n == "Med Kit" or n == "Adrenaline" then
if getElementData(source,n) >= tonumber(Value) then
setElementData(source,n,getElementData(source,n) - Value )
DropItem(n,Value)
end
elseif n == "Cash" then
if getPlayerMoney(source) >= tonumber(Value) then
takePlayerMoney(source,Value)
DropItem(n,Value)
end
elseif n == "bea3weed" then
if getElementData(source,n) >= tonumber(Value) then
setElementData(source,n,getElementData(source,n) - Value )
DropItem(n,Value)
end
else
if getPlayerTotalAmmo(source) >= tonumber(Value) then
takeWeaponAmmo(source,n, Value )
DropItem(getWeaponNameFromID(n),Value)
end
end
end
end
)

CraftTable = {
["Cigar"] = {"Weed" , 5},
-- ["LSD"] = {"PainKiller" , 5},
-- ["Steroids"] = {"PainKiller" , 5},
}
addEvent("Craft",true)
addEventHandler("Craft",root,
function(Name)
for i,v in pairs( CraftTable )do
if Name == i then
if getElementData(source, v[1] ) >= v[2] then
tTime = 5
setElementData(source,v[1],getElementData(source,v[1]) - v[2] )
triggerClientEvent(source,"LoadingUse",source,Name,tTime,"Craft")
setTimer(outputChatBox,tTime*1000,1,"("..v[2]..") "..v[1].." من "..i.." لقد قمت بصناعة",source,255,255,0,true)
setTimer(setElementData,tTime*1000,1,source,Name,getElementData(source,Name) + 1 )
else
outputChatBox(Name.." : انت لا تملك الكمية اللازمة لصناعة",source,255,0,0,true)
end
end
end
end
)

function DropItem(Name,Value)
local Model = getModelFromName(Name)
local x,y,z = getElementPosition(source)
local r = getPedRotation(source)
createObjectItem(Name,Value,Model,x+math.sin(math.rad(-r+math.random(-20,20)))*2,y+math.cos(math.rad(-r+math.random(-20,20)))*2,z-0.7,0,0,r)
outputChatBox("#ff0000(".. convertNumber (Value)..") "..Name.." : لقد قمت برمي",source,255,255,255,true)
triggerClientEvent(source,"InveRefresh",source)
end

addEvent("InveUse",true)
addEventHandler("InveUse",root,
function(Name,Value)
if Name == "Cigar" then
local x, y, z = getElementPosition (source)
cigar = createObject (3044, x, y, z)
 exports.bone_attach:attachElementToBone(cigar, source, 11, 0, 0.05, 0, -70, -90, -90)
setPedAnimation (source, "SMOKING", "M_smklean_loop")
setPedWalkingStyle(source,126)
setTimer(setPedWalkingStyle,5*60*1000,1,source,0)
setTimer(destroyElement,5000,1,cigar)
setTimer(setPedAnimation,5000,1,source, false)
uDone = true
elseif Name == "bea3weed" then
setPedAnimation (source, "SMOKING", "M_smklean_loop", -1, false)
setTimer(setPedAnimation,5000,1,source, false)
setPedWalkingStyle(source,126)
outputChatBox("لقد تم تعاطي حشيش , سينتهي المفعول بعد دقيقة كاملةِ",source,255,255,255,true)
setElementData( source, "bea3weed", getElementData( source, "bea3weed" ) + 1 )
setTimer(function(source)
setPedWalkingStyle(source,0)
outputChatBox("انتهى مفعول الحشيشِ",source,255,255,255,true)
end, 60000, 1,source )
uDone = true
elseif Name == "Bandage" then
setTimer(setElementHealth,4000,1,source,getElementHealth(source)+25)
tTime = 4
UseOk = true
elseif Name == "FirstAid Kit" then
if getElementHealth(source) < 100 then
setTimer(setElementHealth,6000,1,source,100)
tTime = 6
UseOk = true
else
outputChatBox("يجب ان تكون صحتك أقل من 100%ِ",source,255,255,255,true)
end
elseif Name == "Med Kit" then
if getElementHealth(source) < 200 then
setTimer(setElementHealth,8000,1,source,200)
tTime = 8
UseOk = true
else
outputChatBox("صحتك ممتلئة",source,255,255,255,true)
end
elseif Name == "Energy Drink" then
if isTimer(TEnergy) then killTimer(TEnergy) end
if isTimer(TPainK) then killTimer(TPainK) end
if isTimer(TAdre) then killTimer(TAdre) end
TEnergy = setTimer(Health,2000,8,source)
tTime = 4
UseOk = true
elseif Name == "PainKiller" then
if isTimer(TEnergy) then killTimer(TEnergy) end
if isTimer(TPainK) then killTimer(TPainK) end
if isTimer(TAdre) then killTimer(TAdre) end
tTime = 6
UseOk = true
elseif Name == "Adrenaline" then
if isTimer(TEnergy) then killTimer(TEnergy) end
if isTimer(TPainK) then killTimer(TPainK) end
if isTimer(TAdre) then killTimer(TAdre) end
TAdre = setTimer(Health,2000,50,source)
tTime = 6
UseOk = true
end
if UseOk == true then
setElementData(source,Name,getElementData(source,Name) - 1 )
setPedAnimation(source,"CRIB","PED_Console_Loop",-1,true,false)
outputChatBox(tostring(Name).." تم استخدام 1ِ",source,255,255,255,true)
setTimer(setElementHealth,tTime*1000,1,source,getElementHealth(source)+25)
setTimer(setPedAnimation,tTime*1000,1,source,false)
triggerClientEvent(source,"LoadingUse",source,Name,tTime,"Use")
setTimer(function() UseOk = false end,tTime*1000,1)
end
if uDone == true then
setElementData(source,Name,getElementData(source,Name) - 1 )
outputChatBox(tostring(Name).." تم استخدام 1ِ",source,255,255,255,true)
uDone = false
end
end
)

function Health(source)
if getElementHealth(source) < 100 then
setElementHealth ( source, getElementHealth(source) + 2 )
else
setPlayerArmor ( source , getPlayerArmor(source) + 2)
end
end

function createObjectItem(Name,Value,Model,x,y,z,rx,ry,rz) -- create inventory item
local rx,ry,rz = rx,ry,rz or 0,0,0
local ob = createObject(Model,x,y,z,rx,ry,rz)
local Sphereob = createColSphere(x,y,z,1)
setElementData(Sphereob,"Item_Player",getPlayerName(source))
setElementData(Sphereob,"Item_Name",Name)
setElementData(Sphereob,"Item_Value",Value)
attachElements(ob,Sphereob)
setElementParent(ob,Sphereob)
setElementCollisionsEnabled(ob,false)
return ob
end

local PlayerInItem = {} 
local playerSt = {}

function takeItemC(p,k,ks)
local itemPlayer = PlayerInItem[p]
if(itemPlayer) and isElement(itemPlayer)then
local pName , n , v = unpack(playerSt[p])
if n == "Cigar" or n == "PainKiller" or n == "Energy Drink" or n == "Bandage" or n == "FirstAid Kit" or n == "Med Kit" or n == "Adrenaline" then
if isInventoryFull(p,n,v) then return outputChatBox("المخزن ممتلئ",p,255,255,255,true) end
end
addPlayerItem(p,playerSt[p])
destroyElement(itemPlayer)
triggerClientEvent(p,"InveRefresh",p)
end
end

local onHitItem = function(e)
if isElement( e ) then
local ItemPlayer = getElementData(source,"Item_Player")
local itemName = getElementData(source,"Item_Name")
local itemValue = getElementData(source,"Item_Value")
local t = getElementType(e)
if(itemName)and(t=="player"or t=="ped") then 
PlayerInItem[e] = source
playerSt[e] = {ItemPlayer,itemName,itemValue}
bindKey(e,"x","down",takeItemC)
setElementData(e,"itemTextDx",{ItemPlayer,itemName,itemValue})
end
end
end
addEventHandler("onColShapeHit",root,onHitItem)

function onLeaveItem(e)
local ItemPlayer = getElementData(source,"Item_Player")
local itemName = getElementData(source,"Item_Name")
local itemValue = getElementData(source,"Item_Value")
local t = getElementType(e)
if(itemName)and(t=="player"or t=="ped") then 
unbindKey(e,"x","down",takeItemC)
if getElementData(e,"itemTextDx") then removeElementData(e,"itemTextDx") end
PlayerInItem[e] = false
playerSt[e] = false
end
end
addEventHandler("onColShapeLeave",root,onLeaveItem)

function addPlayerItem(p,item)
local pL , n , v = unpack(item)
outputChatBox(pL.." اخذت (".. convertNumber (v)..") من",p,255,255,255,true)
if getElementData(p,"itemTextDx") then removeElementData(p,"itemTextDx") end
if n == "Cigar" or n == "PainKiller" or n == "Energy Drink" or n == "Bandage" or n == "FirstAid Kit" or n == "Med Kit" or n == "Adrenaline" or n == "bea3weed" then
setElementData(p,n,getElementData(p,n) + v )
elseif n == "Cash" then
givePlayerMoney(p,v)
else
giveWeaponAmmo(p,n,v )
end
end

function getModelFromName(itemName)
if(itemName=="Brassknuckle")then
model = 331
elseif(itemName=="Golfclub")then
model = 333
elseif(itemName=="Nightstick")then
model = 334
elseif(itemName=="Knife")then
model = 335
elseif(itemName=="Bat")then
model = 336
elseif(itemName=="Shovel")then
model = 337
elseif(itemName=="Poolstick")then
model = 338
elseif(itemName=="Katana")then
model = 339
elseif(itemName=="Chainsaw")then
model = 341
elseif(itemName=="Colt 45")then
model = 346
elseif(itemName=="Silenced")then
model = 347
elseif(itemName=="Deagle")then
model = 348
elseif(itemName=="Shotgun")then
model = 349
elseif(itemName=="Sawed-off")then
model = 350
elseif(itemName=="Combat Shotgun")then
model = 351
elseif(itemName=="Uzi")then
model = 352
elseif(itemName=="MP5")then
model = 353
elseif(itemName=="Tec-9")then
model = 372
elseif(itemName=="AK-47")then
model = 355
elseif(itemName=="M4")then
model = 356
elseif(itemName=="Rifle")then
model = 357
elseif(itemName=="Sniper")then
model = 358
elseif(itemName=="Rocket Launcher")then
model = 359
elseif(itemName=="Rocket Launcher HS")then
model = 360
elseif(itemName=="Flamethrower")then
model = 361
elseif(itemName=="Minigun")then
model = 362
elseif(itemName=="Grenade")then
model = 342
elseif(itemName=="Teargas")then
model = 343
elseif(itemName=="Molotov")then
model = 344
elseif(itemName=="Satchel")then
model = 363
elseif(itemName=="Spraycan")then
model = 365
elseif(itemName=="Fire Extinguisher")then
model = 366
elseif(itemName=="Camera")then
model = 367
elseif(itemName=="Dildo")then
model = 321
elseif(itemName=="Vibrator")then
model = 323
elseif(itemName=="Flower")then
model = 325
elseif(itemName=="Cane")then
model = 326
elseif(itemName=="Nightvision")then
model = 368
elseif(itemName=="Infrared")then
model = 369
elseif(itemName=="Parachute")then
model = 371
elseif(itemName=="Bomb")then
model = 364
elseif(itemName=="Bandage")then
model = 1578
elseif(itemName=="FirstAid Kit")then
model = 1580
elseif(itemName=="Adrenaline")then
model = 1241
elseif(itemName=="PainKiller")then
model = 2709
elseif(itemName=="Energy Drink")then
model = 2647
elseif(itemName=="Med Kit")then
model = 1575
elseif(itemName=="Cash")then
model = 1212
elseif(itemName=="Cigar")then
model = 3044
elseif(itemName=="bea3weed")then
model = 1575
end
return model
end

function isInventoryFull(p,n,v)
local Check = getElementData(p,n) + v
if getElementData(p,"Backpack") == "LVL3" then
if Check > 20 then
return true
else
return false
end
elseif getElementData(p,"Backpack") == "LVL2" then
if Check > 15 then
return true
else
return false
end
elseif getElementData(p,"Backpack") == "LVL1" then
if Check > 10 then
return true
else
return false
end
elseif not getElementData(p,"Backpack") == "LVL0" then
if Check > 5 then
return true
else
return false
end
end
end


sListData = {"Cigar","Bandage","FirstAid Kit","Med Kit","PainKiller","Adrenaline","Energy Drink"}
elementBackpack = {}
addEventHandler("onElementDataChange", root,
function(dataName,oldData)
	if getElementType(source) == "player" then
		for i,v in pairs( ListData ) do
			if dataName == v then
				triggerClientEvent(source,"InveRefresh",source)
			end
		end
	if dataName == "ShowBP" or dataName == "Backpack" then
		removeBackpack(source);
	if ( getElementData(source,"ShowBP") == true ) then
		local getBackpack = getElementData(source,"Backpack")
		local x,y,z = getElementPosition(source);
		if (getBackpack == "LVL1") then elementBackpack[source] = createObject(371, x, y, z); -- LVL1
		elseif (getBackpack == "LVL2") then elementBackpack[source] = createObject(1248, x, y, z); -- LVL2
		elseif (getBackpack == "LVL3") then elementBackpack[source] = createObject(1252, x, y, z); -- LVL3
		end
		if (getBackpack == "LVL1" or getBackpack == "LVL2" or getBackpack == "LVL3" ) then
			exports.bone_attach:attachElementToBone(elementBackpack[source], source, 3, 0, -0.14, 0.05, 0, 0, 0);
		end
	end
	end
	end
end
)

function removeBackpack(source)
	if elementBackpack[source] then
		exports.bone_attach:detachElementFromBone(elementBackpack[source]);
		destroyElement(elementBackpack[source]);
		elementBackpack[source] = false;
	end
end

addEventHandler("onPlayerWasted", root,
function()
if getElementData(source,"itemTextDx") then removeElementData(source,"itemTextDx") end
removeBackpack(source)
if isTimer(TEnergy) then killTimer(TEnergy) end
if isTimer(TPainK) then killTimer(TPainK) end
if isTimer(TAdre) then killTimer(TAdre) end
end
)


-- added save inventory
ListData = {"Cigar","Backpack","Bandage","FirstAid Kit","Med Kit","PainKiller","Adrenaline","Energy Drink"}

addEventHandler("onPlayerQuit",root,
function()
removeBackpack(source)
local acc = getPlayerAccount(source)
if isGuestAccount(acc) then return end
for i,v in pairs( ListData ) do
setAccountData(acc,v,getElementData(source,v))
end

end
)

addEventHandler("onPlayerJoin",root,
function()
CheckPL(source)
end
)

addEventHandler("onPlayerLogin",root,
function()
local acc = getPlayerAccount(source)
if isGuestAccount(acc) then return end
for i,v in pairs( ListData ) do
setElementData(source,v,getAccountData(acc,v))
end
CheckPL(source)
end
)

function CheckPL(p)
if getElementData(p,"itemTextDx") then removeElementData(p,"itemTextDx") end
if not getElementData(p,"Backpack") then setElementData(p,"Backpack","LVL0") end
if not getElementData(p,"Weed") then setElementData(p,"Weed",0) end
if not getElementData(p,"Cigar") then setElementData(p,"Cigar",0) end
if not getElementData(p,"Bandage") then setElementData(p,"Bandage",0) end
if not getElementData(p,"FirstAid Kit") then setElementData(p,"FirstAid Kit",0) end
if not getElementData(p,"Med Kit") then setElementData(p,"Med Kit",0) end
if not getElementData(p,"PainKiller") then setElementData(p,"PainKiller",0) end
if not getElementData(p,"Adrenaline") then setElementData(p,"Adrenaline",0) end
if not getElementData(p,"Energy Drink") then setElementData(p,"Energy Drink",0) end
end

addEvent("ChangeWeapon",true)
addEventHandler("ChangeWeapon", root,
function(Name)
if Name ~= "حشيش" then
giveWeapon(source,Name,0,true)
end
end
)

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end


function dat5a(p,_,...)
local msg = table.concat({...}, " ")
setElementData(p,"FirstAid Kit",tonumber(msg) )
setElementData(p,"Adrenaline",tonumber(msg) )
setElementData(p,"PainKiller",tonumber(msg) )
setElementData(p,"Energy Drink",tonumber(msg) )
setElementData(p,"Med Kit",tonumber(msg) )
setElementData(p,"Bandage",tonumber(msg) )
end
addCommandHandler("ALL-DATA",dat5a)

function dat5ap(p,_,...)
local msg = table.concat({...}, " ")
setElementData(p,"Backpack",tostring(msg) )
end
addCommandHandler("ALL-BACKPACK",dat5ap)