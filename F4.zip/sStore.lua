addEvent("BuyStore",true)
addEventHandler("BuyStore",root,
function(Name,Price,Edit)
if getPlayerMoney(source) >= Price then
if Name == "PainKiller" or Name == "Energy Drink" or Name == "Bandage" or Name == "FirstAid Kit" or Name == "Med Kit" or Name == "Adrenaline" then
takePlayerMoney(source,Price)
setElementData(source, Name, getElementData(source,Name) + Edit )
outputChatBox("[Store]: You Buy "..Name.." ("..Edit..")",source,255,255,0,true)
end
if Name == "Backpack1" then
if getElementData(source,"Backpack") ~= "LVL1" then
takePlayerMoney(source,Price)
setElementData(source, "Backpack", "LVL1")
outputChatBox("[Store]: You Buy Backpack Lvl.1",source,255,255,0,true)
SetData(source,10)
else
outputChatBox("You Already Have Backpack Lvl.1",source,255,0,0,true)
end
elseif Name == "Backpack2" then
if getElementData(source,"Backpack") ~= "LVL2" then
takePlayerMoney(source,Price)
setElementData(source, "Backpack", "LVL2")
outputChatBox("[Store]: You Buy Backpack Lvl.2",source,255,255,0,true)
SetData(source,15)
else
outputChatBox("You Already Have Backpack Lvl.2",source,255,0,0,true)
end
elseif Name == "Backpack3" then
if getElementData(source,"Backpack") ~= "LVL3" then
takePlayerMoney(source,Price)
setElementData(source, "Backpack", "LVL3")
outputChatBox("[Store]: You Buy Backpack Lvl.3",source,255,255,0,true)
SetData(source,20)
else
outputChatBox("You Already Have Backpack Lvl.3",source,255,0,0,true)
end
end
else
outputChatBox("You Don't Have Money To Buy This",source,255,0,0,true)
end
end
)

function SetData(p,edit)
if getElementData(p,"Bandage") >= edit then setElementData(p,"Bandage",edit) end
if getElementData(p,"FirstAid Kit") >= edit then setElementData(p,"FirstAid Kit",edit) end
if getElementData(p,"Med Kit") >= edit then setElementData(p,"Med Kit",edit) end
if getElementData(p,"PainKiller") >= edit then setElementData(p,"PainKiller",edit) end
if getElementData(p,"Adrenaline") >= edit then setElementData(p,"Adrenaline",edit) end
if getElementData(p,"Energy Drink") >= edit then setElementData(p,"Energy Drink",edit) end
end