﻿S3D_1 = {
{"..."},
{"ساحة القتال", 278.10345458984,1989.5435791016,17.640625 },
{"استراحة فخامة", -721.34368896484,966.83099365234,12.160091400146 },
{"النخيل", 2123.8325195313,1401.6809082031,11.1328125 },
{"الفندق", -1755.5179443359,949.04315185547,24.7421875 },
{"الدائري", 1688.3386230469,1396.7816162109,10.743474006653 },
{"ساحة التفجير", -2043.0391845703,-94.341201782227,35.1640625 },
{"مسبح فخامةـ", 2877.9543457031,58.122859954834,19.5078125 },
{"الورشة", -1224.48828125,-24.567989349365,14.1484375 },
{"مطار المدينة الثانية", 1501.5555419922,1506.7238769531,10.82702255249 },
{"المرقص", 221.8101348877,-1875.7082519531,2.1141755580902 },
{"العوشرية", 535.88299560547,688.88262939453,3.3668613433838 },
{"مطار المدينة الثانية", -1366.7691650391,-179.01960754395,14.1484375 },
{"محل بيع بيع لأسلحة", 1360.9483642578,-1280.0258789063,13.3828125 },
{"مطار المدينة الأولى", 1928.3995361328,-2351.3386230469,13.546875 },
{"حلبة الدبابات", 2791.8657226563,-1831.6843261719,9.8507347106934 },
{"ورشة سباق الليل المتصل", -1222.4357910156,-21.149410247803,14.1484375 },
{"الدبابات المائية", 154.66203308105,-1933.619140625,3.7734375 },
{"المطعم", 2341.8049316406,74.821495056152,26.3359375 },
{"بقالة فخامة", 992.69012451172,-921.11767578125,42.1796875 },
{"البنك الرئيسي", 1477.4490966797,-1764.4223632813,18.795755386353 },
{"كهف التنين", -466.16806030273,1459.9136962891,21.448348999023 },
{"برج الفيصلية", -1291.2697753906,-16.801460266113,14.1484375 },
}

S3D_2 = {
{"..."},	
{"الطعوس", -3302.55859375,-3109.7810058594,4 },
{"حي فخامة السكني2", -3559.7595214844,-2971.4423828125,4 },
{"ساحة التفجير", -3570.0751953125,-3111.0205078125,4 },
{"ساحة القتال2", -2982.3186035156,-2905.9106445313,4 },
}

S3D_3 = {
{"..."},	
{"حارة فخامة", 832.17687988281,-2043.041015625,13.914699554443,832.83618164063,-2043.7885742188,13.834784507751},
{"استئجار الطائرات", 1556.0522460938,1336.5374755859,11.916500091553,1556.9305419922,1336.0660400391,11.836585044861},
{"الصحراء - المخيم", 2904.2106933594,-782.09490966797,12.072799682617,2905.2048339844,-782.16613769531,11.992884635925},
{"مقهى فخامة", 612.50201416016,-1880.6531982422,4.8477001190186,613.20892333984,-1881.3559570313,4.7677855491638},
{"حي فخامة السكني", 2855.4821777344,-1959.5150146484,11.843299865723,2856.2749023438,-1960.1192626953,11.763384819031},
}

S3D_4 = {
{"..."},
{"الحرب", 1776.3229980469,-1821.1600341797,13.562076568604 },
{"Transporter Mission | مهمةالتوصيل", 1844.4653320313,-1864.7763671875,13.3828125 },
{"سرقة البنك", 591.08264160156,-1241.5334472656,17.910913467407 },
{"سباق السيارات", 2795,-1836,9.8632917404175 },
}

S3D_5 = {
{"..."},	
{"حارة فخامة", 835.86877441406,-2047.2275390625,12.8671875 },
{"استئجار الطائرات", 1560.9708251953,1333.8973388672,10.868956565857 },
{"الصحراء - المخيم", 2909.7785644531,-782.49359130859,11.025268554688 },
{"مقهى فخامة", 614.64233398438,-1882.7807617188,4.0057926177979 },
{"حي فخامة السكني", 2858.4982910156,-1961.8138427734,10.939234733582 },
}

S3D_Place = {
{"أماكن حصرية"},
{"اماكن البداية"},
{"الاماكن الرئيسية"},
{"المهمات"},
}

function centerWindow(center_window,i,v)
local screenW, screenH = guiGetScreenSize()
local windowW, windowH = guiGetSize(center_window, false)
local x, y = (screenW - windowW) / i, (screenH - windowH) / v
guiSetPosition(center_window, x, y, false)
end

local Rroot = getResourceRootElement(getThisResource())

GUIEditor = {
    gridlist = {},
    window = {},
    button = {},
    label = {}
}

GUIEditor.window[1] = guiCreateStaticImage(551, 249, 339, 418, "s3d.png", false)
GUIEditor.gridlist[1] = guiCreateGridList(10, 17, 319, 337, false, GUIEditor.window[1])
guiGridListSetSortingEnabled(GUIEditor.gridlist[1], false)
guiGridListAddColumn(GUIEditor.gridlist[1], "#", 0.4)
guiGridListAddColumn(GUIEditor.gridlist[1], "الاماكن", 0.9)
Text = guiCreateLabel(55, 359, 224, 15, "Double Click Warp | اظغط مرتين للانتقال", false, GUIEditor.window[1])
GUIEditor.button[1] = guiCreateButton(102, 385, 130, 23, "X", false, GUIEditor.window[1]) 

addEventHandler('onClientResourceStart', Rroot,
function()
guiSetVisible(GUIEditor.window[1], false)
centerWindow(GUIEditor.window[1],2,2)
guiSetAlpha(GUIEditor.gridlist[1], 1)
for _, v in ipairs(getElementsByType('gui-button',Rroot)) do
guiSetProperty(v, 'NormalTextColour', 'FFFD0000')
guiSetFont(v, "default-bold-small")
end
for _, v in ipairs(getElementsByType('gui-label',Rroot)) do
guiSetFont(GUIEditor.gridlist[1], "default-bold-small")
guiSetFont(v, "default-bold-small")
guiLabelSetColor(Text, 255, 255, 255)
end end )

addEventHandler("onClientGUIClick", GUIEditor.button[1], 
	function()
		guiSetVisible(GUIEditor.window[1], false)
		showCursor(false)
	end	
,false)

addEventHandler('onClientGUIDoubleClick',GUIEditor.gridlist[1],
function () 
local Row = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 )
local Sel = guiGridListGetSelectedItem( GUIEditor.gridlist[1] )
if ( Sel == -1 ) then return end
if ( Row ) == "الاماكن الرئيسية" then return
Main_Places(localPlayer)
elseif ( Row ) == "..." then return
Return(localPlayer)
elseif ( Row ) == "الشوارع" then return
Streets(localPlayer)
elseif ( Row ) == "المهمات" then return
Missions(localPlayer)
elseif ( Row ) == "اماكن البداية" then return
StartPlaces(localPlayer)
elseif ( Row ) == "أماكن حصرية" then return
Exclusiveplaces(localPlayer)
else
if isPedInVehicle(localPlayer) then return outputChatBox("* الرجاء النزول من السيارهـ #,", 255,0,0, true) end
local Text = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 )
fadeCamera(false)
setTimer(setElementPosition,1000,1, localPlayer, unpack ( guiGridListGetItemData ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 ) ) )
setTimer(function () fadeCamera(true) setCameraTarget(localPlayer) end,2000,1)
guiSetVisible(GUIEditor.window[1],not guiGetVisible(GUIEditor.window[1]))
showCursor(guiGetVisible(GUIEditor.window[1])) 
end end )

bindKey("f6","down",
function ()
guiSetVisible(GUIEditor.window[1],not guiGetVisible(GUIEditor.window[1]))
showCursor(guiGetVisible(GUIEditor.window[1])) 
Return(localPlayer, guiGetVisible(GUIEditor.window[1]))
end
)

function Main_Places ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk in ipairs(S3D_1) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
local First = guiGridListSetItemText( GUIEditor.gridlist[1], 0, 2, '...', false, false )
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,''..i..'-',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk[1],false,false) 
guiGridListSetItemData(GUIEditor.gridlist[1],row,2,{mk[2],mk[3],mk[4]})
guiGridListSetItemColor(GUIEditor.gridlist[1],row,255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end

function Return ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk1 in ipairs(S3D_Place) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
 	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,'+',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk1[1],false,false)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end

function Streets ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk4 in ipairs(S3D_3) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
local First = guiGridListSetItemText( GUIEditor.gridlist[1], 0, 2, '...', false, false )
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,''..i..'-',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk4[1],false,false)
guiGridListSetItemData(GUIEditor.gridlist[1],row,2,{mk4[2],mk4[3],mk4[4]})
guiGridListSetItemColor(GUIEditor.gridlist[1],row,255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end

function Missions ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk3 in ipairs(S3D_4) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
local First = guiGridListSetItemText( GUIEditor.gridlist[1], 0, 2, '...', false, false )
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,''..i..'-',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk3[1],false,false)
guiGridListSetItemData(GUIEditor.gridlist[1],row,2,{mk3[2],mk3[3],mk3[4]})
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end

function StartPlaces ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk5 in ipairs(S3D_2) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
local First = guiGridListSetItemText( GUIEditor.gridlist[1], 0, 2, '...', false, false )
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,''..i..'-',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk5[1],false,false)
guiGridListSetItemData(GUIEditor.gridlist[1],row,2,{mk5[2],mk5[3],mk5[4]})
guiGridListSetItemColor(GUIEditor.gridlist[1],row,255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end

function Exclusiveplaces ()
guiGridListClear(GUIEditor.gridlist[1])
for i,mk7 in ipairs(S3D_5) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,''..i..'-',false,false)
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk7[1],false,false)
guiGridListSetItemData(GUIEditor.gridlist[1],row,2,{mk7[2],mk7[3],mk7[4]})
guiGridListSetItemColor(GUIEditor.gridlist[1],row,255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],255,0,0)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255,250,0)
end
end


for i,mk1 in ipairs(S3D_Place) do
local row = guiGridListAddRow(GUIEditor.gridlist[1])
guiGridListSetItemText(GUIEditor.gridlist[1],row,2,mk1[1],false,false)
guiGridListSetItemColor(GUIEditor.gridlist[1],row,255,0,0)
end

addEventHandler("onClientGUIClick", root,
function()
if (source == GUIEditor.button[1]) then
local Row = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 )
local sel = guiGridListGetSelectedItem ( GUIEditor.gridlist[1] )
if (sel ~= -1) then
if ( Row ) == "..." then return end
if ( Row ) == "الاماكن الرئيسية" then return end
if ( Row ) == "الشوارع" then return end
if ( Row ) == "المهمات" then return end
if ( Row ) == "اماكن البداية" then return end
if ( Row ) == "الاماكن الرئيسية" then return end
if ( Row ) == "أماكن حصرية" then return end
if isPedInVehicle(localPlayer) then return outputChatBox("* الرجاء النزول من السيارهـ #,", 255,0,0, true) end
setTimer(setElementPosition,1000,1, localPlayer, unpack ( guiGridListGetItemData ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 2 ) ) )
fadeCamera(false)
guiSetVisible( GUIEditor.window[1], false )
showCursor(guiGetVisible(GUIEditor.window[1]))
setTimer(function () fadeCamera(true) setCameraTarget(localPlayer) end,2000,1)
end end end )   

function apagarScript()
	if fileExists("Client_S3D.lua") then
		fileDelete("Client_S3D.lua")
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), apagarScript)
addEventHandler("onClientPlayerQuit", getRootElement(), apagarScript)
addEventHandler("onClientPlayerJoin", getRootElement(), apagarScript)