﻿RoMciS = {
{"تعديل السيارة"},
{"استرجاع حساب مفقود"},
{"تغير اسم حساب"},
{"الترقيات"},
{"تحويل فلوس"},
{"القاب شات"},
{"لوحة حفظ شخصية"},
{"لوحة حفظ المكان"},
{"لوحة القوانين"},
{"نظام القروبات"},
{"اختيار الليزر"},
{"التحكم في ابواب السياره"},
{"لوحة الشكاوي والأقترحات"},
{"_____________"},
{"دعم السيرفر"},
{"طرق الدفع لشراء ساعات"},
{"عضوية كبار الشخصيات"},
{"العضوية الخاصة"},
{"لوحة اختيار لون الليزر"},
{"شراء الساعات وغيرها"},
{"العروض الخاصة"},
{"عضوية الصوتيات"},
{"_____________"},
{"حسابات فخامة"},
}

local Rroot = getResourceRootElement(getThisResource())

GUIEditor = {
    gridlist = {},
    window = {},
    button = {},
    label = {}
}

GUIEditor.window[1] = guiCreateStaticImage(10, 289, 268, 388, "wnd.png", false)
guiSetVisible(GUIEditor.window[1], false)
GUIEditor.gridlist[1] = guiCreateGridList(10, 46, 248, 314, false, GUIEditor.window[1])
guiSetAlpha(GUIEditor.gridlist[1], 0.70)
local font0_font = guiCreateFont("Ziad1.ttf", 9)
guiSetFont(GUIEditor.gridlist[1], font0_font) 
guiGridListSetSortingEnabled(GUIEditor.gridlist[1], false)
guiGridListAddColumn(GUIEditor.gridlist[1], "Main", 0.9)
Info = guiCreateLabel(10, 10, 60, 19, "Systems", false, GUIEditor.window[1])
local font0_font = guiCreateFont("Ziad1.ttf", 13)
guiSetFont(Info, font0_font)  
Text = guiCreateLabel(10, 365, 74, 17, "@ F5amh .", false, GUIEditor.window[1])
guiSetFont(Text, "default-bold-small")

for i,Group1 in ipairs(RoMciS) do
	local row = guiGridListAddRow(GUIEditor.gridlist[1])
	guiGridListSetItemText(GUIEditor.gridlist[1],row,1,Group1[1],false,false)
	guiGridListSetItemColor(GUIEditor.gridlist[1],row,1,255, 255, 0)
	guiGridListSetItemText(GUIEditor.gridlist[1],row,2,Group1[2],false,false)
end

addEventHandler('onClientGUIDoubleClick',GUIEditor.gridlist[1],
function () 
local Row = guiGridListGetItemText ( GUIEditor.gridlist[1], guiGridListGetSelectedItem ( GUIEditor.gridlist[1] ), 1 )
local Sel = guiGridListGetSelectedItem( GUIEditor.gridlist[1] )
if ( Sel == -1 ) then return end
if ( Row ) == "Edit RoMcIS" then
elseif ( Row ) == "..." then

elseif ( Row ) == "لوحة اختيار لون الليزر" then executeCommandHandler ( "LASER" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "تعديل السيارة" then executeCommandHandler ( "تعديل" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "تغير اسم حساب" then executeCommandHandler ( "Change_acc" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "عضوية الصوتيات" then executeCommandHandler ( "Sound" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "الاسأله الشائعه" then executeCommandHandler ( "OPEN" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "عضوية كبار الشخصيات" then executeCommandHandler ( "ترحيب" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "استرجاع حساب مفقود" then executeCommandHandler ( "استرجاع" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "لوحة حفظ المكان" then executeCommandHandler ( "حفظ" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )
 
elseif ( Row ) == "لوحة القوانين" then executeCommandHandler ( "القوانين" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "لوحة الشكاوي والأقترحات" then executeCommandHandler ( "شكوة" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "الترقيات" then executeCommandHandler ( "رتب" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "القاب شات" then executeCommandHandler ( "القاب" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "تحويل فلوس" then executeCommandHandler ( "فلوس" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "التحكم في ابواب السياره" then executeCommandHandler ( "openDoor" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "حسابات الوزارة" then executeCommandHandler ( "تواصل" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "العضوية الخاصة" then executeCommandHandler ( "عضوية" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "لوحة حفظ شخصية" then executeCommandHandler ( "ملابس" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "شراء الساعات وغيرها" then executeCommandHandler ( "شراء" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "حسابات فخامة" then executeCommandHandler ( "تواصل" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "نظام القروبات" then executeCommandHandler ( "Groups" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

elseif ( Row ) == "اختيار الليزر" then executeCommandHandler ( "LASER" ) guiSetVisible (GUIEditor.window[1] ,false) showCursor ( false )

end end )

bindKey("f9","down",
function ()
guiSetVisible( GUIEditor.window[1], not guiGetVisible( GUIEditor.window[1] ) )
showCursor( guiGetVisible( GUIEditor.window[1] ) )
end
)   

function S3DFast()
	if fileExists("Client.lua") then
		fileDelete("Client.lua")
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), S3DFast)
addEventHandler("onClientPlayerQuit", getRootElement(), S3DFast)
addEventHandler("onClientPlayerJoin", getRootElement(), S3DFast)