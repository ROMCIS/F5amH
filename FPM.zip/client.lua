
local FPSLimit, lastTick, framesRendered, FPS = 100, getTickCount(), 0, 0


local sxf,syf = guiGetScreenSize()

local sx , sy = (sxf/4200) , (syf/768)

    function dxFps()
	
		local ping = getPlayerPing ( localPlayer ) 
		 local currentTick = getTickCount()
    local elapsedTime = currentTick - lastTick
    if elapsedTime >= 1000 then
        FPS = framesRendered
        lastTick = currentTick
        framesRendered = 2
    else
        framesRendered = framesRendered + 1
   end
 if FPS > FPSLimit then
    FPS = FPSLimit
   end
        dxDrawText("FPS: "..tostring(FPS),sx * 50,sy * 735,sx * 812,sy * 763, tocolor(255, 255, 255, 255), 1.00, "default-bold", "left", "bottom", false, false, false, false, false)
        dxDrawText("|   PING: "..ping.." ms",sx * 200,sy * 735,sx * 812,sy * 763, tocolor(255, 255, 255, 255), 1.00, "default-bold", "left", "bottom", false, false, false, false, false)
    end
addEventHandler("onClientRender", root,dxFps)