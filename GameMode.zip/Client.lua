﻿monthTable = { 
	["10"] = "محرم",
	["11"] = "صفر",
	["12"] = "ربيع الأول",
	["1"] = "ربيع الآخر",
	["2"] = "جمادى الأول",
	["3"] = "جمادى الآخر",
	["4"] = "رجب",
	["5"] = "شعبان",
	["6"] = "رمضان",
	["7"] = "شوال",
	["8"] = "ذو الحجة",
	["9"] = "ذو القعدة"
}

function getRealMonthH()
	local time = getRealTime()
	local month = time.month + 1
	for i, v in pairs ( monthTable ) do
		if string.find ( i , month ) then
			if v ~= "" then
				m = v
			end
		end
	end
	return m
end

dayTable = { 
	["1"] = "الأحد",
	["2"] = "الأثنين",
	["3"] = "الثلاثاء",
	["4"] = "الأربعاء",
	["5"] = "الخميس",
	["6"] = "الجمعة",
	["7"] = "السبت",
	["8"] = "الأحد",
	["9"] = "الأثنين",
	["10"] = "الثلاثاء",
	["11"] = "الأربعاء",
	["12"] = "الخميس",
	["13"] = "الجمعة",
	["14"] = "السبت",
	["15"] = "الأحد",
	["16"] = "الأثنين",
	["17"] = "الثلاثاء",
	["18"] = "الأربعاء",
	["19"] = "الخميس",
	["20"] = "الجمعة",
	["21"] = "السبت",
	["22"] = "الأحد",
	["23"] = "الأثنين",
	["24"] = "الثلاثاء",
	["25"] = "الأربعاء",
	["26"] = "الخميس",
	["27"] = "الجمعة",
	["28"] = "السبت",
	["29"] = "الأحد",
	["30"] = "الأثنين",
	["31"] = "الثلاثاء",
}

function playVideo (posX, posY, width, height, url, duration, canClose, postGUI)
	if not posX or not posY or not width or not height or not url then
		return false
	end
	local webBrowser = false
	if not isElement (webBrowser) then
		webBrowser = createBrowser (width, height, false, false)
		function createVideoPlayer ()
			function webBrowserRender ()
				dxDrawImage (posX, posY, width, height, webBrowser, 0, 0, 0, tocolor(255,255,255,255), postGUI)
showChat (false)
			end
			loadBrowserURL (webBrowser, url)
						setTimer (function()
				addEventHandler ("onClientRender", getRootElement(), webBrowserRender)
			end, 500, 1)
			if duration then
				videoTimer = setTimer (function()
					removeEventHandler ("onClientRender", getRootElement(), webBrowserRender)
					showCursor (true)
showChat (false)
					destroyElement (webBrowser)
				end, duration, 1)
			end
			
			addEventHandler ("onClientGUIClick", closeButton, function (button, state)
				if button == "left" then
					if isTimer (videoTimer) then
						killTimer (videoTimer)
						videoTimer = nil
						removeEventHandler ("onClientRender", getRootElement(), webBrowserRender)
						setElementFrozen (localPlayer, false)
						guiSetVisible (closeButton, false)
						showCursor (false)
						showChat (false)
						destroyElement (webBrowser)
					end
				end
			end, false)
		end
		setTimer (createVideoPlayer, 500, 1)
	end
end

function getRealDay()
	local time = getRealTime()
	local day = time.monthday + 1
	for i, v in pairs ( dayTable ) do
		if string.find ( i , day ) then
			if v ~= "" then
				m = v
			end
		end
	end
	return m
end

local movingSpeed = 12
local screenW, screenH = guiGetScreenSize()
local x, y = (screenW/1366), (screenH/768)
local month = getRealMonthH()
local gday = getRealDay()
local time = getRealTime()
local time2 = getTime()


setElementInterior(player, 0)
setCameraInterior(0)
setPedSkin ( localPlayer, 124 )
showPlayerHudComponent("all", false)
showChat(false)
setElementData(localPlayer, 'xyz', false)
setElementData(localPlayer, 'skin', false)

setElementDimension(localPlayer,1)
setPedSkin ( source, 124 )

checkBox1 = guiCreateCheckBox(x*737, y*502, x*17, y*15, "", false, false)
checkBox2 = guiCreateCheckBox(x*737, y*529, x*17, y*15, "", false, false)

guiSetVisible(checkBox1, false)
guiSetVisible(checkBox2, false)

guiSetAlpha(checkBox1, x*0)
guiSetAlpha(checkBox2, x*0)

userAlpha = x*150
passAlpha = x*150

alpha = 0
logo = 0
cor = {}

local dxfont0_font = dxCreateFont("font/arabic.ttf", x*13)
local font2 = dxCreateFont("font/arabic.ttf", x*20)
local dxfont1_font = dxCreateFont("font/font.ttf", x*10)
local dxfont2_font = dxCreateFont("font/font.ttf", x*18)
local s3d_font = dxCreateFont("font/english.ttf", x*13)

local fontScale = false

editBox = {}
editBox.__index = editBox
editBox.instances = {}

-- addEventHandler("onClientResourceStart",resourceRoot,
-- function ()
-- 	end
-- 

addEventHandler("onClientResourceStart",resourceRoot,
	function ()
setTimer ( function()
			if isPedInVehicle(localPlayer) then destroyElement(getPedOccupiedVehicle(localPlayer)) end	
			addEventHandler("onClientRender",getRootElement(),intro)
			addEventHandler("onClientRender",getRootElement(),hnd1)
			fadeCamera ( false, 3)
			setTimer ( fadeCamera, 100000, 1, true )
			end,2000,1)
	end
)

function intro()
	setTime( 12, 0)
		local speed = 1.0
		local speed2 = 2.5
			tickk = getTickCount()/tonumber(speed)/1000
				theAlpha = math.abs(math.sin(-tickk))*255
-- dxDrawImage((screenW - 338) / 2, (screenH - 48) / 2.2, 338, 48, "-", 0, 0, 0, tocolor(255, 255, 255, theAlpha), false)
		Ti = getTickCount()/tonumber(speed2)
		dxDrawImage((screenW - 100) / 2, (screenH - 100) / 1.1, 100, 100, "img/load.png",Ti/15,0,0,tocolor(255, 255, 255, 255), true)
        dxDrawText("-【 Welcome To Server | F5aMh Server 】-", (screenW - 362) / 2, (screenH - 23) / 2, ((screenW - 362) / 2) + 362, ( (screenH - 23) / 2) + 23, tocolor(38, 216, 93, 255), 1.00, dxfont0_font, "left", "top", false, false, false, false, false)
triggerEvent('removeFahaD',source)
end



----------

setTimer(function ()
	addEventHandler("onClientRender",getRootElement(),play)
local x, y = guiGetScreenSize()
				removeEventHandler("onClientRender",getRootElement(),intro)
	playVideo (0, 0, x, y, "https://www.youtube.com/embed/ja7MoqBGYik?autoplay=1&showinfo=0&rel=0&controls=0&disablekb=1", 62000, false, false)
setTime( 12, 0)
end,16000,1)

setTimer(function ()
	addEventHandler("onClientRender",getRootElement(),sand)
sound = playSound( "sounds/song.mp3", true )
		setTime( 12, 0)
			removeEventHandler("onClientRender",getRootElement(),hnd8)
				addEventHandler("onClientRender",getRootElement(),addRednessOnDamage)
				addEventHandler("onClientRender",getRootElement(),logo)
				removeEventHandler("onClientRender",getRootElement(),intro)
				removeEventHandler("onClientRender",getRootElement(),play)
guiSetVisible(background,true)
addEventHandler("onClientRender", getRootElement(), s3d)
		fadeCamera ( false, 1)
	setTimer ( fadeCamera, 5000, 1, true )
setTime( 20, 0)
end,80000,1)

function onClientResourceStart()
    guiSetInputMode ( "no_binds" )
	local font_EditBox = dxCreateFont("font/font_EditBox.ttf", x*14)

	user = editBox.new()
	user:setPosition(x*519, y*274, x*332, y*35, "UserName :", false)
	user.color = {255,255,255,255}
	user.font = font_EditBox
	user.visible = true
	user.onInput = function()
		userAlpha = 255
	end
	user.onOutput = function()
		userAlpha = 150
	end

	pass = editBox.new()
	pass:setPosition(x*519, y*344, x*332, y*35, "Password :", false) 
	pass.color = {255,255,255,255}
	pass.font = font_EditBox
	pass.masked = true
	pass.visible = true
	pass.onInput = function()
		passAlpha = 255
	end
	pass.onOutput = function()
		passAlpha = 150
	end
     
	setTimer(function()
	end, 2500, 1)
	showCursor(true)
	guiSetVisible(checkBox1, true)
	guiSetVisible(checkBox2, true)	
-- addEventHandler("onClientRender", getRootElement(), s3d)
-- addEventHandler("onClientRender", getRootElement(), crown)
	addEventHandler("onClientRender", getRootElement(), renderMensagesLogin)

	if not fontScale then fontScale = screenH/100 end

	local username, password = loadLoginFromXML()

	if not(username == "" or password == "") then
		guiCheckBoxSetSelected(checkBox1, true)
		user.text = tostring(username)
		pass.text = tostring(password)
	else
		guiCheckBoxSetSelected(checkBox1, false)
		user.text = tostring(username)
		pass.text = tostring(password)
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onClientResourceStart)

----------------------------------------------------------------------------------------------------------------------------------------------


function s3d()
dxDrawImage(x*0, y*0, x*1368, y*768, "img/background.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
cor[4] = tocolor(0, 0, 0, 155)
if cursorPosition(x*1040, y*622, x*189, y*59) then cor[4] = tocolor(255, 0, 0, 255) end
dxDrawRectangle(x*1040, y*622, x*189, y*59, cor[4], false) -- زر دخول السيرفر
dxDrawText("دخول السيرفر", x*1057, y*637, x*586, y*464, tocolor(255, 255, 255, 255), 1.40, dxfont0_font, "left", "top", false, false, true, false, false)

dxDrawImage(x*232, y*264, x*47, y*45, "img/players.png", 0, 0, 0, tocolor(255, 255, 255, 255), false) -- صورة الاعبين
dxDrawText("اللاعبين المتصلين", x*155, y*332, x*876, y*464, tocolor(255, 255, 255, 255), 1.00, font2, "left", "top", false, false, true, false, false)

dxDrawText("" ..gday.."", x*1000, y*450, x*586, y*464, tocolor(255, 255, 255, 255), 1.00, font2, "left", "top", false, false, true, false, false) -- اليوم
dxDrawText("" ..month.."", x*980, y*490, x*586, y*464, tocolor(255, 255, 255, 255), 1.00, font2, "left", "top", false, false, true, false, false) -- الشهر

dxDrawText("" .. #getElementsByType( "player" ) .. "", x*325, y*270, x*876, y*464, tocolor(255, 255, 255, 255), 1.00, s3d_font, "left", "top", false, false, true, false, false)
dxDrawImage(x*232, y*394, x*47, y*45, "img/ping.png", 0, 0, 0, tocolor(255, 255, 255, 255), false) -- صورة البنق
dxDrawText("البنق", x*225, y*460, x*876, y*464, tocolor(255, 255, 255, 255), 1.00, font2, "left", "top", false, false, true, false, false)
dxDrawText("" .. getPlayerPing(localPlayer) .. "", x*325, y*420, x*876, y*464, tocolor(255, 255, 255, 255), 1.00, s3d_font, "left", "top", false, false, true, false, false)
dxDrawText("W W W . F 5 A M H . N E T", x*527, y*689, x*586, y*464, tocolor(255, 255, 255, 255), 1.20, s3d_font, "left", "top", false, false, true, false, false) -- اسم السيرفر
end


function crown()
        dxDrawImage(x*0, y*0, x*1368, y*768, "img/background2.png", 0, 0, 0, tocolor(255, 255, 255, 255), false) -- الخلفيه

	   
	    logo = logo +2


	cor[1] = tocolor(24, 24, 24, 255)
	cor[2] = tocolor(0, 0, 0, 110)
	cor[3] = tocolor(24, 24, 24, 255)
        cor[5] = tocolor(24, 24, 24, 255)

	if cursorPosition(x*520, y*400, x*165, y*42) then cor[1] = tocolor(255, 37, 37, 255) end
	if cursorPosition(x*690, y*400, x*163, y*42) then cor[3] = tocolor(255, 37, 37, 255) end
        if cursorPosition(x*605, y*448, x*165, y*42) then cor[5] = tocolor(255, 37, 37, 255) end
	        dxDrawRectangle(x*462, y*224, x*450, y*327, tocolor(255, 255, 255, 90), false) -- الجيو
	    dxDrawRectangle(x*520, y*400, x*165, y*42, cor[1], false) -- زر التسجيل
	    dxDrawRectangle(x*690, y*400, x*163, y*42, cor[3], false) -- زر حساب جديد
	    dxDrawRectangle(x*607, y*448, x*165, y*42, cor[5], false) -- زر الرجوع للرئيسية
		
 dxDrawRectangle(x*462, y*224, x*450, y*30, tocolor(30, 30, 30, 255, alpha), false) -- الخط الاسود
dxDrawRectangle(x*462, y*251, x*450, y*4, tocolor(251, 0, 0, 255, alpha), false) -- الخط الاحمر



dxDrawImage(x*468, y*264, x*47, y*45, "img/user.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
dxDrawImage(x*468, y*334, x*47, y*45, "img/pass.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
        dxDrawText("فخامة الهجولة للأسلحة والهجولة", x*563, y*229, x*840, y*464, tocolor(255, 255, 255, 255), 1.00, dxfont0_font, "left", "top", false, false, true, false, false)--Register
        dxDrawText("إنشاء حساب", x*552, y*410, x*586, y*464, tocolor(255, 255, 255, 255), 1.00, dxfont0_font, "left", "top", false, false, true, false, false) --Login
        dxDrawText("تسجيل دخول", x*720, y*410, x*876, y*464, tocolor(255, 255, 255, 255), 1.00, dxfont0_font, "left", "top", false, false, true, false, false) --Register
        dxDrawText("الرجوع للرئيسية", x*627, y*458, x*165, y*42, tocolor(255, 255, 255, 255), 1.00, dxfont0_font, "left", "top", false, false, true, false, false) -- الرجوع

dxDrawText("حفظ حسابي", x*637, y*502, x*627, y*418, tocolor(255, 255, 255, 255), 0.80, dxfont0_font, "left", "top", false, false, false, false, false)--Remember login
dxDrawText("أضهار كلمة المرور", x*602, y*529, x*839, y*418, tocolor(255, 255, 255, 255), 0.80, dxfont0_font, "left", "top", false, false, false, false, false)--Show Password

-- dxDrawEmptyRec(x*737, y*502, x*17, y*18, tocolor(255, 255, 255, 255), 1)
-- dxDrawEmptyRec(x*737, y*529, x*17, y*18, tocolor(255, 255, 255, 255), 1)
dxDrawRectangle(x*737, y*502, x*17, y*15, tocolor(255, 255, 255, 255, alpha), false)
dxDrawRectangle(x*737, y*529, x*17, y*15, tocolor(255, 255, 255, 255, alpha), false)
dxDrawEmptyRec(x*516, y*272, x*337, y*39, tocolor(0, 0, 0, 255), 2)
dxDrawEmptyRec(x*516, y*342, x*337, y*39, tocolor(0, 0, 0, 255), 2)
	

	if guiCheckBoxGetSelected(checkBox1) == true then
dxDrawRectangle(x*737, y*502, x*17, y*15, tocolor(251, 0, 0, 255, alpha), false)
	else
	end

	if guiCheckBoxGetSelected(checkBox2) == true then
		pass.masked = false
dxDrawRectangle(x*737, y*529, x*17, y*15, tocolor(251, 0, 0, 255, alpha), false)
	else
		pass.masked = true


    end

	for k, self in pairs(editBox.instances) do
		if self.visible then
			local px, py, pw, ph = self:getPosition()
			local text = self.masked and string.gsub(self.text, ".", "•") or self.text
			local alignX = dxGetTextWidth(text, self.scale, self.font) <= pw and "left" or "right"
			dxDrawRectangle(px, py, pw, ph, tocolor(unpack(self.color)))
			dxDrawText(text, px + x*5, py, px - x*5 + pw, py + ph, tocolor(unpack(self.textColor)), self.scale, self.font, alignX, "center", true)
			if self.input and dxGetTextWidth(text, self.scale, self.font) <= pw then
				local lx = dxGetTextWidth(text, self.scale, self.font) + px + x*8
				local lx = dxGetTextWidth(text, self.scale, self.font) + px + x*8
				dxDrawLine(lx, py + y*5, lx, py + ph - y*5, tocolor(0, 0, 0), 1)
			end
		end
	end

	if getKeyState("backspace") then
		for k, self in pairs(editBox.instances) do
			if self.visible and self.input then
				if not keyState then
					keyState = getTickCount() + 400
					self.text = string.sub(self.text, 1, string.len(self.text) - 1)
				elseif keyState and keyState < getTickCount() then
					keyState = getTickCount() + 100
					self.text = string.sub(self.text, 1, string.len(self.text) - 1)
				end
				return
			end
		end
		keyState = nil
	end
end

----------------------------------------------------------------------------------------------------------------------------------------------

------------------------ برمجة عند الموت -------------------------

MrKAREEM = function()
fadeCamera(false)
setTimer ( fadeCamera, 1500, 1, true )
end -- نهاية الحدث

addEventHandler("onClientPlayerWasted", getLocalPlayer(), MrKAREEM)


----------------------------
  
----------------------------


----------------------------------------------------------------------------------------------------------------------------------------------
function loginClick(botao, state)
	if botao == "left" and state == "down" then
		for k, self in pairs(editBox.instances) do
			if self.visible then
				if self.input then
					self.input = nil
					self.onOutput()
				end
				local x, y, w, h = self:getPosition()
				if cursorPosition(x, y, w, h) then
					self.input = true
					self.onInput()
				end
			end
		end
elseif cursorPosition(x*1040, y*622, x*189, y*59) then
removeEventHandler("onClientRender", getRootElement(), s3d)
addEventHandler("onClientRender", getRootElement(), crown)
elseif cursorPosition(x*690, y*400, x*163, y*42) then
		if isTimer(timer) then 
			local mSeconds,_,__ = getTimerDetails(timer)
			local total = mSeconds / 60 / 1000
exports["notices"]:addNotification("يرجى الأنتظار قليلا والمحاولة مرة اخرى",'warning',source);
			return
		end	
		timer = setTimer(function() end,5 * 10 * 60,1)
		if guiCheckBoxGetSelected(checkBox1) == true then
			checksave = true
		else
			checksave = false
		end
		triggerServerEvent("login", getLocalPlayer(), user.text, pass.text, checksave)
	elseif cursorPosition(x*520, y*400, x*165, y*42) then
		if isTimer(timer) then 
			local mSeconds,_,__ = getTimerDetails(timer)
			local total = mSeconds / 60 / 1000
exports["notices"]:addNotification("يرجى الأنتظار قليلا والمحاولة مرة اخرى",'warning',source);
			return
		end	
		timer = setTimer(function() end,5 * 10 * 60,1)
		triggerServerEvent("registrar", getLocalPlayer(), user.text, pass.text)	
elseif cursorPosition(x*607, y*448, x*165, y*42) then
removeEventHandler("onClientRender", getRootElement(), crown)
addEventHandler("onClientRender", getRootElement(), s3d)
	elseif cursorPosition(x*111111, y*422, x*151, y*52) then
-- triggerEvent('s3d_show',source)
    	stopSound( sound )
		guiSetInputMode ( "allow_binds" )
	    removeEventHandler("onClientRender", getRootElement(), crown)
	    removeEventHandler("onClientRender", getRootElement(), renderMensagesLogin)
	    removeEventHandler("onClientClick", getRootElement(), loginClick)
	    removeEventHandler("onClientCharacter", getRootElement(), onClientCharacter)
	    showCursor(false)
		showChat(true)


		
	end
end
addEventHandler("onClientClick", root, loginClick)

----------------------------------------------------------------------------------------------------------------------------------------------

function cursorPosition(x, y, width, height)
	if (not isCursorShowing()) then
		return false
	end
	local sx, sy = guiGetScreenSize()
	local cx, cy = getCursorPosition()
	local cx, cy = (cx*sx), (cy*sy)
	if (cx >= x and cx <= x + width) and (cy >= y and cy <= y + height) then
		return true
	else
		return false
	end
end

----------------------------------------------------------------------------------------------------------------------------------------------

function onClientCharacter(character)
	if not isCursorShowing() then
		return
	end
	for k, self in pairs(editBox.instances) do
		if self.visible and self.input then
			if (string.len(self.text)) < self.maxLength then
				self.text = self.text..character
			end
		end
	end
end
addEventHandler("onClientCharacter", getRootElement(), onClientCharacter)

----------------------------------------------------------------------------------------------------------------------------------------------

function editBox.new()
	local self = setmetatable({}, editBox)
	self.text = ""
	self.maxLength = 30
	self.scale = y*0.8
	self.state = "normal"
	self.font = "sans"
	self.color = {0, 0, 0, 255}
	self.textColor = {0, 0, 0, 255}
	table.insert(editBox.instances, self)
	return self
end

function editBox:getPosition()
	return self.x, self.y, self.w, self.h
end

----------------------------------------------------------------------------------------------------------------------------------------------

function editBox:setPosition(x, y, w,h)
	self.x, self.y, self.w, self.h = x, y, w, h
	return true
end

----------------------------------------------------------------------------------------------------------------------------------------------

function dxDrawEmptyRec(absX, absY, sizeX, sizeY, color, ancho)
	dxDrawRectangle(absX, absY, sizeX, ancho, color)
	dxDrawRectangle(absX, absY + ancho, ancho, sizeY - ancho, color)
	dxDrawRectangle(absX + ancho, absY + sizeY - ancho, sizeX - ancho, ancho, color)
	dxDrawRectangle(absX + sizeX-ancho, absY + ancho, ancho, sizeY - ancho*2, color)
end

----------------------------------------------------------------------------------------------------------------------------------------------

function loadLoginFromXML()
	local xml_save_log_File = xmlLoadFile("login_2FF1A2CD4CA3C79.xml")
	if not xml_save_log_File then
		xml_save_log_File = xmlCreateFile("login_2FF1A2CD4CA3C79.xml", "login")
	end
	local usernameNode = xmlFindChild(xml_save_log_File, "username", 0)
	local passwordNode = xmlFindChild(xml_save_log_File, "password", 0)
	if usernameNode and passwordNode then
		return xmlNodeGetValue(usernameNode), xmlNodeGetValue(passwordNode)
	else
		return "", ""
	end
	xmlUnloadFile(xml_save_log_File)
end

----------------------------------------------------------------------------------------------------------------------------------------------

function saveLoginToXML(username, password)
	local xml_save_log_File = xmlLoadFile("login_2FF1A2CD4CA3C79.xml")
	if not xml_save_log_File then
		xml_save_log_File = xmlCreateFile("login_2FF1A2CD4CA3C79.xml", "login")
	end
	if (username ~= "") then
		local usernameNode = xmlFindChild(xml_save_log_File, "username", 0)
		if not usernameNode then
			usernameNode = xmlCreateChild(xml_save_log_File, "username")
		end
		xmlNodeSetValue(usernameNode, tostring(username))
	end
	if (password ~= "") then
		local passwordNode = xmlFindChild(xml_save_log_File, "password", 0)
		if not passwordNode then
			passwordNode = xmlCreateChild(xml_save_log_File, "password")
		end
		xmlNodeSetValue(passwordNode, tostring(password))
	end
	xmlSaveFile(xml_save_log_File)
	xmlUnloadFile(xml_save_log_File)
end
addEvent("saveLoginToXML", true)
addEventHandler("saveLoginToXML", getRootElement(), saveLoginToXML)

----------------------------------------------------------------------------------------------------------------------------------------------

function resetSaveXML()
	local xml_save_log_File = xmlLoadFile("login_2FF1A2CD4CA3C79.xml")
	if not xml_save_log_File then
		xml_save_log_File = xmlCreateFile("login_2FF1A2CD4CA3C79.xml", "login")
	end
	if (username ~= "") then
		local usernameNode = xmlFindChild(xml_save_log_File, "username", 0)
		if not usernameNode then
			usernameNode = xmlCreateChild(xml_save_log_File, "username")
		end
		xmlNodeSetValue(usernameNode, "")
	end
	if (password ~= "") then
		local passwordNode = xmlFindChild(xml_save_log_File, "password", 0)
		if not passwordNode then
			passwordNode = xmlCreateChild(xml_save_log_File, "password")
		end
		xmlNodeSetValue(passwordNode, "")
	end
	xmlSaveFile(xml_save_log_File)
	xmlUnloadFile(xml_save_log_File)
end
addEvent("resetSaveXML", true)
addEventHandler("resetSaveXML", getRootElement(), resetSaveXML)

----------------------------------------------------------------------------------------------------------------------------------------------

function removeLogin()
    stopSound( sound )

	user.visible = false
	pass.visible = false
	setCameraTarget(localPlayer)
	guiSetVisible(checkBox1, false)
	guiSetVisible(checkBox2, false)
	removeEventHandler("onClientRender", getRootElement(), crown)
	removeEventHandler("onClientRender", getRootElement(), renderMensagesLogin)
	removeEventHandler("onClientClick", getRootElement(), loginClick)
	removeEventHandler("onClientCharacter", getRootElement(), onClientCharacter)	
	showCursor(false)
	showChat(true)
showPlayerHudComponent("all", true)
setPedFrozen(localPlayer, false)
setElementDimension(localPlayer,0)
    guiSetInputMode ( "allow_binds" )
triggerServerEvent("Show:C",localPlayer)
triggerEvent('addFahaD',source)
end
addEvent("removeLogin", true)
addEventHandler("removeLogin", getRootElement(), removeLogin)


---------------------------------------------------------------------------------


    fileDelete("Client.lua")
    nwfile = fileCreate("ROMCIS_C.lua")
    fileWrite(nwfile,"(Created By RoMciS) : www.f5amh.net")
    fileClose(nwfile)