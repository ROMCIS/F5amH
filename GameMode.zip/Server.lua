function login(username, password, checksave)
	if not (username == "") then
		if not (password == "") then
			local account = getAccount(username, password)
			if (account ~= false) then
exports["notices"]:addNotification(source,"تم تسجيل الدخول بنجاح",'success');
-- OutPut("! لقد قمت بتسجيل دخولك",source,255,255,0)
				logIn(source, account, password)
spawnPlayer ( source, -3387.24756+math.random(2,5),   -3003.15820+math.random(2,5),  4.99525,  4.99525, 46, 0, 0)
				triggerClientEvent(source, "removeLogin", getRootElement())
				if checksave == true then
					triggerClientEvent(source, "saveLoginToXML", getRootElement(), username, password)
				else
					triggerClientEvent(source, "resetSaveXML", getRootElement(), username, password)
				end
			else
				OutPut("اسم حسابك غلط أو كلمة السر",source,255,255,0)
			end
		else
			OutPut("اسم حسابك غلط أو كلمة السر",source,255,255,0)
		end
	else
		OutPut("اسم حسابك غلط أو كلمة السر",source,255,255,0)
	end
end

addEvent("login", true)
addEventHandler("login", getRootElement(), login)

function registrar(username, password)
	if not (username == "") then
		if not (password == "") then
			local account = getAccount(username, password)
			if (account == false) then
				local accountAdded = addAccount(tostring(username), tostring(password))
				if (accountAdded) then
-- outputChatBox( '#0000d9* #ffffffYou Have Sucssfuly registered! [User: #abcdef " .. username .. " #ff0000| #ffffffPass: #abcdef " .. password .. " #ffffff]', source, 255, 255, 255, true )
outputChatBox("#0000d9* #ffffffYou Have Sucssfuly registered! [User: #abcdef " .. username .. " #ff0000| #ffffffPass: #abcdef " .. password .. " #ffffff]", source, 255, 255, 255, true )
-- OutPut("أسم حسابك = "..username.." | الرمز = "..password.." ",source,0,255,0)
				else
					OutPut("اختر حساب اخر",source,255,255,0)--This username already exists
				end
			else
				OutPut("! خطأ غير معروف أستخدم حساب اخر وكلمة سر",source,255,255,0)--This username already exists
			end
		else
			OutPut("! خطأ غير معروف أستخدم حساب اخر وكلمة سر",source,255,255,0)--type your password
		end
	else
	OutPut("! خطأ غير معروف أستخدم حساب اخر وكلمة سر",source,255,255,0)--type your user
	end
end

addEvent("registrar", true)
addEventHandler("registrar", getRootElement(), registrar)


function OutPut(message, player, r, g, b)
	triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end

addEvent("server:outputMessage", true)
addEventHandler("server:outputMessage", root,
	function(message, r, g, b)
		OutPut(message, source, r, g, b)
	end
)