addEventHandler("onResourceStart", resourceRoot,
	function()
		resetMapInfo()
		for i,player in ipairs(getElementsByType("player")) do
			spawn(player)
		end
	end
)

function spawn(player)
	if not isElement(player) then return end
	repeat until spawnPlayer ( player, -2733.2883300781, -7764.73046875, 5.8000001907349, 180, 46, 0, 0)
	fadeCamera(player, true)
	setCameraTarget(player, player)
	showChat(player, true)
end

addEventHandler("onPlayerJoin", root,
	function()
		spawn(source)
	end
)

addEventHandler("onPlayerWasted", root,
	function()
		setTimer(spawn, 1800, 1, source)
	end
)

-- -2733.2883300781,-7764.73046875,5.8000001907349