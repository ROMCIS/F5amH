﻿local x, y, z =x,y,z
local marker = createMarker( -2822.06445, -7535.98486, 7.07859, "cylinder", 1.5, 200, 0, 0, 255 )
local vehicles = { }
local IDs = { 436, 561, 587, 438, 46, 549, 540, 580, 489, 555 }

addEventHandler( "onMarkerHit", marker,
	function( element )
		if getElementType( element ) ~= "player" then return end
		if isPedInVehicle( element ) then return end
		if vehicles[ element ] then
			destroyElement( vehicles[ element ] )
			vehicles[ element ] = nil
		end
		local pX, pY, pZ = getElementPosition( element )
		local pRX, pRY, pRZ = getElementRotation( element )
		local randomNum = math.random( #IDs )
		local id = IDs[ randomNum ]
		vehicles[ element ] = createVehicle( id, -2803.00854, -7530.63086, 7.70000 )
		if vehicles[ element ] then
			warpPedIntoVehicle( element, vehicles[ element ] )
			OutPut( "تم اعطائك سيارة بنجاح", element, 254, 203, 0, true )
		end
	end
)

addEventHandler( "onPlayerQuit", root,
	function( )
		if vehicles[ source ] then
			destroyElement( vehicles[ source ] )
			vehicles[ source ] = nil
		end
	end
)

addEventHandler( "onVehicleExplode", root,
	function( )
		setTimer( function( source )
			for k, v in ipairs( vehicles ) do
				if source == v then
					table.remove( vehicles, k )
				end
			end
			destroyElement( source )
		end, 2000, 1 )
	end
)

function OutPut(message, player, r, g, b) 
triggerClientEvent(player, "client:dxOutputMessage", player, message, r, g, b)
end


