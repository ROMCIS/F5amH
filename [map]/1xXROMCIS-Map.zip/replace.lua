txd1 = engineLoadTXD("8661.txd")
engineImportTXD(txd1, 8661)

txd2 = engineLoadTXD("4241.txd")
engineImportTXD(txd2, 4241)

txd5 = engineLoadTXD("8357.txd")
engineImportTXD(txd5, 8357)

local txd14 = engineLoadTXD('TxD.txd',true)
            engineImportTXD(txd14, 3095) 

txd55 = engineLoadTXD("4867.txd")
engineImportTXD(txd55, 4867)





