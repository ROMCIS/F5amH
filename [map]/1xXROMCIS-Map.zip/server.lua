﻿
SafahM = createMarker( -2733.462890625, -7765.4682617188, 5.8000001907349, "cylinder", 200, 0, 0, 0, 0 )
-- 2733.462890625,-7765.4682617188,5.8000001907349

addEventHandler ( "onMarkerHit", SafahM,
    function ( hitPlayer )
		setPedSkin ( hitPlayer, 46 )
        if getElementType ( hitPlayer ) == "player" then
            toggleControl ( hitPlayer, "fire", false )
            toggleControl ( hitPlayer, "aim_weapon", false )
        elseif getElementType ( hitPlayer ) == "vehicle" then
            local Player = getVehicleController ( hitPlayer )
            outputChatBox ( "* ممنوع دخول المواتر هنا !", Player, 255, 0, 0, true )
            destroyElement ( hitPlayer )			
        end
    end
)
 
addEventHandler ( "onMarkerLeave", SafahM,
    function ( leftPlayer )
        if getElementType ( leftPlayer ) == "player" then
            toggleControl ( leftPlayer, "fire", true )
            toggleControl ( leftPlayer, "aim_weapon", true )
        end
    end
)

function xRayan()
setPedSkin ( source, 46 )
end
addEventHandler("onPlayerLogin", getRootElement(), xRayan)