function superman ()
cancelEvent ()
end

xCol = createColRectangle (-3655,-3166.0693359375,379.03997802734,200)
xRadar = createRadarArea (-3600,-3100.0693359375,450.00000000000,200,0,0,255,0,root)

addEventHandler("onColShapeHit",resourceRoot,function (element)
if ( getElementType(element) == "vehicle" ) then
destroyElement(element)
elseif ( getElementType(element) == "player" ) then
toggleControl (element,"fire",false)
toggleControl (element,"action",false)
toggleControl (element,"aim_weapon",false)
addEventHandler("onPlayerDamage",root,superman)
addEventHandler("onClientPlayerDamage", localPlayer, cancelEvent)
end
end)

addEventHandler("onColShapeLeave",resourceRoot,function (element)
if ( getElementType(element) == "player" ) then
toggleControl (element,"fire",true)
toggleControl (element,"action",true)
toggleControl (element,"aim_weapon",true)
removeEventHandler("onPlayerDamage",root,superman)
removeEventHandler("onClientPlayerDamage", localPlayer, cancelEvent)
end
end)
