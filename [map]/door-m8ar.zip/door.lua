Door3 = createObject(6959,3545.3999023438,2192,45.700000762939,0,0,0)
markerDoor3 = createMarker(3545.3000488281,2194,46.700000762939,'cylinder',35,0,0,0,0)

addEventHandler('onMarkerHit',markerDoor3,
function ( hitElement )
     moveObject(Door3,1000,3545.3999023438,2232.3000488281,45.700000762939)
end
)

addEventHandler('onMarkerLeave',markerDoor3,
function ( hitElement )
     moveObject(Door3,1000,3545.3999023438,2192,45.700000762939)
end
)